﻿import os

ROOT = r"C:\IOTEC_OMEGA_X\frontend"

connector_script = """

<script src="../core_connector.js"></script>

<script>

async function autoSendOrder(){

    await sendOrder({

        cliente:"Visitante Global",
        pais:"Brasil",
        setor:"Corporate Operations",
        produto:"SolicitaÃ§Ã£o Web",
        valor:199.90

    });

}

</script>

"""

BUTTON_CODE = """

<button onclick="autoSendOrder()" class="iotec-order-button">

Solicitar implantaÃ§Ã£o

</button>

"""

for root, dirs, files in os.walk(ROOT):

    for file in files:

        if file.endswith(".html"):

            path = os.path.join(root, file)

            try:

                with open(
                    path,
                    "r",
                    encoding="utf-8"
                ) as f:

                    content = f.read()

                modified = False

                if "core_connector.js" not in content:

                    content = content.replace(

                        "</body>",

                        connector_script + "\n</body>"

                    )

                    modified = True

                if "iotec-order-button" not in content:

                    content = content.replace(

                        "</body>",

                        BUTTON_CODE + "\n</body>"

                    )

                    modified = True

                if modified:

                    with open(

                        path,
                        "w",
                        encoding="utf-8"

                    ) as f:

                        f.write(content)

                    print(
                        "[CONNECTED]",
                        path
                    )

            except Exception as e:

                print(
                    "[ERROR]",
                    path,
                    e
                )

print()

print("======================================")
print(" IOTEC AUTO INJECTOR COMPLETE")
print("======================================")

