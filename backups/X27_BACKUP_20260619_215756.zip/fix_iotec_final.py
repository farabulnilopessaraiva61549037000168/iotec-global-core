﻿import re

FILE = r"C:\IOTEC\FROZEN\visible_core_router.py"

with open(FILE, "r", encoding="utf-8", errors="ignore") as f:
    text = f.read()

# 🔥 INJEÇÃO DE CONFIG SEGURA NO __init__
patch = """
        # AUTO-GENERATED SAFE CONFIG PATCH
        if not hasattr(self, "config") or self.config is None:
            self.config = {}

        self.config.setdefault("paths", {})
        self.config["paths"].setdefault("logs_dir", "logs")
        self.config["paths"].setdefault("snapshots_dir", "snapshots")
"""

# injeta depois do __init__ (heurística simples)
text = text.replace(
    "def __init__(self",
    "def __init__(self" + patch
)

# fallback adicional direto no acesso problemático
text = re.sub(
    r'self\.config\["paths"\]\["snapshots_dir"\]',
    'self.config.get("paths", {}).get("snapshots_dir", "snapshots")',
    text
)

text = re.sub(
    r'self\.config\["paths"\]\["logs_dir"\]',
    'self.config.get("paths", {}).get("logs_dir", "logs")',
    text
)

with open(FILE, "w", encoding="utf-8") as f:
    f.write(text)

print("PATCH DEFINITIVO APLICADO")
