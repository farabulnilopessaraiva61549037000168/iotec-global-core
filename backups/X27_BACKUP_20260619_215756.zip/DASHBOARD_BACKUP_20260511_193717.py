﻿# ============================================================
# IOTEC LIVE CONTROL TOWER
# ============================================================

import streamlit as st
import sqlite3
import pandas as pd
import time

# ============================================================
# CONFIGURAÃ‡ÃƒO
# ============================================================

st.set_page_config(

    page_title="IOTEC CONTROL TOWER",

    layout="wide"
)

# ============================================================
# AUTO REFRESH
# ============================================================

st.autorefresh(
    interval=5000,
    key="iotec_refresh"
)

# ============================================================
# CONEXÃƒO
# ============================================================

conn = sqlite3.connect(
    "iotec_operational.db"
)

# ============================================================
# LEITURA DE DADOS
# ============================================================

clients = pd.read_sql_query(
    "SELECT * FROM clients",
    conn
)

requests = pd.read_sql_query(
    "SELECT * FROM requests",
    conn
)

payments = pd.read_sql_query(
    "SELECT * FROM payments",
    conn
)

logs = pd.read_sql_query(
    "SELECT * FROM logs",
    conn
)

# ============================================================
# TOTAL FINANCEIRO
# ============================================================

if len(payments) > 0:

    total_revenue = payments["amount"].sum()

else:

    total_revenue = 0

# ============================================================
# CABEÃ‡ALHO
# ============================================================

st.title("IOTEC LIVE CONTROL TOWER")

st.caption(
    "GovernanÃ§a Operacional Viva"
)

# ============================================================
# STATUS OPERACIONAL
# ============================================================

st.success("NÃšCLEO OPERACIONAL ONLINE")

# ============================================================
# MÃ‰TRICAS
# ============================================================

col1, col2, col3, col4 = st.columns(4)

col1.metric(
    "CLIENTES",
    len(clients)
)

col2.metric(
    "SOLICITAÃ‡Ã•ES",
    len(requests)
)

col3.metric(
    "PAGAMENTOS",
    len(payments)
)

col4.metric(
    "RECEITA TOTAL",
    f"R$ {total_revenue:,.2f}"
)

# ============================================================
# CLIENTES
# ============================================================

st.divider()

st.subheader("CLIENTES")

st.dataframe(
    clients,
    width="stretch"
)

# ============================================================
# SOLICITAÃ‡Ã•ES
# ============================================================

st.divider()

st.subheader("SOLICITAÃ‡Ã•ES")

st.dataframe(
    requests,
    width="stretch"
)

# ============================================================
# PAGAMENTOS
# ============================================================

st.divider()

st.subheader("PAGAMENTOS")

st.dataframe(
    payments,
    width="stretch"
)

# ============================================================
# LOGS OPERACIONAIS
# ============================================================

st.divider()

st.subheader("LOGS OPERACIONAIS")

if len(logs) > 0:

    logs = logs.sort_values(
        by="id",
        ascending=False
    )

st.dataframe(
    logs,
    width="stretch"
)

# ============================================================
# RODAPÃ‰
# ============================================================

st.divider()

st.caption(
    "IOTEC â€¢ LIVE OPERATIONAL GOVERNANCE"
)

# ============================================================
# FIM
# ============================================================

