﻿if eh_pagamento_paypal(remetente, assunto, corpo):

    print("ðŸ’° Pagamento confirmado via PayPal")

    # exemplo: atualizar cliente
    for c in st.session_state.clientes:
        if c["status"] == "AGUARDANDO_PAGAMENTO":
            c["status"] = "PAGO"
            c["prioridade"] = "ALTA"

