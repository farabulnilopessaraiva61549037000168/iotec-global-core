﻿// ===============================
// IOTEC ADAPTADOR DE ROTAS
// ===============================

// intercepta todos os links
document.querySelectorAll('a').forEach(link => {
  link.addEventListener('click', function(e) {
    const href = this.getAttribute('href');

    if (!href) return;

    // sÃ³ intercepta rotas do Replit
    if (href.startsWith('http') && href.includes('replit')) {
      e.preventDefault();

      if (href.includes('/servicos')) {
        window.location.href = 'servicos.html';
      }

      else if (href.includes('/diagnostico')) {
        window.location.href = 'diagnostico.html';
      }

      else if (href.includes('/portais')) {
        window.location.href = 'portais.html';
      }

      else {
        window.location.href = 'index.html';
      }
    }
  });
});


// ===============================
// SIMULAÃ‡ÃƒO DO NÃšCLEO
// ===============================
const NUCLEO = {
  diagnostico: function(texto) {
    return "DiagnÃ³stico processado pelo nÃºcleo IOTEC";
  }
};


// ===============================
// LIGAÃ‡ÃƒO COM O TEXTAREA
// ===============================
const textarea = document.getElementById("diagTexto");
const resultado = document.getElementById("diagResults");

if (textarea && resultado) {
  textarea.addEventListener("blur", () => {
    const resposta = NUCLEO.diagnostico(textarea.value);
    resultado.innerHTML = `<div style="padding:10px">${resposta}</div>`;
  });
}

