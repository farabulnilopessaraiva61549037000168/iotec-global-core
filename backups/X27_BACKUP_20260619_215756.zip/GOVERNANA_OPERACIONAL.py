﻿# ============================================================
# IOTEC - GOVERNANÃ‡A OPERACIONAL INTELIGENTE
# REGULUS CORE ENGINE v2.0
# EMPRESA: IOTEC
# MODO: ORQUESTRACAO_ENTERPRISE
# STATUS: ONLINE
# ============================================================

import json
import uuid
import random
from datetime import datetime

# ============================================================
# IDENTIDADE DO NÃšCLEO
# ============================================================

NUCLEO = {
    "empresa": "IOTEC",
    "cidade": "REGULUS_CITY",
    "modo": "orquestracao_enterprise",
    "status": "online",
    "timestamp": str(datetime.now())
}

# ============================================================
# SETORES OPERACIONAIS
# ============================================================

SETORES = {

    "analytics": {
        "capacidade": random.randint(40, 99),
        "compatibilidade": ["govtech", "juridico"]
    },

    "govtech": {
        "capacidade": random.randint(40, 99),
        "compatibilidade": ["analytics", "juridico"]
    },

    "juridico": {
        "capacidade": random.randint(40, 99),
        "compatibilidade": ["analytics"]
    },

    "importacao": {
        "capacidade": random.randint(40, 99),
        "compatibilidade": ["analytics"]
    }
}

# ============================================================
# CLIENTES
# ============================================================

CLIENTES = [
    "North Analytics",
    "Global Vision",
    "Future Legal",
    "Atlas Systems",
    "Prime Commerce",
    "Omega Intelligence"
]

# ============================================================
# PRODUTOS
# ============================================================

PRODUTOS = {
    "analytics": "Omega Analytics Enterprise",
    "govtech": "GovTech Intelligence",
    "juridico": "Lexus Juris Enterprise",
    "importacao": "Casa Turca Commerce"
}

# ============================================================
# LOG GLOBAL
# ============================================================

LOG_GLOBAL = []

# ============================================================
# REGISTRO DE LOG
# ============================================================

def registrar_log(evento):

    LOG_GLOBAL.append({
        "timestamp": str(datetime.now()),
        "evento": evento
    })

# ============================================================
# DETECÃ‡ÃƒO DE SOBRECARGA
# ============================================================

def detectar_sobrecarga():

    sobrecarga = []

    for setor, dados in SETORES.items():

        if dados["capacidade"] >= 90:

            sobrecarga.append(setor)

            registrar_log(
                f"SOBRECARGA DETECTADA -> {setor.upper()} "
                f"({dados['capacidade']}%)"
            )

    return sobrecarga

# ============================================================
# BUSCA DE SETOR AUXILIAR
# ============================================================

def buscar_setor_auxiliar(setor_origem):

    compativeis = SETORES[setor_origem]["compatibilidade"]

    for setor in compativeis:

        capacidade = SETORES[setor]["capacidade"]

        if capacidade <= 70:

            registrar_log(
                f"SETOR AUXILIAR ENCONTRADO -> "
                f"{setor.upper()} ({capacidade}%)"
            )

            return setor

    return None

# ============================================================
# ATA OPERACIONAL
# ============================================================

def criar_ata(setor_origem, setor_auxiliar):

    ata = {
        "id_operacao": str(uuid.uuid4()),
        "timestamp": str(datetime.now()),
        "setor_origem": setor_origem,
        "setor_auxiliar": setor_auxiliar,
        "motivo": "sobrecarga_operacional",
        "status": "redistribuicao_autorizada"
    }

    registrar_log(
        f"ATA GERADA -> {setor_origem.upper()} "
        f"-> {setor_auxiliar.upper()}"
    )

    return ata

# ============================================================
# GERAÃ‡ÃƒO DE PEDIDO
# ============================================================

def gerar_pedido():

    setor = random.choice(list(SETORES.keys()))

    pedido = {
        "id": str(uuid.uuid4()),
        "cliente": random.choice(CLIENTES),
        "setor": setor,
        "produto": PRODUTOS[setor],
        "prazo_contratual": "30 dias",
        "status": "em_producao"
    }

    registrar_log(
        f"NOVO PEDIDO -> {pedido['cliente']} "
        f"({pedido['produto']})"
    )

    return pedido

# ============================================================
# MOTOR DE PRODUÃ‡ÃƒO
# ============================================================

def motor_producao(pedido):

    setor = pedido["setor"]

    capacidade = SETORES[setor]["capacidade"]

    print("\n===================================================")
    print(" MOTOR DE PRODUÃ‡ÃƒO")
    print("===================================================\n")

    print(f"SETOR: {setor.upper()}")
    print(f"CAPACIDADE: {capacidade}%")

    if capacidade >= 90:

        print("\n[!] SOBRECARGA DETECTADA")

        auxiliar = buscar_setor_auxiliar(setor)

        if auxiliar:

            ata = criar_ata(setor, auxiliar)

            print(f"\n[+] REDISTRIBUIÃ‡ÃƒO AUTORIZADA")
            print(f"SETOR AUXILIAR: {auxiliar.upper()}")

            registrar_log(
                f"PIPELINE REDISTRIBUIDO -> "
                f"{setor.upper()} -> {auxiliar.upper()}"
            )

            pedido["setor_auxiliar"] = auxiliar
            pedido["ata_operacional"] = ata

        else:

            print("\n[!] NENHUM SETOR DISPONÃVEL")

            registrar_log(
                f"FILA DE ESPERA -> {setor.upper()}"
            )

    else:

        print("\n[+] PRODUÃ‡ÃƒO NORMAL")

        registrar_log(
            f"PRODUÃ‡ÃƒO NORMAL -> {setor.upper()}"
        )

    return pedido

# ============================================================
# ENTREGA ANTECIPADA
# ============================================================

def verificar_entrega(pedido):

    pronto = random.choice([True, False])

    if pronto:

        pedido["status"] = "concluido_antecipadamente"

        registrar_log(
            f"ENTREGA ANTECIPADA -> "
            f"{pedido['cliente']}"
        )

        print("\n===================================================")
        print(" ENTREGA ANTECIPADA")
        print("===================================================\n")

        print(f"CLIENTE: {pedido['cliente']}")
        print(f"PRODUTO: {pedido['produto']}")

        print("\nSTATUS:")
        print("PROJETO CONCLUÃDO ANTES DO PRAZO")

        print("\nAÃ‡ÃƒO:")
        print("ENVIAR FATURA FINAL")
        print("ENVIAR RELATÃ“RIO")
        print("LIBERAR IMPLANTAÃ‡ÃƒO")

    return pedido

# ============================================================
# EXPORTAÃ‡ÃƒO DE RELATÃ“RIO
# ============================================================

def exportar_relatorio(pedido):

    relatorio = {
        "nucleo": NUCLEO,
        "pedido": pedido,
        "logs": LOG_GLOBAL
    }

    arquivo = "IOTEC_RELATORIO_OPERACIONAL.json"

    with open(arquivo, "w", encoding="utf-8") as f:
        json.dump(relatorio, f, indent=4, ensure_ascii=False)

    print("\n===================================================")
    print(" EXPORTAÃ‡ÃƒO")
    print("===================================================\n")

    print(f"RELATÃ“RIO -> {arquivo}")

# ============================================================
# EXECUÃ‡ÃƒO PRINCIPAL
# ============================================================

def iniciar_nucleo():

    print("\n===================================================")
    print(" IOTEC - REGULUS CORE ENGINE")
    print("===================================================\n")

    pedido = gerar_pedido()

    print(f"CLIENTE: {pedido['cliente']}")
    print(f"PRODUTO: {pedido['produto']}")
    print(f"PRAZO: {pedido['prazo_contratual']}")

    pedido = motor_producao(pedido)

    pedido = verificar_entrega(pedido)

    exportar_relatorio(pedido)

    print("\n===================================================")
    print(" NÃšCLEO FINALIZADO")
    print("===================================================\n")

# ============================================================
# START
# ============================================================

if __name__ == "__main__":
    iniciar_nucleo()

