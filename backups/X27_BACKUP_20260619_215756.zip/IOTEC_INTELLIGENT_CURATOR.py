﻿from flask import Flask, jsonify
from flask_cors import CORS
from datetime import datetime
import os
import uuid

app = Flask(__name__)
CORS(app)

ROOT = r"C:\IOTEC"

ATIVOS = []

MAPAS = {
    "interfaces": [],
    "backends": [],
    "engines": [],
    "governanca": [],
    "seguranca": [],
    "autonomia": [],
    "marketing": [],
    "producao": [],
    "analise": [],
    "duplicados": [],
    "premium": []
}

PALAVRAS_CHAVE = {

    "engines": [
        "engine",
        "core",
        "gateway",
        "kernel",
        "master"
    ],

    "governanca": [
        "govern",
        "control",
        "tower",
        "manager",
        "supervisor"
    ],

    "seguranca": [
        "security",
        "protect",
        "audit",
        "shield"
    ],

    "autonomia": [
        "auto",
        "adaptive",
        "autonomous"
    ],

    "marketing": [
        "cliente",
        "marketing",
        "publicidade",
        "branding",
        "atendente"
    ],

    "producao": [
        "dashboard",
        "interface",
        "visual",
        "frontend",
        "html"
    ],

    "analise": [
        "analise",
        "analytics",
        "diagnostico",
        "detectar"
    ]
}

def classificar(nome):

    nome_lower = nome.lower()

    categorias = []

    for categoria, palavras in PALAVRAS_CHAVE.items():

        for palavra in palavras:

            if palavra in nome_lower:

                categorias.append(categoria)

                break

    return categorias

def premium_score(nome):

    score = 0

    nome = nome.lower()

    if "iotec" in nome:
        score += 3

    if "core" in nome:
        score += 4

    if "engine" in nome:
        score += 4

    if "gateway" in nome:
        score += 5

    if "adaptive" in nome:
        score += 5

    if "autonomous" in nome:
        score += 5

    if "global" in nome:
        score += 4

    if "intelligence" in nome:
        score += 5

    return score

@app.route('/')

def home():

    return jsonify({

        "empresa": "IOTEC",

        "modo": "organizacao_inteligente",

        "curator": "online",

        "timestamp":
        datetime.now().strftime(
            "%d/%m/%Y %H:%M:%S"
        )
    })

@app.route('/curator/explorar')

def explorar():

    global ATIVOS

    ATIVOS.clear()

    for chave in MAPAS:

        MAPAS[chave].clear()

    nomes = []

    for pasta, subpastas, arquivos in os.walk(ROOT):

        for arquivo in arquivos:

            path = os.path.join(
                pasta,
                arquivo
            )

            ext = os.path.splitext(
                arquivo
            )[1].lower()

            if ext not in [
                ".py",
                ".html",
                ".js",
                ".jsx",
                ".json",
                ".css"
            ]:
                continue

            ativo = {

                "id":
                str(uuid.uuid4()),

                "arquivo":
                arquivo,

                "path":
                path,

                "extensao":
                ext,

                "categorias":
                classificar(arquivo),

                "score":
                premium_score(arquivo),

                "timestamp":
                datetime.now().strftime(
                    "%d/%m/%Y %H:%M:%S"
                )
            }

            if arquivo in nomes:

                MAPAS["duplicados"].append(ativo)

            nomes.append(arquivo)

            if ext in [
                ".html",
                ".css",
                ".js",
                ".jsx"
            ]:

                MAPAS["interfaces"].append(ativo)

            if ext == ".py":

                MAPAS["backends"].append(ativo)

            for categoria in ativo["categorias"]:

                MAPAS[categoria].append(ativo)

            if ativo["score"] >= 8:

                MAPAS["premium"].append(ativo)

            ATIVOS.append(ativo)

    return jsonify({

        "status":
        "curadoria_finalizada",

        "ativos":
        len(ATIVOS),

        "premium":
        len(MAPAS["premium"]),

        "interfaces":
        len(MAPAS["interfaces"]),

        "backends":
        len(MAPAS["backends"]),

        "duplicados":
        len(MAPAS["duplicados"])
    })

@app.route('/curator/mapa')

def mapa():

    resumo = {}

    for categoria, itens in MAPAS.items():

        resumo[categoria] = len(itens)

    return jsonify({

        "modo":
        "organizacao_inteligente",

        "resumo":
        resumo
    })

@app.route('/curator/executivo')

def executivo():

    premium = sorted(

        MAPAS["premium"],

        key=lambda x: x["score"],

        reverse=True
    )

    return jsonify({

        "empresa":
        "IOTEC",

        "modo":
        "curadoria_executiva",

        "ativos":
        len(ATIVOS),

        "premium":
        len(MAPAS["premium"]),

        "engines":
        len(MAPAS["engines"]),

        "governanca":
        len(MAPAS["governanca"]),

        "interfaces":
        len(MAPAS["interfaces"]),

        "top_ativos":
        premium[:20],

        "timestamp":
        datetime.now().strftime(
            "%d/%m/%Y %H:%M:%S"
        )
    })

if __name__ == '__main__':

    print("")
    print("=" * 70)
    print(" IOTEC INTELLIGENT CURATOR ")
    print("=" * 70)
    print("")

    app.run(
        host='0.0.0.0',
        port=7400
    )

