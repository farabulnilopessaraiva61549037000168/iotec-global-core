﻿def gerar_texto_contextual(tipo, dados):

    if tipo == "juridico":
        return f"""
Observa-se, a partir da anÃ¡lise realizada, que a adequaÃ§Ã£o ao novo cenÃ¡rio pode implicar aumento da exposiÃ§Ã£o a riscos administrativos e financeiros.

Sugere-se a adoÃ§Ã£o de medidas preventivas, com vistas Ã  mitigaÃ§Ã£o de possÃ­veis impactos futuros.
"""

    elif tipo == "publico":
        return f"""
A anÃ¡lise indica aumento significativo da despesa com pessoal.

Recomenda-se planejamento estratÃ©gico para adequaÃ§Ã£o, evitando comprometimento do equilÃ­brio orÃ§amentÃ¡rio.
"""

    elif tipo == "privado":
        return f"""
A projeÃ§Ã£o aponta aumento nos custos operacionais.

Ã‰ recomendada a adoÃ§Ã£o de medidas de ajuste para preservar a sustentabilidade financeira.
"""

