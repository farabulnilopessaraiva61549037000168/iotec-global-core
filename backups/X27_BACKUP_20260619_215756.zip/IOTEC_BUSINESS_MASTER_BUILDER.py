import json
from pathlib import Path
from datetime import datetime

ROOT = Path(r"C:\IOTEC")

PALAVRAS = {

    "empresa",
    "cliente",
    "clientes",
    "telefone",
    "celular",
    "whatsapp",
    "email",
    "contato",
    "cidade",
    "estado",
    "endereco",
    "site",
    "segmento",
    "cnpj",
    "fornecedor",
    "parceiro",
    "parceiros",
    "lead",
    "leads",
    "oportunidade",
    "oportunidades",
    "escola",
    "escolas",
    "universidade",
    "universidades",
    "faculdade",
    "faculdades"
}

MASTER = {
    "gerado_em": str(datetime.now()),
    "origens": [],
    "registros": []
}

jsons = list(ROOT.rglob("*.json"))

for arq in jsons:

    try:

        with open(
            arq,
            "r",
            encoding="utf-8",
            errors="ignore"
        ) as f:

            dados = json.load(f)

        encontrou = False

        def verificar(obj):

            global encontrou

            if isinstance(obj, dict):

                for k, v in obj.items():

                    if str(k).lower() in PALAVRAS:

                        return True

                    if verificar(v):

                        return True

            elif isinstance(obj, list):

                for item in obj:

                    if verificar(item):

                        return True

            return False

        encontrou = verificar(dados)

        if encontrou:

            MASTER["origens"].append(
                str(arq)
            )

            MASTER["registros"].append({
                "arquivo": arq.name,
                "caminho": str(arq),
                "dados": dados
            })

    except:
        pass

saida = ROOT / "BUSINESS_MASTER_RESERVOIR.json"

with open(
    saida,
    "w",
    encoding="utf-8"
) as f:

    json.dump(
        MASTER,
        f,
        indent=2,
        ensure_ascii=False
    )

print("\nBUSINESS MASTER CRIADO\n")

print(
    f"ORIGENS: {len(MASTER['origens'])}"
)

print(
    f"REGISTROS: {len(MASTER['registros'])}"
)

print(
    f"\nARQUIVO: {saida}"
)