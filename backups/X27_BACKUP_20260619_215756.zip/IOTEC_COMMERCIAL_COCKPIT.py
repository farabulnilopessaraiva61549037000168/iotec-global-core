import json
from datetime import datetime

ARQUIVO = "IOTEC_TRAFFIC_LOG.json"

try:

    with open(
        ARQUIVO,
        "r",
        encoding="utf-8"
    ) as f:

        dados = json.load(f)

except:

    dados = {

        "visitas": [],
        "formularios": [],
        "leads": [],
        "propostas": [],
        "contratos": [],
        "receita": []
    }

visitas = len(dados.get("visitas", []))
formularios = len(dados.get("formularios", []))
leads = len(dados.get("leads", []))
propostas = len(dados.get("propostas", []))
contratos = len(dados.get("contratos", []))

receita_total = 0

for item in dados.get("receita", []):

    receita_total += item.get(
        "valor",
        0
    )

taxa_formulario = 0
taxa_lead = 0
taxa_proposta = 0
taxa_contrato = 0

if visitas > 0:

    taxa_formulario = (
        formularios / visitas
    ) * 100

    taxa_lead = (
        leads / visitas
    ) * 100

if leads > 0:

    taxa_proposta = (
        propostas / leads
    ) * 100

if propostas > 0:

    taxa_contrato = (
        contratos / propostas
    ) * 100

print("")
print("===================================")
print("IOTEC COMMERCIAL COCKPIT")
print("===================================")

print("")
print("DATA:")
print(datetime.now())

print("")
print("===================================")
print("FUNIL COMERCIAL")
print("===================================")

print("")
print("VISITAS:")
print(visitas)

print("")
print("FORMULARIOS:")
print(formularios)

print("")
print("LEADS:")
print(leads)

print("")
print("PROPOSTAS:")
print(propostas)

print("")
print("CONTRATOS:")
print(contratos)

print("")
print("===================================")
print("CONVERSAO")
print("===================================")

print("")
print("VISITA -> FORMULARIO:")
print(f"{taxa_formulario:.2f}%")

print("")
print("VISITA -> LEAD:")
print(f"{taxa_lead:.2f}%")

print("")
print("LEAD -> PROPOSTA:")
print(f"{taxa_proposta:.2f}%")

print("")
print("PROPOSTA -> CONTRATO:")
print(f"{taxa_contrato:.2f}%")

print("")
print("===================================")
print("RECEITA")
print("===================================")

print("")
print("RECEITA TOTAL:")
print(
    f"R$ {receita_total:,.2f}"
)

print("")
print("===================================")
print("MAPA OPERACIONAL")
print("===================================")

print("VISITA")
print("↓")

print("FORMULARIO")
print("↓")

print("LEAD")
print("↓")

print("PROPOSTA")
print("↓")

print("CONTRATO")
print("↓")

print("RECEITA")

print("")
print("===================================")
print("STATUS")
print("===================================")

if leads > 0:

    print("LEADS DETECTADOS")

else:

    print("SEM LEADS")

if propostas > 0:

    print("PROPOSTAS DETECTADAS")

else:

    print("SEM PROPOSTAS")

if contratos > 0:

    print("CONTRATOS DETECTADOS")

else:

    print("SEM CONTRATOS")

if receita_total > 0:

    print("RECEITA DETECTADA")

else:

    print("SEM RECEITA")

print("")
print("===================================")
print("ORDEM MOR")
print("===================================")

print(
    "TRANSFORMAR VISITAS "
    "EM RECEITA."
)

print("")
print("COMMERCIAL COCKPIT ATIVO")