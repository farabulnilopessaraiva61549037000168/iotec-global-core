﻿def gerar_resposta(memoria_cliente, mensagem):

    historico = memoria_cliente["historico"]
    nome = memoria_cliente["nome"]
    servico = memoria_cliente["servico"]

    if len(historico) > 5:
        return f"""
{nome}, jÃ¡ estamos acompanhando seu caso ({servico}).

Com base nas interaÃ§Ãµes anteriores, estamos avanÃ§ando no processo.
"""

    return f"""
{nome}, entendi sua mensagem.

Estamos tratando seu caso ({servico}).
"""

