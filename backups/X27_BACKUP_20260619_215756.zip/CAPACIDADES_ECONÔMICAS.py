# ============================================================
# 🧠 IOTEC - SONDA DE CAPACIDADES ECONÔMICAS
# ============================================================
# OBJETIVO:
# Vasculhar o núcleo procurando:
# - APIs
# - IA
# - automações
# - dashboards
# - OCR
# - monitoramento
# - analytics
# - monetização potencial
# - deploys
# - microserviços
#
# Gera relatório completo em JSON + TXT
# ============================================================

import os
import json
import re
from datetime import datetime

# ============================================================
# CONFIG
# ============================================================

ROOT_DIR = r"C:\IOTEC"   # ALTERE SE NECESSÁRIO

OUTPUT_JSON = "IOTEC_CAPABILITIES_REPORT.json"
OUTPUT_TXT  = "IOTEC_CAPABILITIES_REPORT.txt"

# ============================================================
# PALAVRAS-CHAVE E SCORE
# ============================================================

KEYWORDS = {
    "AI_ENGINE": [
        "openai",
        "gpt",
        "llm",
        "langchain",
        "agent",
        "ai",
        "intelligence"
    ],

    "MONITORING": [
        "monitor",
        "health",
        "analytics",
        "metrics",
        "dashboard",
        "stream",
        "telemetry"
    ],

    "AUTOMATION": [
        "automation",
        "auto",
        "scheduler",
        "trigger",
        "workflow",
        "pipeline"
    ],

    "OCR_DOCUMENT": [
        "ocr",
        "pdf",
        "document",
        "scan",
        "vision"
    ],

    "API_SERVICE": [
        "api",
        "fastapi",
        "flask",
        "express",
        "router",
        "endpoint"
    ],

    "AUTH_SECURITY": [
        "login",
        "auth",
        "token",
        "jwt",
        "session"
    ],

    "DATABASE": [
        "supabase",
        "postgres",
        "mongodb",
        "sqlite",
        "mysql"
    ],

    "DEPLOY_INFRA": [
        "render",
        "netlify",
        "docker",
        "deploy",
        "cloud",
        "server"
    ]
}

# ============================================================
# SCORE ECONÔMICO
# ============================================================

VALUE_SCORE = {
    "AI_ENGINE": 10,
    "MONITORING": 9,
    "AUTOMATION": 9,
    "OCR_DOCUMENT": 8,
    "API_SERVICE": 8,
    "AUTH_SECURITY": 6,
    "DATABASE": 5,
    "DEPLOY_INFRA": 9
}

# ============================================================
# EXTENSÕES
# ============================================================

VALID_EXTENSIONS = [
    ".py",
    ".js",
    ".ts",
    ".tsx",
    ".jsx",
    ".json",
    ".env",
    ".md"
]

# ============================================================
# RESULTADOS
# ============================================================

report = {
    "generated_at": str(datetime.now()),
    "root": ROOT_DIR,
    "files_scanned": 0,
    "capabilities": [],
    "economic_opportunities": []
}

# ============================================================
# ANALISADOR
# ============================================================

def analyze_file(filepath):

    findings = []

    try:
        with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
            content = f.read().lower()

            for capability, words in KEYWORDS.items():

                found = []

                for word in words:
                    if word in content:
                        found.append(word)

                if found:

                    findings.append({
                        "capability": capability,
                        "keywords": found,
                        "score": VALUE_SCORE[capability]
                    })

    except:
        pass

    return findings

# ============================================================
# SCAN
# ============================================================

for root, dirs, files in os.walk(ROOT_DIR):

    for file in files:

        ext = os.path.splitext(file)[1].lower()

        if ext in VALID_EXTENSIONS:

            path = os.path.join(root, file)

            report["files_scanned"] += 1

            results = analyze_file(path)

            if results:

                capability_data = {
                    "file": path,
                    "findings": results
                }

                report["capabilities"].append(capability_data)

# ============================================================
# AGRUPAMENTO ECONÔMICO
# ============================================================

economic_map = {}

for item in report["capabilities"]:

    for finding in item["findings"]:

        cap = finding["capability"]

        if cap not in economic_map:
            economic_map[cap] = 0

        economic_map[cap] += finding["score"]

# ============================================================
# PRIORIZAÇÃO
# ============================================================

sorted_caps = sorted(
    economic_map.items(),
    key=lambda x: x[1],
    reverse=True
)

for cap, score in sorted_caps:

    recommendation = ""

    if score >= 100:
        recommendation = "🔥 ALTÍSSIMO POTENCIAL COMERCIAL"

    elif score >= 50:
        recommendation = "⚡ ALTO POTENCIAL"

    elif score >= 20:
        recommendation = "🟢 POTENCIAL MÉDIO"

    else:
        recommendation = "⚪ BAIXO POTENCIAL"

    report["economic_opportunities"].append({
        "capability": cap,
        "score": score,
        "recommendation": recommendation
    })

# ============================================================
# EXPORT JSON
# ============================================================

with open(OUTPUT_JSON, "w", encoding="utf-8") as f:
    json.dump(report, f, indent=4, ensure_ascii=False)

# ============================================================
# EXPORT TXT
# ============================================================

with open(OUTPUT_TXT, "w", encoding="utf-8") as f:

    f.write("\n")
    f.write("====================================================\n")
    f.write(" IOTEC - RELATÓRIO DE CAPACIDADES ECONÔMICAS\n")
    f.write("====================================================\n\n")

    f.write(f"ROOT: {ROOT_DIR}\n")
    f.write(f"ARQUIVOS ESCANEADOS: {report['files_scanned']}\n")
    f.write(f"GERADO EM: {report['generated_at']}\n\n")

    f.write("====================================================\n")
    f.write(" OPORTUNIDADES ECONÔMICAS\n")
    f.write("====================================================\n\n")

    for opp in report["economic_opportunities"]:

        f.write(f"CAPACIDADE: {opp['capability']}\n")
        f.write(f"SCORE: {opp['score']}\n")
        f.write(f"STATUS: {opp['recommendation']}\n")
        f.write("\n")

    f.write("====================================================\n")
    f.write(" CAPACIDADES DETECTADAS\n")
    f.write("====================================================\n\n")

    for cap in report["capabilities"]:

        f.write(f"ARQUIVO: {cap['file']}\n")

        for finding in cap["findings"]:

            f.write(f"  -> {finding['capability']}\n")
            f.write(f"     KEYWORDS: {finding['keywords']}\n")
            f.write(f"     SCORE: {finding['score']}\n")

        f.write("\n")

print("\n================================================")
print(" 🧠 IOTEC SONDA FINALIZADA")
print("================================================")
print(f" Arquivos escaneados: {report['files_scanned']}")
print(f" Relatório JSON: {OUTPUT_JSON}")
print(f" Relatório TXT : {OUTPUT_TXT}")
print("================================================\n")