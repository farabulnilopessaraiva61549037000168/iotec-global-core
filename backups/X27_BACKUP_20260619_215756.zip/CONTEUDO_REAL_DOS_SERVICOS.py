﻿<script>
// ===============================
// CONTEÃšDO REAL DOS SERVIÃ‡OS
// ===============================

function abrirServico(nome) {

    let conteudo = "";

    if (nome.includes("auditoria")) {
        conteudo = `
        <h1>Auditoria TecnolÃ³gica</h1>
        <p>DiagnÃ³stico completo da infraestrutura digital.</p>
        <ul>
            <li>AnÃ¡lise de sistemas</li>
            <li>Mapeamento de falhas</li>
            <li>Plano de otimizaÃ§Ã£o</li>
        </ul>
        `;
    }

    else if (nome.includes("pericia")) {
        conteudo = `
        <h1>PerÃ­cia TÃ©cnica Judicial</h1>
        <p>Laudos tÃ©cnicos para processos judiciais.</p>
        `;
    }

    else if (nome.includes("desenvol")) {
        conteudo = `
        <h1>Desenvolvimento Sob Medida</h1>
        <p>Sistemas personalizados para sua empresa.</p>
        `;
    }

    else if (nome.includes("seguran")) {
        conteudo = `
        <h1>SeguranÃ§a da InformaÃ§Ã£o</h1>
        <p>ProteÃ§Ã£o completa de dados e sistemas.</p>
        `;
    }

    else if (nome.includes("dados") || nome.includes("business")) {
        conteudo = `
        <h1>Business Intelligence</h1>
        <p>AnÃ¡lise estratÃ©gica de dados.</p>
        `;
    }

    abrirPainel(conteudo);
}

// ATIVA TODOS OS "SAIBA MAIS"
document.querySelectorAll("a, button").forEach(el => {

    el.addEventListener("click", function(e) {

        let texto = (this.innerText || "").toLowerCase();

        if (texto.includes("saiba")) {
            e.preventDefault();
            abrirServico(texto);
        }

    });

});
</script>

