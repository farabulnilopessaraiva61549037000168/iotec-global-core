﻿[
  {
    "nome": "Financeiro",
    "arquivo": "financeiro.html",
    "tipo": "pagamento"
  },
  {
    "nome": "Pedidos",
    "arquivo": "pedidos.html",
    "tipo": "pedido"
  }
]

