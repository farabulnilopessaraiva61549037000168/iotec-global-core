import json

ARQUIVO = "IOTEC_PIPELINE_DATABASE.json"

with open(
    ARQUIVO,
    "r",
    encoding="utf-8"
) as f:

    dados = json.load(f)

print("")
print("===================================")
print("IOTEC PIPELINE INSPECTOR")
print("===================================")

for lead in dados["leads"]:

    print("")
    print("-----------------------------------")
    print(lead["id"])
    print("-----------------------------------")

    propostas = [

        p for p in dados["propostas"]

        if p.get("lead_id")
        ==
        lead["id"]
    ]

    if not propostas:

        print("SEM PROPOSTA")
        continue

    for proposta in propostas:

        print("↓")
        print(proposta["id"])

        contratos = [

            c for c in dados["contratos"]

            if c.get("proposta_id")
            ==
            proposta["id"]
        ]

        if not contratos:

            print("↓")
            print("SEM CONTRATO")
            continue

        for contrato in contratos:

            print("↓")
            print(contrato["id"])

            receitas = [

                r for r in dados["receita"]

                if r.get("contrato_id")
                ==
                contrato["id"]
            ]

            if not receitas:

                print("↓")
                print("SEM RECEITA")
                continue

            for receita in receitas:

                print("↓")
                print(receita["id"])

print("")
print("INSPECAO FINALIZADA")