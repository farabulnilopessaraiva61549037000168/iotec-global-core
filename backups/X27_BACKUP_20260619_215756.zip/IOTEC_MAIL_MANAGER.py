﻿# ============================================================
# IOTEC_MAIL_MANAGER.py
# Monitoramento + limpeza + organizaÃ§Ã£o de e-mails
# ============================================================

import imaplib
import email
from email.header import decode_header

EMAIL = "seu@gmail.com"
SENHA = "senha_app"
IMAP = "imap.gmail.com"

# =========================
# CLASSIFICAÃ‡ÃƒO SIMPLES
# =========================

def classificar(assunto):

    assunto = assunto.lower()

    if "paypal" in assunto or "payment" in assunto:
        return "FINANCEIRO"

    if "formulÃ¡rio" in assunto or "analysis" in assunto:
        return "CLIENTE"

    if "promo" in assunto or "newsletter" in assunto:
        return "SPAM"

    return "OUTROS"

# =========================
# ORGANIZAÃ‡ÃƒO
# =========================

def organizar_email(mail, num, tipo):

    if tipo == "SPAM":
        mail.copy(num, "Spam")

    elif tipo == "CLIENTE":
        mail.copy(num, "Processados")

    elif tipo == "FINANCEIRO":
        mail.copy(num, "Financeiro")

    # marca como lido
    mail.store(num, '+FLAGS', '\\Seen')

# =========================
# MONITORAMENTO
# =========================

def monitorar():

    mail = imaplib.IMAP4_SSL(IMAP)
    mail.login(EMAIL, SENHA)
    mail.select("inbox")

    status, mensagens = mail.search(None, "UNSEEN")
    mensagens = mensagens[0].split()

    for num in mensagens:

        status, msg_data = mail.fetch(num, "(RFC822)")
        msg = email.message_from_bytes(msg_data[0][1])

        assunto, enc = decode_header(msg["Subject"])[0]
        if isinstance(assunto, bytes):
            assunto = assunto.decode(enc if enc else "utf-8")

        tipo = classificar(assunto)

        print("ðŸ“© Novo:", assunto, "| Tipo:", tipo)

        organizar_email(mail, num, tipo)

# =========================
# EXECUÃ‡ÃƒO
# =========================

if __name__ == "__main__":
    monitorar()

