# ==========================================================
# IOTEC ALMA CORE v3
# CONSOLIDADOR DA TORRE
# Clusterização + Detecção de duplicidade + Sugestão estrutural
# ==========================================================

import os
from pathlib import Path
from collections import defaultdict, Counter
from datetime import datetime

ROOT_DIR = Path.cwd()

# ----------------------------------------------------------
# MAPA BASE DE SETORES
# ----------------------------------------------------------
SETOR_MAPA = {
    "presidencia": ["core", "master", "central", "admin", "orchestrator"],
    "recepcao": ["portal", "ui", "frontend", "html", "interface"],
    "producao": ["pipeline", "engine", "worker", "automation", "build"],
    "atendimento": ["chat", "client", "ticket", "support", "msg"],
    "dados": ["json", "csv", "data", "analytics", "report"],
    "documentos": ["pdf", "doc", "contract", "proposal"],
    "almoxarifado": ["backup", "legacy", "old", "archive", "dump"],
}

# ----------------------------------------------------------
# CLASSIFICADOR BASE
# ----------------------------------------------------------
def classificar(nome: str):
    n = nome.lower()

    for setor, palavras in SETOR_MAPA.items():
        for p in palavras:
            if p in n:
                return setor

    return "desconhecido"


# ----------------------------------------------------------
# ESCANEAMENTO COMPLETO
# ----------------------------------------------------------
def escanear():
    inventario = defaultdict(list)

    for root, _, files in os.walk(ROOT_DIR):
        for f in files:
            caminho = str(Path(root) / f)
            setor = classificar(f)
            inventario[setor].append(caminho)

    return inventario


# ----------------------------------------------------------
# DETECÇÃO DE DUPLICADOS (por nome base)
# ----------------------------------------------------------
def detectar_duplicados(inventario):
    nomes = []

    for itens in inventario.values():
        for path in itens:
            nomes.append(os.path.basename(path))

    contagem = Counter(nomes)

    duplicados = {k: v for k, v in contagem.items() if v > 1}

    return duplicados


# ----------------------------------------------------------
# CLUSTERIZAÇÃO DE CAOS (DESCONHECIDO)
# ----------------------------------------------------------
def cluster_desconhecido(inventario):
    grupos = defaultdict(list)

    for path in inventario.get("desconhecido", []):
        nome = os.path.basename(path).lower()

        # cluster simples por prefixo
        chave = nome[:3]
        grupos[chave].append(path)

    return grupos


# ----------------------------------------------------------
# SUGESTÃO DE CONSOLIDAÇÃO
# ----------------------------------------------------------
def sugerir_consolidacao(duplicados):
    sugestoes = []

    for nome, qtd in duplicados.items():
        if qtd > 5:
            sugestoes.append(f"🔴 CONSOLIDAR URGENTE: {nome} ({qtd} cópias)")
        elif qtd > 2:
            sugestoes.append(f"🟠 POSSÍVEL DUPLICAÇÃO: {nome} ({qtd})")

    return sugestoes


# ----------------------------------------------------------
# MAPA DE SAÚDE ESTRUTURAL
# ----------------------------------------------------------
def relatorio(inventario):
    total = sum(len(v) for v in inventario.values())

    duplicados = detectar_duplicados(inventario)
    clusters = cluster_desconhecido(inventario)
    sugestoes = sugerir_consolidacao(duplicados)

    print("\n====================================")
    print("🧠 IOTEC ALMA CORE v3 - CONSOLIDAÇÃO")
    print("====================================\n")

    print(f"📦 TOTAL DE ATIVOS: {total}")
    print(f"🔁 ITENS DUPLICADOS: {len(duplicados)}\n")

    print("📌 ALERTAS DE CONSOLIDAÇÃO:")
    if sugestoes:
        for s in sugestoes:
            print(" ", s)
    else:
        print(" ✔ Nenhuma duplicação crítica detectada")

    print("\n🧩 CLUSTERS DE DESCONHECIDO:")
    for k, v in list(clusters.items())[:10]:
        print(f" - Grupo '{k}': {len(v)} itens")

    print("\n====================================")
    print(f"Timestamp: {datetime.now()}")
    print("====================================\n")


# ----------------------------------------------------------
# CORE
# ----------------------------------------------------------
def alma_core_v3():
    print("🧠 ALMA CORE v3 INICIADO - MODO CONSOLIDADOR\n")

    inventario = escanear()
    relatorio(inventario)

    print("✔ Consolidação concluída.")


# ----------------------------------------------------------
# EXECUÇÃO
# ----------------------------------------------------------
if __name__ == "__main__":
    alma_core_v3()