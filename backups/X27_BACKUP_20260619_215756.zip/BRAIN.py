﻿# =========================================================
# IOTEC EXECUTION BRAIN
# MAPA VIVO DE EXECUÃ‡ÃƒO REAL DO NÃšCLEO
# =========================================================

import os
import ast
import json
from collections import defaultdict

ROOT = input("Caminho do nÃºcleo: ").strip()

# =========================================================
# FILTROS
# =========================================================

IGNORE_DIRS = [
    "venv",
    "__pycache__",
    "site-packages",
    "dist-packages",
    "node_modules",
    ".git"
]

ENTRY_KEYWORDS = [
    "app",
    "main",
    "boot",
    "start",
    "run",
    "api",
    "server",
    "router",
    "core",
    "engine",
    "orchestrator"
]

# =========================================================
# ESTRUTURAS
# =========================================================

graph = defaultdict(set)
reverse_graph = defaultdict(set)

runtime_candidates = []
dead_modules = []
entrypoints = []

# =========================================================
# UTILIDADES
# =========================================================

def valid_path(path):
    low = path.lower()

    return not any(x in low for x in IGNORE_DIRS)


def module_name(path):
    return os.path.splitext(os.path.basename(path))[0]


# =========================================================
# EXTRAÃ‡ÃƒO AST
# =========================================================

def extract_calls(file_path):
    calls = set()
    imports = set()

    try:
        with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
            tree = ast.parse(f.read())

        for node in ast.walk(tree):

            # imports
            if isinstance(node, ast.Import):
                for n in node.names:
                    imports.add(n.name.split(".")[0])

            elif isinstance(node, ast.ImportFrom):
                if node.module:
                    imports.add(node.module.split(".")[0])

            # chamadas
            elif isinstance(node, ast.Call):

                if isinstance(node.func, ast.Name):
                    calls.add(node.func.id)

                elif isinstance(node.func, ast.Attribute):
                    calls.add(node.func.attr)

        return imports, calls

    except:
        return set(), set()


# =========================================================
# SCAN
# =========================================================

print("\n[EXECUTION BRAIN] Escaneando nÃºcleo...\n")

all_files = []

for root, dirs, files in os.walk(ROOT):

    dirs[:] = [d for d in dirs if valid_path(d)]

    for file in files:

        if not file.endswith(".py"):
            continue

        full = os.path.join(root, file)

        if not valid_path(full):
            continue

        all_files.append(full)

# =========================================================
# BUILD GRAPH
# =========================================================

for file in all_files:

    current = module_name(file)

    imports, calls = extract_calls(file)

    for i in imports:
        graph[current].add(i)
        reverse_graph[i].add(current)

    score = len(imports) + len(calls)

    if score >= 10:
        runtime_candidates.append((current, score))

    if score == 0:
        dead_modules.append(current)

    if any(k in current.lower() for k in ENTRY_KEYWORDS):
        entrypoints.append(current)

# =========================================================
# RANKING
# =========================================================

runtime_candidates.sort(key=lambda x: x[1], reverse=True)

top_runtime = runtime_candidates[:25]

# =========================================================
# DETECTAR CÃ‰REBRO CENTRAL
# =========================================================

brain_score = []

for node in graph:

    outgoing = len(graph[node])
    incoming = len(reverse_graph[node])

    total = outgoing + incoming

    brain_score.append((node, total))

brain_score.sort(key=lambda x: x[1], reverse=True)

# =========================================================
# EXPORT
# =========================================================

report = {
    "total_modules": len(all_files),
    "brain": brain_score[:20],
    "runtime_candidates": top_runtime,
    "entrypoints": entrypoints[:50],
    "dead_modules": dead_modules[:50],
    "connections": {
        k: list(v)
        for k, v in graph.items()
    }
}

with open(
    "IOTEC_EXECUTION_BRAIN_REPORT.json",
    "w",
    encoding="utf-8"
) as f:
    json.dump(report, f, indent=2)

# =========================================================
# OUTPUT
# =========================================================

print("=======================================")
print(" IOTEC EXECUTION BRAIN")
print("=======================================\n")

print("ðŸ§  CÃ‰REBRO OPERACIONAL:\n")

for node, score in brain_score[:15]:
    print(f"{node} -> {score} conexÃµes")

print("\nðŸ”¥ MÃ“DULOS MAIS EXECUTÃVEIS:\n")

for node, score in top_runtime:
    print(f"{node} -> score {score}")

print("\nðŸšª ENTRYPOINTS:\n")

for e in entrypoints[:20]:
    print(e)

print("\nðŸ§Š POSSÃVEIS MÃ“DULOS MORTOS:\n")

for d in dead_modules[:20]:
    print(d)

print("\n=======================================")
print("ANÃLISE FINALIZADA")
print("=======================================\n")

print("RelatÃ³rio salvo:")
print("IOTEC_EXECUTION_BRAIN_REPORT.json")
