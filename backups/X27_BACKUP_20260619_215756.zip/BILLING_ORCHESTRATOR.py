# BILLING_ORCHESTRATOR.py
#
# ORQUESTRADOR DE FATURAMENTO IOTEC
#
# Fluxo:
#
# PROPOSTA APROVADA
#      ↓
# FATURA 30%
#      ↓
# PAGAMENTO 30%
#      ↓
# LIBERA PROJETO
#      ↓
# FATURA 70%
#      ↓
# PAGAMENTO FINAL
#      ↓
# CLIENTE PREMIUM

import sqlite3
from datetime import datetime

DB = r"C:\IOTEC_OMEGA_X\backend\iotec.db"

conn = sqlite3.connect(DB)
cur = conn.cursor()

# ==================================================
# SCHEMA
# ==================================================

campos = [

    ("invoice30_value","REAL"),
    ("invoice70_value","REAL"),

    ("invoice30_status","TEXT"),
    ("invoice70_status","TEXT"),

    ("invoice30_date","TEXT"),
    ("invoice70_date","TEXT")

]

for campo,tipo in campos:

    try:

        cur.execute(
            f"""
            ALTER TABLE pipeline
            ADD COLUMN {campo} {tipo}
            """
        )

        print("[OK]",campo)

    except:

        print("[EXISTE]",campo)

# ==================================================
# GERAR FATURAS
# ==================================================

aprovados = cur.execute("""

SELECT

opportunity_id,
proposal_value

FROM pipeline

WHERE status='PAGAMENTO_PENDENTE'

""").fetchall()

gerados = 0

for op_id,valor in aprovados:

    entrada = round(valor * 0.30,2)

    final = round(valor * 0.70,2)

    cur.execute("""

    UPDATE pipeline

    SET

    invoice30_value=?,
    invoice70_value=?,

    invoice30_status='AGUARDANDO',

    invoice70_status='BLOQUEADA',

    invoice30_date=?

    WHERE opportunity_id=?

    """,(

        entrada,
        final,
        datetime.now().strftime(
            "%d/%m/%Y %H:%M:%S"
        ),
        op_id

    ))

    gerados += 1

conn.commit()
conn.close()

print("")
print("===================================")
print("BILLING ORCHESTRATOR")
print("===================================")
print("")
print("FATURAS GERADAS:", gerados)
print("")