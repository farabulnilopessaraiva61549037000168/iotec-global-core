﻿"""
====================================================
IOTEC AI CORE ENGINE v1.0
Sistema de OrquestraÃ§Ã£o de InteligÃªncia Educacional
====================================================
Autor: NÃºcleo IoTec EDU
FunÃ§Ã£o: CÃ©rebro central do ecossistema de IA
====================================================
"""

