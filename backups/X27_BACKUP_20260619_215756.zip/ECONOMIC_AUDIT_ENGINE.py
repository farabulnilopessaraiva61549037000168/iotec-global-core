import os
import json
from pathlib import Path

ROOTS = [
    r"C:\IOTEC",
    str(Path.home() / "Downloads"),
    str(Path.home() / "Desktop")
]

KEYWORDS = {

    "AI_AUTOMATION": [
        "automation",
        "workflow",
        "pipeline",
        "agent",
        "ai"
    ],

    "ANALYTICS": [
        "analytics",
        "dashboard",
        "metric",
        "report",
        "business"
    ],

    "MONITORING": [
        "monitor",
        "alert",
        "tracking",
        "tower"
    ],

    "DEPLOY": [
        "deploy",
        "server",
        "cloud",
        "hosting"
    ],

    "OCR": [
        "ocr",
        "document",
        "pdf",
        "image"
    ]

}

results = []

def classify(name):

    lower = name.lower()

    best = "UNCLASSIFIED"
    score = 0

    for category, words in KEYWORDS.items():

        current = 0

        for word in words:

            if word in lower:
                current += 10

        if current > score:
            score = current
            best = category

    return best, score

def scan():

    for root in ROOTS:

        if not os.path.exists(root):
            continue

        for path, dirs, files in os.walk(root):

            for file in files:

                category, score = classify(file)

                if score > 0:

                    results.append({

                        "file": file,
                        "path": os.path.join(path, file),
                        "category": category,
                        "score": score

                    })

scan()

results.sort(
    key=lambda x: x["score"],
    reverse=True
)

with open(
    "ECONOMIC_AUDIT_REPORT.json",
    "w",
    encoding="utf-8"
) as f:

    json.dump(
        results,
        f,
        indent=4,
        ensure_ascii=False
    )

print("")
print("====================================")
print(" ECONOMIC AUDIT COMPLETED ")
print("====================================")
print("ITEMS FOUND :", len(results))
print("REPORT      : ECONOMIC_AUDIT_REPORT.json")
print("====================================")