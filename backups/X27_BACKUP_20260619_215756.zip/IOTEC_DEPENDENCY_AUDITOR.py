import ast
import json
from pathlib import Path
from datetime import datetime

ROOT = Path(r"C:\IOTEC")

relatorio = {
    "data": str(datetime.now()),
    "arquivos": {},
    "isolados": [],
    "mais_importados": {},
    "erros": []
}

# -----------------------------
# EXTRAI IMPORTS
# -----------------------------

def extrair_imports(arquivo):

    try:

        with open(
            arquivo,
            "r",
            encoding="utf-8",
            errors="ignore"
        ) as f:

            codigo = f.read()

        arvore = ast.parse(codigo)

        imports = []

        for node in ast.walk(arvore):

            if isinstance(node, ast.Import):

                for n in node.names:

                    imports.append(n.name)

            elif isinstance(node, ast.ImportFrom):

                if node.module:

                    imports.append(node.module)

        return imports

    except Exception as e:

        relatorio["erros"].append({
            "arquivo": arquivo.name,
            "erro": str(e)
        })

        return []

# -----------------------------
# MAPA DE ARQUIVOS
# -----------------------------

arquivos_py = list(ROOT.rglob("*.py"))

nomes = {}

for arq in arquivos_py:

    nomes[arq.stem] = arq.name

# -----------------------------
# ANALISA
# -----------------------------

contador_importados = {}

for arq in arquivos_py:

    imports = extrair_imports(arq)

    internos = []

    for item in imports:

        base = item.split(".")[0]

        if base in nomes:

            internos.append(base)

            contador_importados[base] = (
                contador_importados.get(base, 0) + 1
            )

    relatorio["arquivos"][arq.stem] = {
        "imports": internos,
        "quantidade": len(internos)
    }

# -----------------------------
# ISOLADOS
# -----------------------------

for motor, dados in relatorio["arquivos"].items():

    if dados["quantidade"] == 0:

        relatorio["isolados"].append(motor)

# -----------------------------
# MAIS IMPORTADOS
# -----------------------------

ordenado = sorted(
    contador_importados.items(),
    key=lambda x: x[1],
    reverse=True
)

for nome, qtd in ordenado[:100]:

    relatorio["mais_importados"][nome] = qtd

# -----------------------------
# RESUMO
# -----------------------------

relatorio["resumo"] = {

    "total_python":
        len(arquivos_py),

    "isolados":
        len(relatorio["isolados"]),

    "mais_importados":
        len(relatorio["mais_importados"]),

    "erros":
        len(relatorio["erros"])
}

# -----------------------------
# SALVAR
# -----------------------------

saida = ROOT / "IOTEC_DEPENDENCY_REPORT.json"

with open(
    saida,
    "w",
    encoding="utf-8"
) as f:

    json.dump(
        relatorio,
        f,
        indent=4,
        ensure_ascii=False
    )

print("\nDEPENDENCY AUDIT FINALIZADO\n")

print(json.dumps(
    relatorio["resumo"],
    indent=4,
    ensure_ascii=False
))

print(
    f"\nRELATÓRIO: {saida}"
)