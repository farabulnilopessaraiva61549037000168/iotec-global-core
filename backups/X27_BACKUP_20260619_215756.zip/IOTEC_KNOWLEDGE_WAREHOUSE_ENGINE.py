# ==========================================================
# IOTEC KNOWLEDGE WAREHOUSE ENGINE
# ARMAZÉM CENTRAL DE CONHECIMENTO
# ==========================================================

import sqlite3
import json
from datetime import datetime

DB = r"C:\IOTEC\IOTEC_KNOWLEDGE_WAREHOUSE.db"

conn = sqlite3.connect(DB)
cur = conn.cursor()

# ==========================================================
# CONHECIMENTO BRUTO
# ==========================================================

cur.execute("""

CREATE TABLE IF NOT EXISTS warehouse (

    id INTEGER PRIMARY KEY AUTOINCREMENT,

    timestamp TEXT,

    source_motor TEXT,

    category TEXT,

    title TEXT,

    content TEXT,

    relevance INTEGER,

    value_score INTEGER,

    status TEXT

)

""")

# ==========================================================
# RESERVATÓRIOS
# ==========================================================

cur.execute("""

CREATE TABLE IF NOT EXISTS reservoirs (

    id INTEGER PRIMARY KEY AUTOINCREMENT,

    timestamp TEXT,

    reservoir TEXT,

    source_motor TEXT,

    item_id INTEGER,

    value_score INTEGER

)

""")

# ==========================================================
# CAPACIDADES
# ==========================================================

cur.execute("""

CREATE TABLE IF NOT EXISTS capabilities (

    id INTEGER PRIMARY KEY AUTOINCREMENT,

    timestamp TEXT,

    capability TEXT,

    source TEXT,

    maturity INTEGER,

    economic_value INTEGER

)

""")

conn.commit()

# ==========================================================
# CARREGA TORRE
# ==========================================================

MASTER_FILE = r"C:\IOTEC\IOTEC_MASTER_TOWER.json"

with open(
    MASTER_FILE,
    "r",
    encoding="utf-8"
) as f:

    tower = json.load(f)

# ==========================================================
# REGISTRO INICIAL
# ==========================================================

timestamp = str(datetime.now())

seed_data = [

    (
        tower["master_brain"],
        "BRAIN",
        "MASTER BRAIN ONLINE",
        "Cérebro mestre conectado ao Warehouse",
        100,
        100
    ),

    (
        tower["unified_brain"],
        "BRAIN",
        "UNIFIED BRAIN ONLINE",
        "Cérebro unificado conectado ao Warehouse",
        90,
        90
    ),

    (
        tower["control_tower"],
        "CONTROL",
        "CONTROL TOWER ONLINE",
        "Torre operacional conectada",
        95,
        95
    ),

    (
        tower["memory"],
        "MEMORY",
        "MEMORY ONLINE",
        "Memória central conectada",
        85,
        85
    )

]

for item in seed_data:

    cur.execute("""

    INSERT INTO warehouse (

        timestamp,
        source_motor,
        category,
        title,
        content,
        relevance,
        value_score,
        status

    )

    VALUES (

        ?,?,?,?,?,?,?,?

    )

    """,

    (

        timestamp,
        item[0],
        item[1],
        item[2],
        item[3],
        item[4],
        item[5],
        "ACTIVE"

    ))

conn.commit()

# ==========================================================
# RESUMO
# ==========================================================

warehouse_count = cur.execute(
    "SELECT COUNT(*) FROM warehouse"
).fetchone()[0]

print("")
print("===================================")
print("IOTEC KNOWLEDGE WAREHOUSE")
print("===================================")

print("")
print("ITENS NO ARMAZEM:", warehouse_count)

print("")
print("MASTER BRAIN:")
print(tower["master_brain"])

print("")
print("UNIFIED BRAIN:")
print(tower["unified_brain"])

print("")
print("CONTROL TOWER:")
print(tower["control_tower"])

print("")
print("MEMORY:")
print(tower["memory"])

print("")
print("DATABASE:")
print(DB)

print("")
print("CONCLUIDO")

conn.close()