def main():

    artemis_scan()

    generate_proposal(

        cliente="MUNICIPIO_EXEMPLO",

        problema="CONTINUIDADE_OPERACIONAL",

        pessoas_afetadas=25000,

        prejuizo_estimado=5000000,

        criticidade=8

    )

if __name__ == "__main__":
    main()