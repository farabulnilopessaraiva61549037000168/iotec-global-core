import sqlite3

DB = r"C:\IOTEC_OMEGA_X\backend\iotec.db"

conn = sqlite3.connect(DB)
cur = conn.cursor()

print("")
print("======================================================")
print("IOTEC COMMERCIAL EXECUTIVE REPORT")
print("======================================================")
print("")

# ======================================================
# EMPRESAS ANALISADAS
# ======================================================

try:

    empresas = cur.execute("""

    SELECT COUNT(*)

    FROM commercial_opportunities

    """).fetchone()[0]

except:

    empresas = 0

# ======================================================
# RECEITA POTENCIAL
# ======================================================

try:

    receita = cur.execute("""

    SELECT IFNULL(
        SUM(estimated_value),
        0
    )

    FROM commercial_opportunities

    """).fetchone()[0]

except:

    receita = 0

# ======================================================
# STATUS
# ======================================================

status_list = [

    "NOVA",
    "EM_ANALISE",
    "PROPOSTA_ENVIADA",
    "NEGOCIACAO",
    "PAGAMENTO_PENDENTE",
    "CLIENTE_ATIVO"

]

status_count = {}

for s in status_list:

    try:

        qtd = cur.execute("""

        SELECT COUNT(*)

        FROM commercial_opportunities

        WHERE status=?

        """,(s,)).fetchone()[0]

    except:

        qtd = 0

    status_count[s] = qtd

# ======================================================
# CLIENTES ATIVOS DO PIPELINE
# ======================================================

try:

    clientes_ativos = cur.execute("""

    SELECT COUNT(*)

    FROM pipeline

    WHERE status='CLIENTE_ATIVO'

    """).fetchone()[0]

except:

    clientes_ativos = 0

# ======================================================
# PROJETOS LIBERADOS
# ======================================================

try:

    projetos = cur.execute("""

    SELECT COUNT(*)

    FROM pipeline

    WHERE status='PROJETO_LIBERADO'

    """).fetchone()[0]

except:

    projetos = 0

# ======================================================
# TAXA DE CONVERSAO
# ======================================================

if empresas > 0:

    conversao = (
        clientes_ativos / empresas
    ) * 100

else:

    conversao = 0

# ======================================================
# RELATORIO
# ======================================================

print(f"EMPRESAS ANALISADAS: {empresas}")
print("")

print("RECEITA POTENCIAL:")
print(f"R$ {receita:,.2f}")
print("")

print("STATUS COMERCIAIS")
print("------------------------------")

for k,v in status_count.items():

    print(f"{k}: {v}")

print("")

print(f"CLIENTES ATIVOS: {clientes_ativos}")
print(f"PROJETOS LIBERADOS: {projetos}")

print("")

print(
    f"TAXA DE CONVERSAO: "
    f"{conversao:.2f}%"
)

print("")
print("======================================================")

conn.close()