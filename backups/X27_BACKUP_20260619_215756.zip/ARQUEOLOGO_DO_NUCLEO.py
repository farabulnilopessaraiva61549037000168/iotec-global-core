# ============================================================
# IOTEC OMEGA X
# TORRE DE CONTROLE OFICIAL
# ============================================================
#
# FUNÇÃO:# ============================================================
# IOTEC OMEGA X
# ARQUEÓLOGO DO NÚCLEO
# ============================================================
#
# FUNÇÃO:
# Fazer levantamento completo do núcleo sem modificar nada.
#
# O QUE ELE FAZ:
# - Conta arquivos Python
# - Localiza bancos de dados
# - Localiza inventários
# - Localiza APIs e configs
# - Localiza dashboards
# - Gera relatório consolidado
#
# OBS:
# SOMENTE LEITURA
# NÃO APAGA
# NÃO ALTERA
# NÃO INSTALA
# ============================================================

from pathlib import Path
from datetime import datetime
import json

ROOT = Path("C:/IOTEC")

CATEGORIAS = {
    "python": [".py"],
    "database": [".db", ".sqlite", ".sqlite3"],
    "config": [".json", ".yaml", ".yml", ".ini", ".env"],
    "documentos": [".txt", ".md", ".pdf"],
    "planilhas": [".xlsx", ".csv"],
}

PALAVRAS_CHAVE = [
    "inventario",
    "arqueologia",
    "capacidade",
    "nucleo",
    "ecosystem",
    "dashboard",
    "radar",
    "torre",
    "controle",
    "scanner",
    "audit",
]

resultado = {
    "data": str(datetime.now()),
    "raiz": str(ROOT),
    "arquivos": {},
    "inventarios": [],
}

for categoria, extensoes in CATEGORIAS.items():

    encontrados = []

    for ext in extensoes:
        encontrados.extend(ROOT.rglob(f"*{ext}"))

    resultado["arquivos"][categoria] = len(encontrados)

inventarios = []

for arquivo in ROOT.rglob("*"):

    if not arquivo.is_file():
        continue

    nome = arquivo.name.lower()

    for palavra in PALAVRAS_CHAVE:

        if palavra in nome:

            inventarios.append(str(arquivo))
            break

resultado["inventarios"] = inventarios

print("\n")
print("=" * 70)
print("ARQUEÓLOGO DO NÚCLEO")
print("=" * 70)

for categoria, quantidade in resultado["arquivos"].items():

    print(
        f"{categoria.upper():20} : {quantidade}"
    )

print("-" * 70)

print(
    f"INVENTÁRIOS ENCONTRADOS : {len(resultado['inventarios'])}"
)

print("=" * 70)

saida = ROOT / "RELATORIO_ARQUEOLOGIA_NUCLEO.json"

with open(saida, "w", encoding="utf-8") as f:
    json.dump(
        resultado,
        f,
        indent=4,
        ensure_ascii=False
    )

print("\nRELATÓRIO GERADO:")
print(saida)

print("\nARQUIVOS DE INVENTÁRIO ENCONTRADOS:\n")

for item in inventarios[:100]:
    print(item)

print("\nFINALIZADO.")
# Supervisão operacional do núcleo.
#
# RESPONSABILIDADES:
# - Monitorar oportunidades reais
# - Monitorar contratos
# - Monitorar receita
# - Monitorar produção
# - Monitorar entregas
# - Monitorar comunicação
# - Monitorar rastreabilidade
# - Detectar falhas e gargalos
#
# REGRA FUNDAMENTAL:
# Nenhum dado exibido deverá ser simulado.
# Todos os dados devem ser provenientes de eventos
# efetivamente registrados no núcleo.
#
# ============================================================

from dataclasses import dataclass
from datetime import datetime
from typing import Optional


@dataclass
class Oportunidade:

    id: str
    instituicao: str
    setor: str

    descricao: str

    valor_estimado: float

    origem: str

    status: str

    criado_em: datetime


@dataclass
class Contrato:

    id: str

    oportunidade_id: str

    cliente: str

    valor: float

    status: str

    criado_em: datetime


@dataclass
class Projeto:

    id: str

    contrato_id: str

    responsavel: str

    status: str

    progresso: int

    criado_em: datetime


class TorreControle:

    def __init__(self):

        self.oportunidades = []

        self.contratos = []

        self.projetos = []

    # --------------------------------------------------------

    def registrar_oportunidade(self, oportunidade):

        self.oportunidades.append(oportunidade)

    # --------------------------------------------------------

    def registrar_contrato(self, contrato):

        self.contratos.append(contrato)

    # --------------------------------------------------------

    def registrar_projeto(self, projeto):

        self.projetos.append(projeto)

    # --------------------------------------------------------

    def receita_confirmada(self):

        total = 0

        for contrato in self.contratos:

            if contrato.status == "ATIVO":

                total += contrato.valor

        return total

    # --------------------------------------------------------

    def painel(self):

        print("\n")
        print("=" * 70)
        print("IOTEC - TORRE DE CONTROLE OFICIAL")
        print("=" * 70)

        print(
            f"OPORTUNIDADES........: {len(self.oportunidades)}"
        )

        print(
            f"CONTRATOS............: {len(self.contratos)}"
        )

        print(
            f"PROJETOS.............: {len(self.projetos)}"
        )

        print(
            f"RECEITA CONFIRMADA...: R$ {self.receita_confirmada():,.2f}"
        )

        print("=" * 70)


if __name__ == "__main__":

    torre = TorreControle()

    torre.painel()