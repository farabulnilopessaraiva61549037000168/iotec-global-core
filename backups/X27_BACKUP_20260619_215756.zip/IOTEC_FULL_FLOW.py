﻿import urllib.parse

# =========================
# GERAR WHATSAPP
# =========================

def gerar_link(nome, telefone, servico):

    mensagem = f"""
OlÃ¡ {nome},

Recebemos sua solicitaÃ§Ã£o sobre:
{servico}

Responda com o nÃºmero da opÃ§Ã£o:

1 - Iniciar anÃ¡lise
2 - Tirar dÃºvidas
3 - Acompanhar pedido
4 - Suporte tÃ©cnico
"""

    texto = urllib.parse.quote(mensagem)

    return f"https://wa.me/55{telefone}?text={texto}"

# =========================
# IA - INTERPRETAÃ‡ÃƒO
# =========================

def interpretar(msg):

    msg = msg.lower()

    if "1" in msg:
        return "ANALISE"
    elif "2" in msg:
        return "DUVIDA"
    elif "3" in msg:
        return "STATUS"
    elif "4" in msg:
        return "SUPORTE"

    return "GERAL"

# =========================
# IA - RESPOSTA
# =========================

def responder(tipo, nome, servico):

    respostas = {
        "ANALISE": f"{nome}, iniciando anÃ¡lise do seu caso ({servico}).",
        "DUVIDA": f"{nome}, descreva sua dÃºvida que eu te ajudo.",
        "STATUS": f"{nome}, sua solicitaÃ§Ã£o estÃ¡ em andamento.",
        "SUPORTE": f"{nome}, descreva o problema tÃ©cnico.",
        "GERAL": f"{nome}, escolha uma opÃ§Ã£o para continuar."
    }

    return respostas.get(tipo)

# =========================
# SIMULAÃ‡ÃƒO DE FLUXO
# =========================

cliente = {
    "nome": "Bruno",
    "telefone": "88999999999",
    "servico": "AnÃ¡lise financeira"
}

link = gerar_link(cliente["nome"], cliente["telefone"], cliente["servico"])

print("ðŸ“² WhatsApp:", link)

# SimulaÃ§Ã£o de resposta do cliente
msg = "1"

tipo = interpretar(msg)
resposta = responder(tipo, cliente["nome"], cliente["servico"])

print("ðŸ¤– IA:", resposta)

