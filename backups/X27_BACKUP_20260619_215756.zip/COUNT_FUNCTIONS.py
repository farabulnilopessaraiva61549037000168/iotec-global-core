import os
import re

ROOT = r"C:\IOTEC"

ranking = []

for root, dirs, files in os.walk(ROOT):

    if any(x in root.lower() for x in [
        "venv",
        "node_modules",
        "__pycache__",
        "duplicados"
    ]):
        continue

    for file in files:

        if not file.endswith(".py"):
            continue

        path = os.path.join(root, file)

        try:
            with open(path,"r",encoding="utf-8",errors="ignore") as f:
                content = f.read()

            funcs = re.findall(
                r"def\s+[a-zA-Z0-9_]+\s*\(",
                content
            )

            ranking.append(
                (len(funcs), file, path)
            )

        except:
            pass

ranking.sort(reverse=True)

for qty, file, path in ranking[:100]:
    print(qty, file)