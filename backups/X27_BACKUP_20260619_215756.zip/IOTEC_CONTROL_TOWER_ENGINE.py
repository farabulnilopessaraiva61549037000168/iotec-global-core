﻿# =========================================================
# FILE: IOTEC_CONTROL_TOWER_ENGINE.py
# =========================================================
# IOTEC GLOBAL CONTROL TOWER
# =========================================================
# LANGUAGE : PYTHON 3.x
# =========================================================

import os
import time
import random
from datetime import datetime

# =========================================================
# SYSTEM CONFIGURATION
# =========================================================

CORE_NAME = "IOTEC"
CORE_VERSION = "1.0.0"

# =========================================================
# STATUS COLORS
# =========================================================

STATUS_GREEN = "ONLINE"
STATUS_YELLOW = "WARNING"
STATUS_RED = "CRITICAL"

# =========================================================
# SYSTEM SERVICES
# =========================================================

SYSTEM_SERVICES = {

    "INTERNET": STATUS_GREEN,
    "AI_ORCHESTRATOR": STATUS_GREEN,
    "DATABASE": STATUS_GREEN,
    "PAYPAL_GATEWAY": STATUS_GREEN,
    "STRIPE_GATEWAY": STATUS_GREEN,
    "EMAIL_ENGINE": STATUS_GREEN,
    "MEDIA_DISTRIBUTION": STATUS_GREEN,
    "AWS_INFRASTRUCTURE": STATUS_GREEN,
    "WEB_PIPELINES": STATUS_GREEN,
    "CLIENT_TRACKING": STATUS_GREEN,
    "GLOBAL_DISTRIBUTION": STATUS_GREEN,
    "LEGAL_PROTECTION": STATUS_GREEN,
    "REPORT_ENGINE": STATUS_GREEN,
    "BACKUP_SYSTEM": STATUS_GREEN
}

# =========================================================
# ERROR DATABASE
# =========================================================

ERROR_DATABASE = []

# =========================================================
# CONTROL TOWER ENGINE
# =========================================================

class ControlTowerEngine:

    def __init__(self):

        self.system_online = False

    # =====================================================
    # INITIALIZE CONTROL TOWER
    # =====================================================

    def initialize_control_tower(self):

        print("=" * 60)
        print(f"{CORE_NAME} CONTROL TOWER")
        print("=" * 60)

        print("[CONTROL] Starting operational systems")

        time.sleep(1)

        self.system_online = True

        print("[CONTROL] Control tower online")

    # =====================================================
    # SYSTEM STATUS MONITOR
    # =====================================================

    def monitor_systems(self):

        print("\n" + "=" * 60)
        print("SYSTEM STATUS")
        print("=" * 60)

        for service in SYSTEM_SERVICES:

            failure_probability = random.randint(1, 100)

            if failure_probability > 92:

                SYSTEM_SERVICES[service] = STATUS_RED

                self.register_error(
                    service,
                    "Critical operational failure detected"
                )

            elif failure_probability > 80:

                SYSTEM_SERVICES[service] = STATUS_YELLOW

            else:

                SYSTEM_SERVICES[service] = STATUS_GREEN

            print(
                f"{service:<25} "
                f"STATUS: {SYSTEM_SERVICES[service]}"
            )

    # =====================================================
    # ERROR REGISTRATION
    # =====================================================

    def register_error(
        self,
        service,
        message
    ):

        error = {

            "timestamp": str(datetime.now()),
            "service": service,
            "message": message,
            "resolved": False
        }

        ERROR_DATABASE.append(error)

    # =====================================================
    # DISPLAY ERRORS
    # =====================================================

    def display_errors(self):

        print("\n" + "=" * 60)
        print("ERROR CHANNEL")
        print("=" * 60)

        unresolved = [
            error for error in ERROR_DATABASE
            if not error["resolved"]
        ]

        if not unresolved:

            print("[CONTROL] No active operational errors")

        else:

            for index, error in enumerate(unresolved):

                print(
                    f"[{index}] "
                    f"{error['service']} "
                    f"| {error['message']}"
                )

    # =====================================================
    # RESOLVE ERROR
    # =====================================================

    def resolve_error(self, index):

        unresolved = [
            error for error in ERROR_DATABASE
            if not error["resolved"]
        ]

        if index < len(unresolved):

            unresolved[index]["resolved"] = True

            service = unresolved[index]["service"]

            SYSTEM_SERVICES[service] = STATUS_GREEN

            print(
                f"[CONTROL] Error resolved: {service}"
            )

    # =====================================================
    # GLOBAL WEB STATUS
    # =====================================================

    def global_web_status(self):

        print("\n" + "=" * 60)
        print("GLOBAL WEB STATUS")
        print("=" * 60)

        online_services = sum(
            1 for status in SYSTEM_SERVICES.values()
            if status == STATUS_GREEN
        )

        total_services = len(SYSTEM_SERVICES)

        print(
            f"Operational services: "
            f"{online_services}/{total_services}"
        )

        if online_services == total_services:

            print(
                "[GLOBAL] ALL SYSTEMS GREEN"
            )

            print(
                "[GLOBAL] WEB OPERATION ACTIVE"
            )

        else:

            print(
                "[GLOBAL] Operational attention required"
            )

    # =====================================================
    # OPERATIONAL DASHBOARD
    # =====================================================

    def operational_dashboard(self):

        print("\n" + "=" * 60)
        print("OPERATIONAL DASHBOARD")
        print("=" * 60)

        print(
            f"Timestamp: {datetime.now()}"
        )

        print(
            f"Core: {CORE_NAME}"
        )

        print(
            f"Version: {CORE_VERSION}"
        )

        print(
            f"Status: "
            f"{'ONLINE' if self.system_online else 'OFFLINE'}"
        )

# =========================================================
# MAIN EXECUTION
# =========================================================

if __name__ == "__main__":

    tower = ControlTowerEngine()

    tower.initialize_control_tower()

    while True:

        tower.operational_dashboard()

        tower.monitor_systems()

        tower.display_errors()

        tower.global_web_status()

        unresolved = [
            error for error in ERROR_DATABASE
            if not error["resolved"]
        ]

        if unresolved:

            tower.resolve_error(0)

        time.sleep(5)

