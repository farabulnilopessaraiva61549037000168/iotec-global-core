﻿# ============================================================
# IOTEC_CUSTOMER_SERVICE_CORE.py
# ============================================================
# NÃšCLEO DE ATENDIMENTO COMERCIAL
# ============================================================
# OBJETIVO:
# ------------------------------------------------------------
# Este nÃºcleo Ã© EXCLUSIVAMENTE responsÃ¡vel por:
#
# - atendimento
# - vendas
# - apresentaÃ§Ã£o de catÃ¡logo
# - demonstraÃ§Ã£o de serviÃ§os
# - investigaÃ§Ã£o do cliente
# - geraÃ§Ã£o de proposta
# - formalizaÃ§Ã£o financeira
# - confirmaÃ§Ã£o de pagamento
# - acompanhamento operacional
# - entrega do projeto
#
# ESTE NÃšCLEO NÃƒO EXPÃ•E:
# - mapas econÃ´micos
# - inteligÃªncia interna
# - sentinelas
# - metas financeiras
# - cartografia estratÃ©gica
#
# ============================================================

import time
from dataclasses import dataclass, field
from typing import List, Dict

# ============================================================
# CATÃLOGO PÃšBLICO
# ============================================================

PUBLIC_CATALOG = {

    "AutomaÃ§Ã£o Empresarial": {
        "descricao": "AutomaÃ§Ã£o de processos operacionais.",
        "valor_base": 15000
    },

    "ERP Empresarial": {
        "descricao": "Sistema completo de gestÃ£o empresarial.",
        "valor_base": 35000
    },

    "Dashboard Inteligente": {
        "descricao": "Painel analÃ­tico e operacional.",
        "valor_base": 12000
    },

    "Sistema Industrial": {
        "descricao": "Monitoramento industrial automatizado.",
        "valor_base": 45000
    },

    "Sistema JurÃ­dico": {
        "descricao": "GestÃ£o processual e jurÃ­dica.",
        "valor_base": 25000
    },

    "Sistema Educacional": {
        "descricao": "GestÃ£o escolar e pedagÃ³gica.",
        "valor_base": 18000
    },

    "Sistema Hospitalar": {
        "descricao": "GestÃ£o clÃ­nica e hospitalar.",
        "valor_base": 50000
    }
}

# ============================================================
# ESTRUTURAS
# ============================================================

@dataclass
class Client:

    nome: str
    email: str
    empresa: str


@dataclass
class Order:

    servico: str
    descricao: str
    valor: float
    entrada: float
    restante: float
    status: str = "AGUARDANDO PAGAMENTO"

# ============================================================
# NÃšCLEO DE ATENDIMENTO
# ============================================================

class IOTECCustomerService:

    def __init__(self):

        self.client = None
        self.order = None
        self.payment_confirmed = False

    # ========================================================
    # IA VISUAL
    # ========================================================

    def think(self, text):

        print(f"\n[IOTEC AI] {text}")

        time.sleep(1)

    # ========================================================
    # APRESENTAÃ‡ÃƒO
    # ========================================================

    def welcome(self):

        print("\n================================================")
        print("            IOTEC GLOBAL PLATFORM")
        print("================================================")

        self.think(
            "Bem-vindo ao nÃºcleo inteligente de atendimento."
        )

    # ========================================================
    # COLETAR CLIENTE
    # ========================================================

    def collect_client_data(self):

        print("\n================ CLIENTE ================")

        nome = input("\nNome: ")

        email = input("\nE-mail: ")

        empresa = input("\nEmpresa: ")

        self.client = Client(
            nome=nome,
            email=email,
            empresa=empresa
        )

    # ========================================================
    # MOSTRAR CATÃLOGO
    # ========================================================

    def show_catalog(self):

        print("\n================ CATÃLOGO ================")

        for index, item in enumerate(PUBLIC_CATALOG.keys(), start=1):

            print(f"\n{index} - {item}")

    # ========================================================
    # EXPLICAR SERVIÃ‡O
    # ========================================================

    def explain_service(self, service):

        data = PUBLIC_CATALOG[service]

        self.think(
            f"Apresentando soluÃ§Ã£o: {service}"
        )

        print(f"\nSERVIÃ‡O: {service}")

        print(f"\nDESCRIÃ‡ÃƒO:")
        print(data["descricao"])

        print(f"\nVALOR BASE:")
        print(f"R$ {data['valor_base']:,.2f}")

    # ========================================================
    # INVESTIGAÃ‡ÃƒO
    # ========================================================

    def investigate(self):

        print("\n================ INVESTIGAÃ‡ÃƒO ================")

        setor = input(
            "\nQual Ã© o setor da empresa?\n\n>>> "
        )

        problema = input(
            "\nQuais problemas enfrenta atualmente?\n\n>>> "
        )

        objetivo = input(
            "\nQual Ã© o principal objetivo?\n\n>>> "
        )

        usuarios = input(
            "\nQuantas pessoas utilizarÃ£o o sistema?\n\n>>> "
        )

        self.think(
            "Analisando contexto operacional..."
        )

        print("\n================ DIAGNÃ“STICO ================")

        print(f"\nSETOR: {setor}")
        print(f"\nPROBLEMA: {problema}")
        print(f"\nOBJETIVO: {objetivo}")
        print(f"\nUSUÃRIOS: {usuarios}")

    # ========================================================
    # GERAR PEDIDO
    # ========================================================

    def create_order(self, service):

        valor = PUBLIC_CATALOG[service]["valor_base"]

        entrada = valor * 0.30

        restante = valor * 0.70

        self.order = Order(

            servico=service,
            descricao=PUBLIC_CATALOG[service]["descricao"],
            valor=valor,
            entrada=entrada,
            restante=restante
        )

    # ========================================================
    # FORMALIZAÃ‡ÃƒO
    # ========================================================

    def formalize(self):

        print("\n================ PROPOSTA ================")

        print(f"\nCLIENTE: {self.client.nome}")

        print(f"\nEMPRESA: {self.client.empresa}")

        print(f"\nSERVIÃ‡O: {self.order.servico}")

        print(f"\nDESCRIÃ‡ÃƒO:")
        print(self.order.descricao)

        print(f"\nVALOR TOTAL:")
        print(f"R$ {self.order.valor:,.2f}")

        print(f"\nENTRADA OPERACIONAL 30%:")
        print(f"R$ {self.order.entrada:,.2f}")

        print(f"\nRESTANTE 70%:")
        print(f"R$ {self.order.restante:,.2f}")

    # ========================================================
    # PAGAMENTO
    # ========================================================

    def request_payment(self):

        self.think(
            "Para continuarmos o atendimento, Ã© necessÃ¡rio confirmar o pagamento da entrada operacional."
        )

        print("\n================ PAGAMENTO ================")

        print("\nMÃ‰TODOS DISPONÃVEIS:")

        print("\n- PayPal")
        print("- PIX")
        print("- Stripe")
        print("- TransferÃªncia")

        confirmation = input(
            "\nPagamento confirmado?\n\n>>> "
        ).lower()

        if confirmation in ["sim", "s"]:

            self.payment_confirmed = True

            self.order.status = "PAGAMENTO CONFIRMADO"

            self.think(
                "Pagamento confirmado com sucesso."
            )

        else:

            self.payment_confirmed = False

            self.order.status = "AGUARDANDO PAGAMENTO"

            self.think(
                "Atendimento pausado atÃ© confirmaÃ§Ã£o financeira."
            )

    # ========================================================
    # PRODUÃ‡ÃƒO
    # ========================================================

    def production_pipeline(self):

        if not self.payment_confirmed:

            self.think(
                "ProduÃ§Ã£o bloqueada."
            )

            return

        print("\n================ PRODUÃ‡ÃƒO ================")

        steps = [

            "Criando arquitetura",
            "Gerando banco de dados",
            "Configurando backend",
            "Construindo frontend",
            "Gerando APIs",
            "Configurando dashboards",
            "Executando validaÃ§Ãµes",
            "Preparando entrega"
        ]

        for step in steps:

            self.think(step)

        self.order.status = "PROJETO FINALIZADO"

    # ========================================================
    # ENTREGA
    # ========================================================

    def delivery(self):

        if self.order.status != "PROJETO FINALIZADO":

            self.think(
                "Projeto ainda nÃ£o finalizado."
            )

            return

        print("\n================ ENTREGA ================")

        print("\nSTATUS:")
        print("PROJETO ENTREGUE")

        print("\nVERIFICAÃ‡ÃƒO:")
        print("ValidaÃ§Ã£o operacional concluÃ­da.")

        print("\nSUPORTE:")
        print("Sistema monitorado pela IA.")

    # ========================================================
    # FLUXO PRINCIPAL
    # ========================================================

    def start(self):

        self.welcome()

        self.collect_client_data()

        self.show_catalog()

        service_names = list(PUBLIC_CATALOG.keys())

        choice = int(
            input(
                "\nEscolha um serviÃ§o:\n\n>>> "
            )
        )

        selected_service = service_names[choice - 1]

        self.explain_service(selected_service)

        self.investigate()

        self.create_order(selected_service)

        self.formalize()

        self.request_payment()

        if not self.payment_confirmed:

            return

        self.production_pipeline()

        self.delivery()

# ============================================================
# EXECUÃ‡ÃƒO
# ============================================================

if __name__ == "__main__":

    system = IOTECCustomerService()

    system.start()

