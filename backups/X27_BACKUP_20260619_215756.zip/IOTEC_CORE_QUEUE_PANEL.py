﻿# ============================================================
# IOTEC_CORE_QUEUE_PANEL.py
# Painel central de clientes (fila + prioridade + auditoria)
# ============================================================

import streamlit as st

st.set_page_config(layout="wide")

st.title("ðŸ§  IOTEC - Central de OperaÃ§Ãµes")
st.subheader("Fila Inteligente de Clientes")

# =========================
# BANCO SIMPLES (memÃ³ria)
# =========================

if "clientes" not in st.session_state:
    st.session_state.clientes = []

if "historico" not in st.session_state:
    st.session_state.historico = []

# =========================
# ADICIONAR CLIENTE (simulaÃ§Ã£o)
# =========================

def adicionar_cliente(nome, prioridade, servico):

    st.session_state.clientes.append({
        "nome": nome,
        "prioridade": prioridade,
        "servico": servico,
        "status": "ATIVO"
    })

# =========================
# ORDENAÃ‡ÃƒO
# =========================

def ordenar():

    prioridade_map = {
        "ALTA": 1,
        "MEDIA": 2,
        "BAIXA": 3
    }

    st.session_state.clientes.sort(
        key=lambda x: prioridade_map[x["prioridade"]]
    )

# =========================
# CONCLUIR CLIENTE
# =========================

def concluir(index):

    cliente = st.session_state.clientes.pop(index)

    # envia para auditoria
    st.session_state.historico.append(cliente)

# =========================
# INTERFACE
# =========================

st.markdown("### âž• Novo Cliente")

nome = st.text_input("Nome")
prioridade = st.selectbox("Prioridade", ["ALTA", "MEDIA", "BAIXA"])
servico = st.text_input("ServiÃ§o")

if st.button("Adicionar Cliente"):
    adicionar_cliente(nome, prioridade, servico)

ordenar()

# =========================
# FILA ATIVA
# =========================

st.markdown("### ðŸ“‹ Fila Ativa")

for i, c in enumerate(st.session_state.clientes):

    col1, col2, col3, col4 = st.columns([3,2,2,1])

    col1.write(f"ðŸ‘¤ {c['nome']}")
    col2.write(f"ðŸ”¥ {c['prioridade']}")
    col3.write(f"ðŸ’¼ {c['servico']}")

    if col4.button("âœ… Concluir", key=i):
        concluir(i)

# =========================
# HISTÃ“RICO (AUDITORIA)
# =========================

st.markdown("### ðŸ§¾ Auditoria / HistÃ³rico")

for h in st.session_state.historico:
    st.write(f"âœ”ï¸ {h['nome']} - {h['servico']}")

