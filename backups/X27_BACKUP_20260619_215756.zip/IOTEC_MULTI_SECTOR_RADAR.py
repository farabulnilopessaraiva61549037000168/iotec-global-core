﻿# ============================================================
# IOTEC_MULTI_SECTOR_RADAR.py
# Radar multissetorial de oportunidades
# ============================================================

import streamlit as st

st.set_page_config(layout="wide")

st.title("ðŸ§  IOTEC - Radar Multissetorial")
st.subheader("Mapa inteligente de oportunidades por setor")

# =========================
# BASE DE LEADS (exemplo)
# =========================

if "leads" not in st.session_state:
    st.session_state.leads = [
        {"setor": "PÃºblico", "entidade": "Prefeitura X", "score": 32},
        {"setor": "PME", "entidade": "Empresa Y", "score": 18},
        {"setor": "Agro", "entidade": "Fazenda Z", "score": 25},
        {"setor": "Tech", "entidade": "Startup A", "score": 12},
        {"setor": "MÃ­dia", "entidade": "Produtora B", "score": 8},
    ]

# =========================
# CLASSIFICAÃ‡ÃƒO
# =========================

def classificar(score):
    if score >= 30:
        return "ðŸ”´ Alta"
    elif score >= 20:
        return "ðŸŸ¡ MÃ©dia"
    else:
        return "âšª Baixa"

# =========================
# AGRUPAR POR SETOR
# =========================

setores = {}

for lead in st.session_state.leads:
    setor = lead["setor"]
    if setor not in setores:
        setores[setor] = []
    setores[setor].append(lead)

# =========================
# EXIBIÃ‡ÃƒO
# =========================

st.markdown("### ðŸŒ Setores Monitorados")

cols = st.columns(len(setores))

for i, (setor, leads) in enumerate(setores.items()):
    with cols[i]:
        st.markdown(f"## {setor}")

        for l in leads:
            prioridade = classificar(l["score"])

            st.markdown(f"""
            ---
            **ðŸ¢ {l['entidade']}**  
            Score: {l['score']}  
            Prioridade: {prioridade}
            """)

# =========================
# RESUMO GERAL
# =========================

st.markdown("### ðŸ“Š Resumo do Radar")

total = len(st.session_state.leads)
alta = len([l for l in st.session_state.leads if l["score"] >= 30])
media = len([l for l in st.session_state.leads if 20 <= l["score"] < 30])
baixa = len([l for l in st.session_state.leads if l["score"] < 20])

col1, col2, col3, col4 = st.columns(4)

col1.metric("Total", total)
col2.metric("Alta Prioridade", alta)
col3.metric("MÃ©dia", media)
col4.metric("Baixa", baixa)

