﻿def verificar_pergunta(msg):

    msg = msg.lower()

    palavras_bloqueadas = [
        "como foi feito",
        "como funciona o sistema",
        "cÃ³digo",
        "api",
        "arquitetura",
        "como vocÃªs fazem",
        "backend",
        "nÃºcleo"
    ]

    for p in palavras_bloqueadas:
        if p in msg:
            return "BLOQUEADO"

    return "PERMITIDO"

