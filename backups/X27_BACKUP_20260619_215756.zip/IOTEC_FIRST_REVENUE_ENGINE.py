﻿# =========================================================
# FILE: IOTEC_FIRST_REVENUE_ENGINE.py
# =========================================================
# IOTEC FIRST REVENUE ENGINE
# =========================================================
# OBJETIVO:
# PRIMEIRO VAGÃƒO REAL DE MONETIZAÃ‡ÃƒO
# =========================================================
# FUNÃ‡Ã•ES:
# - LANDING PAGE
# - FORMULÃRIO DE CLIENTE
# - CAPTAÃ‡ÃƒO DE LEADS
# - CLASSIFICAÃ‡ÃƒO DE SERVIÃ‡OS
# - PRIORIDADE
# - PAINEL ADMIN
# - GERAÃ‡ÃƒO DE IDs
# - OPERAÃ‡ÃƒO SEMI-AUTOMÃTICA
# - PREPARAÃ‡ÃƒO PARA RECORRÃŠNCIA
# =========================================================
# LANGUAGE : PYTHON 3.x
# =========================================================

from flask import Flask, request, jsonify

import sqlite3
import uuid

from datetime import datetime

# =========================================================
# CORE CONFIGURATION
# =========================================================

CORE_NAME = "IOTEC"
CORE_VERSION = "1.0"

DATABASE = "iotec_revenue.db"

# =========================================================
# FLASK
# =========================================================

app = Flask(__name__)

# =========================================================
# DATABASE INITIALIZATION
# =========================================================

def initialize_database():

    connection = sqlite3.connect(DATABASE)

    cursor = connection.cursor()

    cursor.execute("""

        CREATE TABLE IF NOT EXISTS leads (

            id TEXT PRIMARY KEY,
            timestamp TEXT,
            company_name TEXT,
            client_name TEXT,
            email TEXT,
            service_type TEXT,
            budget REAL,
            priority TEXT,
            status TEXT

        )

    """)

    connection.commit()

    connection.close()

# =========================================================
# PRIORITY ENGINE
# =========================================================

def calculate_priority(budget):

    if budget >= 20000:
        return "CRITICAL"

    elif budget >= 10000:
        return "HIGH"

    elif budget >= 5000:
        return "MEDIUM"

    return "NORMAL"

# =========================================================
# SERVICE CLASSIFIER
# =========================================================

def classify_service(service):

    service = service.lower()

    if "automation" in service:
        return "AUTOMATION"

    if "dashboard" in service:
        return "BUSINESS_DASHBOARD"

    if "education" in service:
        return "EDUCATION"

    if "document" in service:
        return "DOCUMENT_AUTOMATION"

    if "ai" in service:
        return "AI_SYSTEM"

    return "GENERAL"

# =========================================================
# LANDING PAGE
# =========================================================

@app.route("/")
def home():

    return """

    <html>

    <head>

        <title>IOTEC</title>

        <style>

            body {

                background-color: #0f1115;
                color: white;
                font-family: Arial;
                padding: 40px;

            }

            h1 {

                font-size: 60px;

            }

            p {

                font-size: 22px;

            }

            .container {

                max-width: 900px;
                margin: auto;

            }

            .button {

                background: #ffffff;
                color: black;
                padding: 15px;
                border-radius: 10px;
                text-decoration: none;
                font-weight: bold;

            }

        </style>

    </head>

    <body>

        <div class="container">

            <h1>IOTEC</h1>

            <p>
            Adaptive Technology Ecosystem
            </p>

            <p>
            Automation, dashboards, AI systems,
            educational systems and digital operations.
            </p>

            <a class="button" href="/lead-form">
                REQUEST A SYSTEM
            </a>

        </div>

    </body>

    </html>

    """

# =========================================================
# LEAD FORM
# =========================================================

@app.route("/lead-form")
def lead_form():

    return """

    <html>

    <body style='font-family:Arial;padding:40px;'>

        <h1>REQUEST A SYSTEM</h1>

        <form action='/submit-lead' method='post'>

            <input name='company_name'
            placeholder='Company Name'
            required><br><br>

            <input name='client_name'
            placeholder='Your Name'
            required><br><br>

            <input name='email'
            placeholder='Email'
            required><br><br>

            <input name='service_type'
            placeholder='Service Type'
            required><br><br>

            <input name='budget'
            placeholder='Estimated Budget'
            required><br><br>

            <button type='submit'>
                SEND REQUEST
            </button>

        </form>

    </body>

    </html>

    """

# =========================================================
# SUBMIT LEAD
# =========================================================

@app.route("/submit-lead", methods=["POST"])
def submit_lead():

    company_name = request.form["company_name"]

    client_name = request.form["client_name"]

    email = request.form["email"]

    service_type = request.form["service_type"]

    budget = float(request.form["budget"])

    lead_id = str(uuid.uuid4())

    timestamp = str(datetime.now())

    priority = calculate_priority(budget)

    classified_service = classify_service(service_type)

    status = "RECEIVED"

    connection = sqlite3.connect(DATABASE)

    cursor = connection.cursor()

    cursor.execute("""

        INSERT INTO leads VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)

    """, (

        lead_id,
        timestamp,
        company_name,
        client_name,
        email,
        classified_service,
        budget,
        priority,
        status

    ))

    connection.commit()

    connection.close()

    print("=" * 60)
    print("[NEW LEAD RECEIVED]")
    print("=" * 60)

    print(f"Lead ID      : {lead_id}")
    print(f"Company      : {company_name}")
    print(f"Client       : {client_name}")
    print(f"Service      : {classified_service}")
    print(f"Budget       : {budget}")
    print(f"Priority     : {priority}")

    return f"""

    <html>

    <body style='font-family:Arial;padding:40px;'>

        <h1>REQUEST RECEIVED</h1>

        <p>Your request has been successfully received.</p>

        <p><strong>ID:</strong> {lead_id}</p>

        <p>
        Our operational core will analyze your request.
        </p>

    </body>

    </html>

    """

# =========================================================
# ADMIN PANEL
# =========================================================

@app.route("/admin")
def admin():

    connection = sqlite3.connect(DATABASE)

    cursor = connection.cursor()

    cursor.execute("""

        SELECT * FROM leads
        ORDER BY budget DESC

    """)

    data = cursor.fetchall()

    connection.close()

    html = """

    <html>

    <body style='font-family:Arial;padding:40px;'>

        <h1>IOTEC ADMIN PANEL</h1>

        <table border='1' cellpadding='10'>

            <tr>

                <th>Company</th>
                <th>Client</th>
                <th>Service</th>
                <th>Budget</th>
                <th>Priority</th>
                <th>Status</th>

            </tr>

    """

    for item in data:

        html += f"""

        <tr>

            <td>{item[2]}</td>
            <td>{item[3]}</td>
            <td>{item[5]}</td>
            <td>{item[6]}</td>
            <td>{item[7]}</td>
            <td>{item[8]}</td>

        </tr>

        """

    html += """

        </table>

    </body>

    </html>

    """

    return html

# =========================================================
# CORE STATUS
# =========================================================

@app.route("/status")
def status():

    return jsonify({

        "core": CORE_NAME,
        "version": CORE_VERSION,
        "status": "ONLINE",
        "mode": "FIRST_REVENUE_ENGINE"

    })

# =========================================================
# MAIN EXECUTION
# =========================================================

if __name__ == "__main__":

    initialize_database()

    print("=" * 60)
    print("IOTEC FIRST REVENUE ENGINE")
    print("=" * 60)

    print("[CORE] DATABASE ONLINE")
    print("[CORE] LANDING PAGE ONLINE")
    print("[CORE] LEAD SYSTEM ONLINE")
    print("[CORE] ADMIN PANEL ONLINE")
    print("[CORE] READY FOR FIRST CLIENTS")

    app.run(
        host="0.0.0.0",
        port=5000,
        debug=False, use_reloader=False
    )


