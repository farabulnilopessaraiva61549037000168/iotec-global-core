# ============================================================
# 🧠 IOTEC CAPABILITY HUNTER
# ARQUEOLOGIA DE CAPACIDADES DO NÚCLEO
# ============================================================
# OBJETIVO:
# Vasculhar o núcleo IOTEC em busca de:
# - produtos ocultos
# - automações
# - dashboards
# - APIs
# - IA
# - pipelines
# - sistemas vendáveis
#
# MODO:
# SOMENTE LEITURA
# (não altera, não move e não apaga arquivos)
# ============================================================

import os
import json
from collections import defaultdict
from datetime import datetime

# ============================================================
# CONFIG
# ============================================================

ROOT_PATH = r"C:\IOTEC"

EXTENSOES_ANALISADAS = [
    ".py",
    ".js",
    ".ts",
    ".html",
    ".json",
    ".md"
]

# ============================================================
# PALAVRAS-CHAVE DE CAPACIDADE
# ============================================================

CAPACIDADES = {
    "dashboard": [
        "dashboard",
        "analytics",
        "plotly",
        "grafico",
        "chart",
        "painel"
    ],

    "api": [
        "flask",
        "fastapi",
        "endpoint",
        "api",
        "router"
    ],

    "automacao": [
        "automation",
        "bot",
        "whatsapp",
        "selenium",
        "playwright",
        "scraping"
    ],

    "ia": [
        "openai",
        "llm",
        "gpt",
        "neural",
        "ai",
        "machine learning"
    ],

    "pdf_relatorio": [
        "pdf",
        "report",
        "relatorio",
        "xlsx",
        "planilha"
    ],

    "frontend": [
        "react",
        "html",
        "css",
        "frontend",
        "interface",
        "ui"
    ],

    "dados": [
        "pandas",
        "numpy",
        "csv",
        "json",
        "sqlite",
        "database"
    ],

    "pipeline": [
        "pipeline",
        "engine",
        "workflow",
        "orchestrator"
    ],

    "comercial": [
        "cliente",
        "ticket",
        "orcamento",
        "pedido",
        "contrato"
    ]
}

# ============================================================
# RESULTADOS
# ============================================================

resultados = defaultdict(list)
score_global = defaultdict(int)

# ============================================================
# ANALISADOR
# ============================================================

def analisar_arquivo(path_arquivo):

    try:

        with open(path_arquivo, "r", encoding="utf-8", errors="ignore") as f:
            conteudo = f.read().lower()

        encontrou = []

        for categoria, palavras in CAPACIDADES.items():

            score_local = 0

            for palavra in palavras:

                if palavra.lower() in conteudo:
                    score_local += 1

            if score_local > 0:

                score_global[categoria] += score_local

                encontrou.append({
                    "categoria": categoria,
                    "score": score_local
                })

        return encontrou

    except:
        return []

# ============================================================
# VARREDURA
# ============================================================

print("\n🧠 IOTEC CAPABILITY HUNTER INICIADO")
print("🔎 Vasculhando núcleo...\n")

total_arquivos = 0

for raiz, dirs, arquivos in os.walk(ROOT_PATH):

    for arquivo in arquivos:

        extensao = os.path.splitext(arquivo)[1].lower()

        if extensao in EXTENSOES_ANALISADAS:

            total_arquivos += 1

            caminho = os.path.join(raiz, arquivo)

            capacidades = analisar_arquivo(caminho)

            if capacidades:

                resultados[caminho] = capacidades

# ============================================================
# RELATÓRIO
# ============================================================

print("\n===================================================")
print("🧠 IOTEC - MAPA DE CAPACIDADES")
print("===================================================\n")

print(f"📦 TOTAL ANALISADO: {total_arquivos}\n")

print("🏆 SCORE GLOBAL DE CAPACIDADES:\n")

ranking = sorted(
    score_global.items(),
    key=lambda x: x[1],
    reverse=True
)

for categoria, score in ranking:
    print(f" - {categoria.upper()}: {score}")

print("\n===================================================")
print("📂 CAPACIDADES DETECTADAS")
print("===================================================\n")

contador = 0

for caminho, caps in resultados.items():

    contador += 1

    print(f"\n📄 {caminho}")

    for item in caps:

        print(
            f"   -> {item['categoria'].upper()} "
            f"(score: {item['score']})"
        )

    if contador >= 100:
        print("\n⚠ LIMITE VISUAL ATINGIDO")
        break

# ============================================================
# EXPORTAÇÃO
# ============================================================

export = {
    "timestamp": str(datetime.now()),
    "total_arquivos": total_arquivos,
    "score_global": dict(score_global),
    "resultados": dict(resultados)
}

with open("iotec_capability_map.json", "w", encoding="utf-8") as f:
    json.dump(export, f, indent=4, ensure_ascii=False)

print("\n===================================================")
print("💾 RELATÓRIO SALVO:")
print(" iotec_capability_map.json")
print("===================================================\n")

print("✔ ARQUEOLOGIA CONCLUÍDA")