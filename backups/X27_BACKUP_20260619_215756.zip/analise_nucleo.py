﻿import os

ROOT = "C:/IOTEC"

extensoes = {
    ".py": 0,
    ".js": 0,
    ".html": 0,
    ".css": 0
}

linhas_total = 0
arquivos_total = 0

def contar_linhas(caminho):
    try:
        with open(caminho, "r", encoding="utf-8", errors="ignore") as f:
            return len(f.readlines())
    except:
        return 0

for root, dirs, files in os.walk(ROOT):
    for file in files:
        arquivos_total += 1
        caminho = os.path.join(root, file)

        linhas = contar_linhas(caminho)
        linhas_total += linhas

        for ext in extensoes:
            if file.endswith(ext):
                extensoes[ext] += 1

# ðŸ§  Score tÃ©cnico (simples)
score = (linhas_total / 1000) + (arquivos_total * 0.5)

# ðŸ’° Estimativa de valor (base tÃ©cnica)
valor_usd = score * 50
valor_brl = valor_usd * 5

# ðŸ“„ RELATÃ“RIO
print("\n===== RELATÃ“RIO DO NÃšCLEO IOTEC =====\n")

print(f"Arquivos totais: {arquivos_total}")
print(f"Linhas de cÃ³digo: {linhas_total}\n")

print("DistribuiÃ§Ã£o por tipo:")
for ext, qtd in extensoes.items():
    print(f"{ext}: {qtd}")

print("\nScore tÃ©cnico:", round(score, 2))

print("\nðŸ’° VALUATION ESTIMADO:")
print(f"USD: ${round(valor_usd, 2)}")
print(f"BRL: R$ {round(valor_brl, 2)}")

print("\n====================================\n")

