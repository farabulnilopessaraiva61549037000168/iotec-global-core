﻿import os
import shutil
from openai import OpenAI

client = OpenAI(api_key="SUA_API_KEY")

# =========================
# INTERPRETAR COM IA
# =========================

def interpretar(comando):
    resposta = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[
            {"role": "system", "content": "VocÃª traduz comandos em aÃ§Ãµes tÃ©cnicas em JSON."},
            {"role": "user", "content": comando}
        ]
    )

    return resposta.choices[0].message.content

# =========================
# EXECUTAR AÃ‡Ã•ES
# =========================

def executar(acao_json):
    if "imagens" in acao_json.lower():
        origem = "C:\\IOTEC"
        destino = os.path.join(os.path.expanduser("~"), "Desktop", "interfaces")

        os.makedirs(destino, exist_ok=True)

        for root, dirs, files in os.walk(origem):
            for file in files:
                if file.endswith((".png", ".jpg", ".jpeg", ".webp")):
                    shutil.copy(os.path.join(root, file), destino)

        print("ðŸ“ Imagens organizadas na Ã¡rea de trabalho")

    elif "ligar nucleo" in acao_json.lower():
        print("âš™ï¸ NÃºcleo ativado (simulaÃ§Ã£o)")

    else:
        print("â“ AÃ§Ã£o nÃ£o reconhecida")

# =========================
# LOOP DE CONVERSA
# =========================

while True:
    comando = input("ðŸ§  VocÃª: ")

    if comando.lower() in ["sair", "exit"]:
        break

    acao = interpretar(comando)

    print("ðŸ¤– InterpretaÃ§Ã£o:", acao)

    executar(acao)

