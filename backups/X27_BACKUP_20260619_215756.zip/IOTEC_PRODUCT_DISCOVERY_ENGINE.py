from datetime import datetime

print("")
print("===================================")
print("IOTEC PRODUCT DISCOVERY ENGINE")
print("===================================")

print("")
print("DATA:")
print(datetime.now())

print("")
print("MISSAO:")
print(
    "TRANSFORMAR PROBLEMAS REAIS "
    "EM PRODUTOS MATEMATICOS"
)

REGRAS = [

    "MEDIR",
    "CALCULAR",
    "ESTIMAR",
    "OTIMIZAR",
    "SIMULAR",
    "COMPROVAR"
]

print("")
print("REGRAS FUNDAMENTAIS:")

for regra in REGRAS:

    print(
        "-",
        regra
    )

PROBLEMAS = [

    "ESTIAGEM",

    "ENCHENTE",

    "LOGISTICA",

    "ESTOQUE",

    "RECEITA",

    "TRANSPORTE",

    "ENERGIA",

    "AGRICULTURA",

    "SAUDE",

    "EDUCACAO"
]

print("")
print("PROBLEMAS ANALISAVEIS:")

for item in PROBLEMAS:

    print(
        "-",
        item
    )

print("")
print("PROCESSO DE DESCOBERTA:")

print(
    "PROBLEMA"
)

print("↓")

print(
    "VARIAVEL MENSURAVEL"
)

print("↓")

print(
    "MODELO MATEMATICO"
)

print("↓")

print(
    "SOLUCAO"
)

print("↓")

print(
    "PRODUTO"
)

print("↓")

print(
    "RECEITA"
)

print("")
print("PERGUNTA CENTRAL:")

print(
    "EXISTE ALGUEM DISPOSTO "
    "A PAGAR PARA RESOLVER?"
)

print("")
print("SE SIM:")

print(
    "PRODUTO IDENTIFICADO"
)

print("")
print("CATEGORIAS DE PRODUTOS:")

PRODUTOS = [

    "ANALISE_DE_RISCO",

    "MAPA_DE_VULNERABILIDADE",

    "MODELAGEM_MATEMATICA",

    "PAINEL_EXECUTIVO",

    "SIMULACAO_DE_CENARIOS",

    "PLANO_DE_CONTINGENCIA",

    "OTIMIZACAO_DE_RECURSOS",

    "PROJECAO_FINANCEIRA",

    "ESTUDO_DE_IMPACTO",

    "INTELIGENCIA_ESTRATEGICA"
]

for produto in PRODUTOS:

    print(
        "-",
        produto
    )

print("")
print("ORDEM MOR:")

print(
    "TUDO O QUE PUDER SER "
    "PROVADO MATEMATICAMENTE "
    "PODE SE TORNAR PRODUTO"
)

print("")
print("NUCLEO DE DESCOBERTA ATIVO")