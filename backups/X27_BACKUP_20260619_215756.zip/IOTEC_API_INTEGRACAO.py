﻿# ============================================================
# IOTEC_API_INTEGRACAO.py
# ============================================================

from flask import Flask, request, jsonify
from datetime import datetime

app = Flask(__name__)

# ============================================================
# ROTA PRINCIPAL DO NÚCLEO
# ============================================================

@app.route("/api/iotec", methods=["POST"])
def iotec_core():

    data = request.json

    acao = data.get("acao")
    payload = data.get("payload")
    origem = data.get("origem")

    log = {
        "acao": acao,
        "payload": payload,
        "origem": origem,
        "timestamp": datetime.now().isoformat()
    }

    print("\n[IOTEC RECEBIDO]")
    print(log)

    # ========================================================
    # LÓGICA DO NÚCLEO (EXPANSÍVEL)
    # ========================================================

    if acao == "interacao":
        return jsonify({
            "status": "ok",
            "mensagem": "Interação registrada no núcleo"
        })

    elif acao == "compra":
        return jsonify({
            "status": "ok",
            "mensagem": "Processando pagamento",
            "redirect": payload.get("link_pagamento")
        })

    elif acao == "lead":
        return jsonify({
            "status": "ok",
            "mensagem": "Lead capturado com sucesso"
        })

    else:
        return jsonify({
            "status": "erro",
            "mensagem": "Ação não reconhecida"
        })

# ============================================================
# ROTA DE TESTE
# ============================================================

@app.route("/")
def home():
    return "IOTEC API ONLINE"

# ============================================================
# EXECUÇÃO
# ============================================================

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)

