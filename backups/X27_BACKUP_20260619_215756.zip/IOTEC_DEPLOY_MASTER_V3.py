﻿import os
import shutil
from datetime import datetime

# =========================
# CONFIG
# =========================

DESKTOP = os.path.join(os.path.expanduser("~"), "Desktop")
ORIGEM = os.path.join(DESKTOP, "OFICINA_IOTEC")
DESTINO = os.path.join(os.getcwd(), "IOTEC_RENDER_READY")
STATIC = os.path.join(DESTINO, "static")

# =========================
# LOG
# =========================

def log(msg):
    print(f"[{datetime.now().strftime('%H:%M:%S')}] {msg}")

# =========================
# BUSCAR HTML/HTM
# =========================

def buscar_paginas():
    log("ðŸ” Buscando pÃ¡ginas (.html / .htm)...")

    paginas = []

    for raiz, dirs, arquivos in os.walk(ORIGEM):
        for a in arquivos:
            if a.lower().endswith((".html", ".htm")):
                paginas.append(os.path.join(raiz, a))

    if not paginas:
        raise Exception("âŒ Nenhuma pÃ¡gina HTML/HTM encontrada")

    log(f"âœ” {len(paginas)} pÃ¡ginas encontradas")
    return paginas

# =========================
# PREPARAR PASTA
# =========================

def preparar():
    log("ðŸ“¦ Preparando estrutura...")

    if os.path.exists(DESTINO):
        shutil.rmtree(DESTINO)

    os.makedirs(STATIC)

# =========================
# LIMPAR NOME (IMPORTANTE)
# =========================

def limpar_nome(nome):
    nome = nome.replace(" ", "_")
    nome = nome.replace("â€”", "_")
    nome = nome.replace("Â·", "_")
    return nome

# =========================
# COPIAR E RENOMEAR
# =========================

def copiar_paginas(paginas):
    log("ðŸ“ Copiando e ajustando pÃ¡ginas...")

    nomes = []

    for i, caminho in enumerate(paginas):
        nome_original = os.path.basename(caminho)
        nome_limpo = limpar_nome(nome_original)

        # forÃ§a .html
        if nome_limpo.endswith(".htm"):
            nome_limpo = nome_limpo.replace(".htm", ".html")

        destino_final = os.path.join(STATIC, nome_limpo)
        shutil.copy2(caminho, destino_final)

        nomes.append(nome_limpo)

    return nomes

# =========================
# DEFINIR INDEX
# =========================

def criar_index(nomes):
    log("ðŸ  Criando index.html...")

    index = nomes[0]
    origem = os.path.join(STATIC, index)
    destino = os.path.join(STATIC, "index.html")

    shutil.copy2(origem, destino)

    log(f"âœ” index criado a partir de: {index}")

# =========================
# GERAR FLASK
# =========================

def gerar_app():
    log("âš™ Criando app Flask...")

    codigo = '''from flask import Flask, send_from_directory, request

app = Flask(__name__, static_folder="static")

@app.route("/")
def home():
    return send_from_directory("static", "index.html")

@app.route("/<path:path>")
def arquivos(path):
    return send_from_directory("static", path)

@app.route("/enviar", methods=["POST"])
def enviar():
    nome = request.form.get("nome")
    email = request.form.get("email")
    mensagem = request.form.get("mensagem")

    print("=== NOVO CLIENTE ===")
    print(nome, email, mensagem)

    return "OK"

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=10000)
'''

    with open(os.path.join(DESTINO, "app.py"), "w", encoding="utf-8") as f:
        f.write(codigo)

# =========================
# REQUIREMENTS
# =========================

def gerar_requirements():
    with open(os.path.join(DESTINO, "requirements.txt"), "w") as f:
        f.write("flask\n")

# =========================
# EXECUÃ‡ÃƒO
# =========================

def executar():
    log("ðŸš€ INICIANDO DEPLOY IOTEC V3")

    paginas = buscar_paginas()
    preparar()
    nomes = copiar_paginas(paginas)
    criar_index(nomes)
    gerar_app()
    gerar_requirements()

    log("âœ… PRONTO PARA RENDER")
    log(f"ðŸ“‚ Pasta criada: {DESTINO}")

# =========================

if __name__ == "__main__":
    executar()

