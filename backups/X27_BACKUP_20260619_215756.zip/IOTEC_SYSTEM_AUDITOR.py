import os
import json
import sqlite3
from pathlib import Path
from datetime import datetime

ROOT = Path(r"C:\IOTEC")

relatorio = {
    "data": str(datetime.now()),
    "motores": [],
    "bancos": [],
    "jsons": [],
    "reservatorios": [],
    "duplicados": [],
    "vazios": [],
    "erros": []
}

# ----------------------------------
# PYTHON ENGINES
# ----------------------------------

for arquivo in ROOT.glob("*.py"):

    tamanho = arquivo.stat().st_size

    relatorio["motores"].append({
        "arquivo": arquivo.name,
        "bytes": tamanho
    })

    if tamanho == 0:
        relatorio["vazios"].append(arquivo.name)

# ----------------------------------
# SQLITE
# ----------------------------------

for banco in ROOT.glob("*.db"):

    try:

        conn = sqlite3.connect(banco)

        cursor = conn.cursor()

        cursor.execute("""
        SELECT name
        FROM sqlite_master
        WHERE type='table'
        """)

        tabelas = cursor.fetchall()

        relatorio["bancos"].append({
            "arquivo": banco.name,
            "tabelas": len(tabelas)
        })

        conn.close()

    except Exception as e:

        relatorio["erros"].append({
            "arquivo": banco.name,
            "erro": str(e)
        })

# ----------------------------------
# JSON
# ----------------------------------

for js in ROOT.glob("*.json"):

    try:

        with open(js, "r", encoding="utf-8") as f:

            dados = json.load(f)

        relatorio["jsons"].append({
            "arquivo": js.name,
            "tipo": str(type(dados))
        })

    except Exception as e:

        relatorio["erros"].append({
            "arquivo": js.name,
            "erro": str(e)
        })

# ----------------------------------
# DETECTAR ENGINES
# ----------------------------------

engines = []

for py in ROOT.glob("*.py"):

    nome = py.stem.upper()

    if "ENGINE" in nome:

        engines.append(nome)

contador = {}

for item in engines:

    contador[item] = contador.get(item, 0) + 1

for k, v in contador.items():

    if v > 1:

        relatorio["duplicados"].append({
            "motor": k,
            "quantidade": v
        })

# ----------------------------------
# RESERVATORIOS
# ----------------------------------

for nome in os.listdir(ROOT):

    caminho = ROOT / nome

    if caminho.is_dir():

        try:

            quantidade = len(list(caminho.iterdir()))

            relatorio["reservatorios"].append({
                "nome": nome,
                "itens": quantidade
            })

            if quantidade == 0:

                relatorio["vazios"].append(nome)

        except:
            pass

# ----------------------------------
# RESUMO
# ----------------------------------

relatorio["resumo"] = {

    "motores_total":
        len(relatorio["motores"]),

    "bancos_total":
        len(relatorio["bancos"]),

    "json_total":
        len(relatorio["jsons"]),

    "reservatorios_total":
        len(relatorio["reservatorios"]),

    "erros_total":
        len(relatorio["erros"]),

    "vazios_total":
        len(relatorio["vazios"])
}

saida = ROOT / "IOTEC_SYSTEM_AUDIT_REPORT.json"

with open(saida, "w", encoding="utf-8") as f:

    json.dump(
        relatorio,
        f,
        indent=4,
        ensure_ascii=False
    )

print("\nAUDITORIA CONCLUÍDA\n")
print(json.dumps(relatorio["resumo"], indent=4))
print(f"\nRELATÓRIO: {saida}")