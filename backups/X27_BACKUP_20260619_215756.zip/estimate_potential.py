def estimate_potential():

    potencial_total = 0

    for nome, dados in CAPABILITIES.items():

        valor = dados["valor_medio"]

        potencial_total += valor

    return potencial_total