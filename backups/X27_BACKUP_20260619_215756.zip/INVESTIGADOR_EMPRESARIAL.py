﻿# =========================================================
# IOTEC AI - INVESTIGADOR EMPRESARIAL
# NÃºcleo Inteligente de Levantamento de Requisitos
# =========================================================

class InvestigadorEmpresarial:

    def __init__(self):

        self.dados_cliente = {}

    # =====================================================
    # INICIAR ATENDIMENTO
    # =====================================================

    def iniciar_atendimento(self):

        print("\n[IA] OlÃ¡! Bem-vindo ao sistema inteligente da IOTEC.")
        print("[IA] Vou analisar sua necessidade para montar a melhor soluÃ§Ã£o.\n")

        self.perguntar_setor()
        self.perguntar_problemas()
        self.perguntar_usuarios()
        self.perguntar_recursos()
        self.perguntar_objetivo()

        self.gerar_diagnostico()

    # =====================================================
    # PERGUNTAR SETOR
    # =====================================================

    def perguntar_setor(self):

        print("======================================")
        print("SETOR DA EMPRESA")
        print("======================================")

        setor = input(
            "\n[IA] Qual Ã© o setor da sua empresa?\n"
            "1 - EducaÃ§Ã£o\n"
            "2 - ComÃ©rcio\n"
            "3 - SaÃºde\n"
            "4 - JurÃ­dico\n"
            "5 - Tecnologia\n"
            "6 - Outro\n\n"
            "Digite: "
        )

        setores = {
            "1": "EducaÃ§Ã£o",
            "2": "ComÃ©rcio",
            "3": "SaÃºde",
            "4": "JurÃ­dico",
            "5": "Tecnologia",
            "6": "Outro"
        }

        self.dados_cliente["setor"] = setores.get(setor, "NÃ£o informado")

    # =====================================================
    # PERGUNTAR PROBLEMAS
    # =====================================================

    def perguntar_problemas(self):

        print("\n======================================")
        print("PROBLEMAS ENFRENTADOS")
        print("======================================")

        problemas = input(
            "\n[IA] Quais problemas sua empresa enfrenta atualmente?\n\n"
            "Exemplos:\n"
            "- Falta de organizaÃ§Ã£o\n"
            "- Processos manuais\n"
            "- Controle financeiro\n"
            "- LentidÃ£o operacional\n"
            "- Falta de automaÃ§Ã£o\n\n"
            "Resposta: "
        )

        self.dados_cliente["problemas"] = problemas

    # =====================================================
    # PERGUNTAR USUÃRIOS
    # =====================================================

    def perguntar_usuarios(self):

        print("\n======================================")
        print("USUÃRIOS")
        print("======================================")

        usuarios = input(
            "\n[IA] Quantas pessoas utilizarÃ£o o sistema?\n\n"
            "Resposta: "
        )

        self.dados_cliente["usuarios"] = usuarios

    # =====================================================
    # PERGUNTAR RECURSOS
    # =====================================================

    def perguntar_recursos(self):

        print("\n======================================")
        print("FUNCIONALIDADES")
        print("======================================")

        recursos = input(
            "\n[IA] Quais funcionalidades deseja?\n\n"
            "Exemplos:\n"
            "- Painel administrativo\n"
            "- Controle financeiro\n"
            "- Aplicativo\n"
            "- Dashboard\n"
            "- AutomaÃ§Ã£o\n"
            "- API\n"
            "- WhatsApp\n\n"
            "Resposta: "
        )

        self.dados_cliente["recursos"] = recursos

    # =====================================================
    # PERGUNTAR OBJETIVO
    # =====================================================

    def perguntar_objetivo(self):

        print("\n======================================")
        print("OBJETIVO PRINCIPAL")
        print("======================================")

        objetivo = input(
            "\n[IA] Qual Ã© o principal objetivo do sistema?\n\n"
            "Exemplos:\n"
            "- Automatizar processos\n"
            "- Melhorar gestÃ£o\n"
            "- Reduzir custos\n"
            "- Organizar operaÃ§Ãµes\n"
            "- Melhorar produtividade\n\n"
            "Resposta: "
        )

        self.dados_cliente["objetivo"] = objetivo

    # =====================================================
    # GERAR DIAGNÃ“STICO
    # =====================================================

    def gerar_diagnostico(self):

        print("\n======================================")
        print("DIAGNÃ“STICO INTELIGENTE")
        print("======================================")

        print("\n[IA] Analisando informaÃ§Ãµes do cliente...\n")

        for chave, valor in self.dados_cliente.items():

            print(f"{chave.upper()} -> {valor}")

        print("\n======================================")

        print("[IA] DiagnÃ³stico inicial concluÃ­do.")
        print("[IA] Preparando escopo tÃ©cnico...")
        print("[IA] Encaminhando solicitaÃ§Ã£o ao nÃºcleo operacional...")
        print("[IA] Sistema interno iniciarÃ¡ anÃ¡lise de produÃ§Ã£o.")

# =========================================================
# EXECUÃ‡ÃƒO
# =========================================================

ia = InvestigadorEmpresarial()

ia.iniciar_atendimento()

