﻿# ============================================================
# IOTEC - CONSOLIDADOR E FILTRO PROFISSIONAL
# REGULUS CORE ORGANIZER v2.0
# EMPRESA: IOTEC
# OBJETIVO:
# FILTRAR DEPENDÃŠNCIAS EXTERNAS
# IDENTIFICAR MATRIZES REAIS
# ORGANIZAR O NÃšCLEO PROFISSIONALMENTE
# ============================================================

import os
import json
import shutil
import hashlib
from datetime import datetime
from collections import defaultdict

# ============================================================
# PASTAS ANALISADAS
# ============================================================

PASTAS_ANALISE = [
    r"C:\IOTEC",
    r"C:\Users\Bruno Lopes\Downloads",
    r"C:\Users\Bruno Lopes\Desktop\DIVERSOS",
    r"D:\IOTEC"
]

# ============================================================
# EXTENSÃ•ES IMPORTANTES
# ============================================================

EXTENSOES_VALIDAS = [
    ".py",
    ".html",
    ".css",
    ".js",
    ".json",
    ".tsx",
    ".jsx",
    ".sql"
]

# ============================================================
# PASTAS DE RISCO / DEPENDÃŠNCIAS
# ============================================================

IGNORAR_PASTAS = [

    "site-packages",
    "node_modules",
    "venv",
    "anaconda",
    "Lib",
    "vendor",
    "conda-meta",
    "__pycache__",
    ".git",
    ".idea",
    ".vscode"

]

# ============================================================
# PALAVRAS-CHAVE IOTEC
# ============================================================

PALAVRAS_IOTEC = [

    "iotec",
    "regulus",
    "dashboard",
    "enterprise",
    "govtech",
    "analytics",
    "juris",
    "core",
    "engine",
    "omega",
    "interface",
    "frontend",
    "backend"

]

# ============================================================
# ESTRUTURA CENTRAL
# ============================================================

NUCLEO = {
    "empresa": "IOTEC",
    "cidade": "REGULUS_CITY",
    "modo": "consolidacao_profissional",
    "status": "online",
    "timestamp": str(datetime.now())
}

# ============================================================
# SAÃDA PROFISSIONAL
# ============================================================

BASE_SAIDA = r"C:\IOTEC\NUCLEO_CONSOLIDADO"

PASTAS_SAIDA = {

    "matrizes": os.path.join(BASE_SAIDA, "MATRIZES"),
    "laboratorio": os.path.join(BASE_SAIDA, "LABORATORIO"),
    "frontend": os.path.join(BASE_SAIDA, "FRONTEND"),
    "backend": os.path.join(BASE_SAIDA, "BACKEND"),
    "analytics": os.path.join(BASE_SAIDA, "ANALYTICS"),
    "financeiro": os.path.join(BASE_SAIDA, "FINANCEIRO"),
    "govtech": os.path.join(BASE_SAIDA, "GOVTECH"),
    "juridico": os.path.join(BASE_SAIDA, "JURIDICO"),
    "duplicados": os.path.join(BASE_SAIDA, "DUPLICADOS"),
    "quarentena": os.path.join(BASE_SAIDA, "QUARENTENA"),
    "logs": os.path.join(BASE_SAIDA, "LOGS")

}

# ============================================================
# CRIAR PASTAS
# ============================================================

for pasta in PASTAS_SAIDA.values():
    os.makedirs(pasta, exist_ok=True)

# ============================================================
# BANCO CENTRAL
# ============================================================

ATIVOS = []
HASHES = {}
DUPLICADOS = []
LOGS = []

# ============================================================
# LOG
# ============================================================

def registrar_log(evento):

    LOGS.append({
        "timestamp": str(datetime.now()),
        "evento": evento
    })

# ============================================================
# HASH
# ============================================================

def gerar_hash(caminho):

    try:

        with open(caminho, "rb") as f:
            return hashlib.md5(f.read()).hexdigest()

    except:
        return None

# ============================================================
# DETECTAR RISCO
# ============================================================

def eh_dependencia_externa(caminho):

    caminho_lower = caminho.lower()

    for pasta in IGNORAR_PASTAS:

        if pasta.lower() in caminho_lower:
            return True

    return False

# ============================================================
# DETECTAR IDENTIDADE IOTEC
# ============================================================

def eh_ativo_iotec(nome):

    nome = nome.lower()

    for palavra in PALAVRAS_IOTEC:

        if palavra in nome:
            return True

    return False

# ============================================================
# CLASSIFICAÃ‡ÃƒO
# ============================================================

def classificar(nome):

    nome = nome.lower()

    if "html" in nome or "css" in nome:
        return "frontend"

    if "api" in nome or "server" in nome:
        return "backend"

    if "analytics" in nome or "dashboard" in nome:
        return "analytics"

    if "finance" in nome or "paypal" in nome:
        return "financeiro"

    if "gov" in nome:
        return "govtech"

    if "juris" in nome or "legal" in nome:
        return "juridico"

    return "laboratorio"

# ============================================================
# ESCAVAÃ‡ÃƒO PROFISSIONAL
# ============================================================

def escavar():

    print("\n======================================================")
    print(" IOTEC CONSOLIDADOR PROFISSIONAL")
    print("======================================================")

    total = 0

    for pasta in PASTAS_ANALISE:

        print(f"\n[+] ANALISANDO -> {pasta}")

        if not os.path.exists(pasta):
            continue

        for raiz, dirs, arquivos in os.walk(pasta):

            dirs[:] = [
                d for d in dirs
                if d not in IGNORAR_PASTAS
            ]

            for arquivo in arquivos:

                ext = os.path.splitext(arquivo)[1].lower()

                if ext not in EXTENSOES_VALIDAS:
                    continue

                caminho = os.path.join(raiz, arquivo)

                if eh_dependencia_externa(caminho):

                    registrar_log(
                        f"DEPENDENCIA IGNORADA -> {caminho}"
                    )

                    continue

                hash_arquivo = gerar_hash(caminho)

                if hash_arquivo in HASHES:

                    DUPLICADOS.append(caminho)

                    registrar_log(
                        f"DUPLICADO -> {caminho}"
                    )

                    try:
                        shutil.copy2(
                            caminho,
                            PASTAS_SAIDA["duplicados"]
                        )
                    except:
                        pass

                    continue

                HASHES[hash_arquivo] = caminho

                tipo = classificar(arquivo)

                ativo = {
                    "nome": arquivo,
                    "caminho": caminho,
                    "tipo": tipo,
                    "hash": hash_arquivo,
                    "iotec": eh_ativo_iotec(arquivo)
                }

                ATIVOS.append(ativo)

                destino = PASTAS_SAIDA[tipo]

                try:

                    shutil.copy2(caminho, destino)

                except:

                    registrar_log(
                        f"ERRO COPIA -> {caminho}"
                    )

                total += 1

    print("\n======================================================")
    print(" ESCAVAÃ‡ÃƒO FINALIZADA")
    print("======================================================")

    print(f"\nATIVOS PROFISSIONAIS: {total}")
    print(f"DUPLICADOS: {len(DUPLICADOS)}")

# ============================================================
# RELATÃ“RIO ESTRATÃ‰GICO
# ============================================================

def relatorio():

    print("\n======================================================")
    print(" MAPA ESTRATÃ‰GICO")
    print("======================================================")

    setores = defaultdict(int)

    for ativo in ATIVOS:
        setores[ativo["tipo"]] += 1

    for setor, quantidade in setores.items():

        print(f"\n{setor.upper()} -> {quantidade}")

# ============================================================
# MATRIZES IMPORTANTES
# ============================================================

def matrizes():

    print("\n======================================================")
    print(" MATRIZES IOTEC")
    print("======================================================")

    encontrados = 0

    for ativo in ATIVOS:

        if ativo["iotec"]:

            encontrados += 1

            print(f"\nNOME: {ativo['nome']}")
            print(f"TIPO: {ativo['tipo']}")
            print(f"CAMINHO: {ativo['caminho']}")

            try:

                shutil.copy2(
                    ativo["caminho"],
                    PASTAS_SAIDA["matrizes"]
                )

            except:
                pass

            if encontrados >= 30:
                break

# ============================================================
# EXPORTAÃ‡ÃƒO JSON
# ============================================================

def exportar():

    relatorio = {

        "nucleo": NUCLEO,
        "ativos": len(ATIVOS),
        "duplicados": len(DUPLICADOS),
        "logs": LOGS,
        "timestamp": str(datetime.now())

    }

    arquivo = os.path.join(
        BASE_SAIDA,
        "RELATORIO_CONSOLIDADO.json"
    )

    with open(arquivo, "w", encoding="utf-8") as f:

        json.dump(
            relatorio,
            f,
            indent=4,
            ensure_ascii=False
        )

    print("\n======================================================")
    print(" EXPORTAÃ‡ÃƒO")
    print("======================================================")

    print(f"\nJSON -> {arquivo}")

# ============================================================
# EXECUÃ‡ÃƒO
# ============================================================

def iniciar():

    escavar()

    relatorio()

    matrizes()

    exportar()

    print("\n======================================================")
    print(" NÃšCLEO CONSOLIDADO COM SUCESSO")
    print("======================================================\n")

# ============================================================
# START
# ============================================================

if __name__ == "__main__":
    iniciar()

