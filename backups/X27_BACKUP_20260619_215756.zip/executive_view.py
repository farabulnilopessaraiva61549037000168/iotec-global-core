def main():

    executive_view()

    compare_goal(
        meta=100000
    )

if __name__ == "__main__":
    main()