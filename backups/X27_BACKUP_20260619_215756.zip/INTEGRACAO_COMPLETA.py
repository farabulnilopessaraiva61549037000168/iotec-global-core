﻿# ============================================================
# IOTEC CORE - SISTEMA INTEGRADO COMPLETO
# ============================================================

import os, json, random
from datetime import datetime

# ============================================================
# BASE SEGURA (RESTRIÃ‡ÃƒO DE ATUAÃ‡ÃƒO)
# ============================================================

BASE = "C:\\IoTec"
os.makedirs(BASE, exist_ok=True)

LOG = os.path.join(BASE, "log.txt")
TASKS = os.path.join(BASE, "tasks.json")
PERF = os.path.join(BASE, "perf.json")
IDENT = os.path.join(BASE, "identidade.json")

for f in [TASKS, PERF]:
    if not os.path.exists(f):
        with open(f, "w") as arq:
            json.dump({}, arq)

# ============================================================
# VOZ
# ============================================================

try:
    import pyttsx3
    tts = pyttsx3.init()
    def falar(txt):
        tts.say(txt)
        tts.runAndWait()
except:
    def falar(txt):
        print("[VOZ]", txt)

# ============================================================
# LOG
# ============================================================

def log(tipo, msg):
    registro = f"[{datetime.now()}] {tipo}: {msg}"
    print(registro)
    with open(LOG, "a", encoding="utf-8") as f:
        f.write(registro + "\n")

# ============================================================
# TAREFAS
# ============================================================

def gerar_tarefa(desc):
    tarefas = json.load(open(TASKS))
    tarefas[str(len(tarefas)+1)] = desc
    json.dump(tarefas, open(TASKS, "w"), indent=2)

# ============================================================
# PERFORMANCE
# ============================================================

def carregar_perf():
    return json.load(open(PERF))

def salvar_perf(d):
    json.dump(d, open(PERF, "w"), indent=2)

def atualizar_perf(setor, valor, custo, sucesso):
    p = carregar_perf()
    if setor not in p:
        p[setor] = {"valor":0, "custo":0, "tentativas":0}

    p[setor]["tentativas"] += 1
    p[setor]["custo"] += custo
    if sucesso:
        p[setor]["valor"] += valor

    salvar_perf(p)

# ============================================================
# DECISÃƒO
# ============================================================

def detectar():
    return {
        "valor": random.uniform(0.5,2),
        "demanda": random.uniform(0.5,2),
        "custo": random.uniform(0.01,0.2)
    }

def score(d):
    return (d["valor"]*d["demanda"])/d["custo"]

# ============================================================
# NAVEGAÃ‡ÃƒO
# ============================================================

APIS = [
    {"nome":"financeiro","custo":0.05},
    {"nome":"economico","custo":0.03},
    {"nome":"geral","custo":0.02}
]

def escolher_api():
    return random.choice(APIS)

# ============================================================
# QUALITY GATE
# ============================================================

def validar_interface():
    checks = [True, True, True]  # simulaÃ§Ã£o
    if all(checks):
        log("QA", "Interface aprovada")
        return True
    else:
        log("QA", "Interface bloqueada")
        return False

# ============================================================
# IDENTIDADE
# ============================================================

def atualizar_identidade():
    p = carregar_perf()
    total = sum(v["valor"] for v in p.values()) if p else 0

    identidade = {
        "nome":"IoTec Core",
        "valor_gerado": round(total,2),
        "data": str(datetime.now())
    }

    json.dump(identidade, open(IDENT,"w"), indent=2)

# ============================================================
# EXECUÃ‡ÃƒO DO NÃšCLEO
# ============================================================

def executar(pedido):

    dados = detectar()
    s = score(dados)

    api = escolher_api()

    if api["custo"] > 1:
        log("CUSTO", "API ignorada por custo")
        return

    sucesso = random.random() < 0.8

    if sucesso:
        valor = random.uniform(1,5)
        atualizar_perf(api["nome"], valor, api["custo"], True)

        msg = f"Oportunidade explorada no setor {api['nome']}"
        log("SUCESSO", msg)
        return msg
    else:
        atualizar_perf(api["nome"], 0, api["custo"], False)

        log("ERRO", "Falha na coleta")
        gerar_tarefa("Revisar API")
        return "Falha detectada"

# ============================================================
# ASSISTENTE
# ============================================================

def assistente():
    falar("Bem-vindo ao IoTec. Como posso ajudar?")

    while True:
        entrada = input("VocÃª: ")

        if entrada.lower() in ["sair","exit"]:
            falar("Encerrando sistema")
            break

        resposta = executar(entrada)

        print("IoTec:", resposta)
        falar(resposta)

        atualizar_identidade()

# ============================================================
# START
# ============================================================

if __name__ == "__main__":
    if validar_interface():
        assistente()

