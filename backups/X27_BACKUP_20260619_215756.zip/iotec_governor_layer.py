# ==========================================================
# 🧠 IOTEC GOVERNOR LAYER v1.0
# Camada de governança do ecossistema
# ==========================================================

import os
import json
from collections import defaultdict
from datetime import datetime

ROOT = r"C:\IOTEC"

# -----------------------------
# 🏛 REGRAS DE GOVERNO
# -----------------------------
REGRAS = {
    "core": ["core", "master", "central", "orquestr", "govern"],
    "producao": ["pipeline", "build", "gerar", "process", "automation"],
    "recepcao": ["form", "html", "interface", "chat", "cliente"],
    "dados": ["json", "csv", "db", "data", "event"],
    "presidencia": ["admin", "audit", "verify", "control", "gov"],
    "almoxarifado": ["backup", "legacy", "archive", "old"],
    "documentos": ["doc", "pdf", "readme", "md"],
    "atendimento": ["ticket", "msg", "support", "chat"]
}


# -----------------------------
# 🧠 CLASSIFICAÇÃO
# -----------------------------
def classificar(path):
    p = path.lower()

    for setor, palavras in REGRAS.items():
        for palavra in palavras:
            if palavra in p:
                return setor

    return "ruido"


# -----------------------------
# 📦 ESCANEAMENTO
# -----------------------------
def escanear(root):
    mapa = defaultdict(list)
    total = 0

    for base, _, files in os.walk(root):
        for f in files:
            full = os.path.join(base, f)
            setor = classificar(full)
            mapa[setor].append(full)
            total += 1

    return mapa, total


# -----------------------------
# 🔁 DUPLICADOS
# -----------------------------
def duplicados(mapa):
    freq = defaultdict(int)

    for setor in mapa:
        for file in mapa[setor]:
            nome = os.path.basename(file)
            freq[nome] += 1

    return {k: v for k, v in freq.items() if v > 1}


# -----------------------------
# 🧠 PESO DE IMPORTÂNCIA
# -----------------------------
PESO = {
    "core": 100,
    "presidencia": 80,
    "producao": 70,
    "dados": 60,
    "atendimento": 50,
    "recepcao": 40,
    "documentos": 30,
    "almoxarifado": 20,
    "ruido": 1
}


def calcular_score(mapa):
    score = {}

    for setor, itens in mapa.items():
        score[setor] = len(itens) * PESO.get(setor, 1)

    return dict(sorted(score.items(), key=lambda x: -x[1]))


# -----------------------------
# 🏛 RELATÓRIO DE GOVERNO
# -----------------------------
def relatorio(mapa, total):
    dup = duplicados(mapa)
    score = calcular_score(mapa)

    return {
        "timestamp": str(datetime.now()),
        "total_ativos": total,
        "estrutura": {k: len(v) for k, v in mapa.items()},
        "duplicados": dup,
        "score_governanca": score
    }


# -----------------------------
# 📊 RELATÓRIO VISUAL
# -----------------------------
def imprimir(rel):
    print("\n====================================")
    print("🏛 IOTEC - GOVERNOR LAYER")
    print("====================================")

    print(f"\n📦 TOTAL DE ATIVOS: {rel['total_ativos']}\n")

    print("📊 ESTRUTURA:")
    for k, v in rel["estrutura"].items():
        print(f" - {k}: {v}")

    print("\n🏆 SCORE DE IMPORTÂNCIA:")
    for k, v in rel["score_governanca"].items():
        print(f" - {k}: {v}")

    print("\n⚠ TOP DUPLICADOS:")
    for k, v in sorted(rel["duplicados"].items(), key=lambda x: -x[1])[:10]:
        print(f" - {k}: {v}")

    print("\n====================================")
    print("✔ GOVERNANÇA FINALIZADA")
    print("====================================\n")


# -----------------------------
# 💾 SALVAR
# -----------------------------
def salvar(rel):
    with open("iotec_governanca.json", "w", encoding="utf-8") as f:
        json.dump(rel, f, indent=4, ensure_ascii=False)


# -----------------------------
# 🚀 EXECUÇÃO
# -----------------------------
if __name__ == "__main__":
    mapa, total = escanear(ROOT)
    rel = relatorio(mapa, total)

    imprimir(rel)
    salvar(rel)