﻿import os

ARQUIVO = "C:\\IOTEC\\CORE\\interface_profissional.html"

def substituir():

    with open(ARQUIVO, "r", encoding="utf-8") as f:
        conteudo = f.read()

    antigo = "function enviar(){"
    novo = """async function enviar(){

  const dados = {
    nome: document.querySelector("input[placeholder='Nome completo ou responsÃ¡vel']").value,
    empresa: document.querySelector("input[placeholder='Empresa / InstituiÃ§Ã£o']").value,
    email: document.querySelector("input[type='email']").value,
    telefone: document.querySelector("input[placeholder='Telefone']").value,
    setor: document.querySelector("select").value,
    problema: document.querySelector("textarea").value
  };

  await fetch("http://127.0.0.1:5000/enviar", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(dados)
  });

  alert("SolicitaÃ§Ã£o enviada para o nÃºcleo.");
}
"""

    if antigo in conteudo:
        conteudo = conteudo.replace(
            conteudo[conteudo.find(antigo):conteudo.find("}", conteudo.find(antigo))+1],
            novo
        )

        with open(ARQUIVO, "w", encoding="utf-8") as f:
            f.write(conteudo)

        print("âœ” Interface atualizada automaticamente")
    else:
        print("âš  FunÃ§Ã£o nÃ£o encontrada")

if __name__ == "__main__":
    substituir()

