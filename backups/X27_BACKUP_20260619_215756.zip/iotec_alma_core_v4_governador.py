# ==========================================================
# IOTEC ALMA CORE v4 - GOVERNADOR DO ECOSSISTEMA
# Núcleo oficial + histórico + experimental + ruído
# ==========================================================

import os
from pathlib import Path
from collections import defaultdict, Counter
from datetime import datetime

ROOT_DIR = Path.cwd()

# ----------------------------------------------------------
# CLASSIFICAÇÃO INTELIGENTE (3 DIMENSÕES)
# ----------------------------------------------------------

NUCLEO_INDICADORES = [
    "core", "master", "central", "engine", "orchestrator",
    "api", "kernel", "system", "main", "gateway"
]

HISTORICO_INDICADORES = [
    "backup", "legacy", "old", "archive", "dump", "v1", "v2", "v3"
]

EXPERIMENTAL_INDICADORES = [
    "test", "dev", "lab", "sandbox", "beta", "prototype"
]


# ----------------------------------------------------------
# FUNÇÃO DE CLASSIFICAÇÃO
# ----------------------------------------------------------
def classificar_fase(nome: str):

    n = nome.lower()

    if any(k in n for k in NUCLEO_INDICADORES):
        return "NUCLEO_OFICIAL"

    if any(k in n for k in HISTORICO_INDICADORES):
        return "HISTORICO"

    if any(k in n for k in EXPERIMENTAL_INDICADORES):
        return "EXPERIMENTAL"

    return "RUÍDO/NAO_CLASSIFICADO"


# ----------------------------------------------------------
# ESCANEAMENTO
# ----------------------------------------------------------
def escanear():
    mapa = defaultdict(list)

    for root, _, files in os.walk(ROOT_DIR):
        for f in files:
            path = str(Path(root) / f)
            categoria = classificar_fase(f)
            mapa[categoria].append(path)

    return mapa


# ----------------------------------------------------------
# ANÁLISE ESTRUTURAL
# ----------------------------------------------------------
def analisar(mapa):

    total = sum(len(v) for v in mapa.values())

    duplicados = Counter(
        [os.path.basename(p) for v in mapa.values() for p in v]
    )

    duplicados = {k: v for k, v in duplicados.items() if v > 1}

    return {
        "total": total,
        "nucleo": len(mapa.get("NUCLEO_OFICIAL", [])),
        "historico": len(mapa.get("HISTORICO", [])),
        "experimental": len(mapa.get("EXPERIMENTAL", [])),
        "ruido": len(mapa.get("RUÍDO/NAO_CLASSIFICADO", [])),
        "duplicados": len(duplicados),
        "top_duplicados": dict(list(duplicados.items())[:10])
    }


# ----------------------------------------------------------
# DIAGNÓSTICO DE ARQUITETURA
# ----------------------------------------------------------
def diagnostico(rel):

    alertas = []

    if rel["nucleo"] < rel["total"] * 0.05:
        alertas.append("🔴 Núcleo oficial muito pequeno vs sistema total")

    if rel["ruido"] > rel["total"] * 0.2:
        alertas.append("⚠ Alto nível de ruído estrutural")

    if rel["duplicados"] > 5000:
        alertas.append("⚠ Excesso crítico de duplicação de arquivos")

    if rel["historico"] > rel["nucleo"] * 3:
        alertas.append("⚠ Sistema carregado de versões antigas")

    return alertas


# ----------------------------------------------------------
# RELATÓRIO FINAL
# ----------------------------------------------------------
def relatorio(mapa):

    rel = analisar(mapa)
    alertas = diagnostico(rel)

    print("\n====================================")
    print("🧠 IOTEC ALMA CORE v4 - GOVERNADOR")
    print("====================================\n")

    print(f"📦 TOTAL DE ATIVOS: {rel['total']}\n")

    print("🏛 DISTRIBUIÇÃO ESTRUTURAL:")
    print(f" - Núcleo Oficial: {rel['nucleo']}")
    print(f" - Histórico: {rel['historico']}")
    print(f" - Experimental: {rel['experimental']}")
    print(f" - Ruído: {rel['ruido']}")
    print(f" - Duplicados: {rel['duplicados']}\n")

    print("🚨 ALERTAS ESTRATÉGICOS:")
    if alertas:
        for a in alertas:
            print(" ", a)
    else:
        print(" ✔ Estrutura relativamente estável")

    print("\n📌 TOP DUPLICADOS:")
    for k, v in rel["top_duplicados"].items():
        print(f" - {k}: {v}")

    print("\n====================================")
    print(f"Timestamp: {datetime.now()}")
    print("====================================\n")


# ----------------------------------------------------------
# CORE
# ----------------------------------------------------------
def governador():
    print("🧠 ALMA CORE v4 - GOVERNADOR INICIADO\n")

    mapa = escanear()
    relatorio(mapa)

    print("✔ Governança concluída.")


# ----------------------------------------------------------
# EXECUÇÃO
# ----------------------------------------------------------
if __name__ == "__main__":
    governador()