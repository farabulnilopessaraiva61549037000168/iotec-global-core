﻿# =========================================================
# IOTEC TRAFFIC CONTROLLER
# CONTROLADOR DE TRAFEGO OPERACIONAL
# =========================================================

from flask import Flask, jsonify, request
from flask_cors import CORS

from datetime import datetime

import socket
import threading
import time
import json
import os

# =========================================================
# APP
# =========================================================

app = Flask(__name__)

CORS(app)

# =========================================================
# BASE
# =========================================================

BASE_DIR = "iotec_traffic"

os.makedirs(BASE_DIR, exist_ok=True)

# =========================================================
# MEMORIA CENTRAL
# =========================================================

TRAFEGO = {

    "interfaces": [],

    "portas_ocupadas": [],

    "fila_subida": [],

    "modulos_online": [],

    "alertas": [],

    "semaforos": {}
}

# =========================================================
# LOG CENTRAL
# =========================================================

def registrar_evento(evento):

    arquivo = os.path.join(

        BASE_DIR,

        f"traffic_{datetime.now().strftime('%Y-%m-%d')}.txt"
    )

    with open(

        arquivo,

        "a",

        encoding="utf-8"

    ) as f:

        f.write("\n")
        f.write("=" * 60)
        f.write("\n")

        f.write(

            datetime.now().strftime(
                "%d/%m/%Y %H:%M:%S"
            )

        )

        f.write("\n\n")

        f.write(evento)

        f.write("\n")

# =========================================================
# SALVAR MEMORIA
# =========================================================

def salvar_estado():

    caminho = os.path.join(
        BASE_DIR,
        "estado.json"
    )

    with open(

        caminho,

        "w",

        encoding="utf-8"

    ) as f:

        json.dump(

            TRAFEGO,

            f,

            indent=4,

            ensure_ascii=False
        )

# =========================================================
# VERIFICAR PORTA
# =========================================================

def porta_ocupada(porta):

    sock = socket.socket(
        socket.AF_INET,
        socket.SOCK_STREAM
    )

    resultado = sock.connect_ex(
        ('127.0.0.1', porta)
    )

    sock.close()

    return resultado == 0

# =========================================================
# MONITORAR PORTAS
# =========================================================

def monitorar_portas():

    while True:

        ocupadas = []

        for porta in range(5000, 5100):

            if porta_ocupada(porta):

                ocupadas.append(porta)

        TRAFEGO["portas_ocupadas"] = ocupadas

        salvar_estado()

        time.sleep(10)

# =========================================================
# REGISTRAR INTERFACE
# =========================================================

def registrar_interface(

    nome,
    porta,
    prioridade="media"

):

    if porta in TRAFEGO["portas_ocupadas"]:

        alerta = (

            f"CONFLITO DETECTADO "
            f"NA PORTA {porta}"
        )

        TRAFEGO["alertas"].append(
            alerta
        )

        registrar_evento(alerta)

        return {

            "status": "bloqueado",

            "motivo":
            "porta ocupada"
        }

    interface = {

        "nome": nome,

        "porta": porta,

        "prioridade": prioridade,

        "status": "online",

        "timestamp":

        datetime.now().strftime(
            "%d/%m/%Y %H:%M:%S"
        )
    }

    TRAFEGO["interfaces"].append(
        interface
    )

    TRAFEGO["fila_subida"].append(
        nome
    )

    TRAFEGO["semaforos"][nome] = "verde"

    registrar_evento(

        f"INTERFACE REGISTRADA: "
        f"{nome}"
    )

    salvar_estado()

    return {

        "status": "registrado",

        "interface": nome
    }

# =========================================================
# GUARDA DE TRAFEGO
# =========================================================

def guarda_operacional():

    while True:

        for interface in TRAFEGO["interfaces"]:

            porta = interface["porta"]

            nome = interface["nome"]

            if porta_ocupada(porta):

                TRAFEGO["semaforos"][nome] = "verde"

            else:

                TRAFEGO["semaforos"][nome] = "vermelho"

                alerta = (

                    f"INTERFACE OFFLINE: "
                    f"{nome}"
                )

                if alerta not in TRAFEGO["alertas"]:

                    TRAFEGO["alertas"].append(
                        alerta
                    )

                    registrar_evento(alerta)

        salvar_estado()

        time.sleep(15)

# =========================================================
# HOME
# =========================================================

@app.route('/')

def home():

    return jsonify({

        "iotec_traffic":
        "online",

        "sistema":
        "controlador_operacional",

        "interfaces":
        len(TRAFEGO["interfaces"]),

        "portas_ativas":
        len(TRAFEGO["portas_ocupadas"]),

        "alertas":
        len(TRAFEGO["alertas"])
    })

# =========================================================
# STATUS
# =========================================================

@app.route('/traffic/status')

def status():

    return jsonify(TRAFEGO)

# =========================================================
# REGISTRAR INTERFACE
# =========================================================

@app.route('/traffic/registrar', methods=['POST'])

def registrar():

    dados = request.json

    nome = dados.get("nome")

    porta = dados.get("porta")

    prioridade = dados.get(
        "prioridade",
        "media"
    )

    resultado = registrar_interface(

        nome,
        porta,
        prioridade
    )

    return jsonify(resultado)

# =========================================================
# ALERTAS
# =========================================================

@app.route('/traffic/alertas')

def alertas():

    return jsonify({

        "alertas":
        TRAFEGO["alertas"]
    })

# =========================================================
# SEMAFOROS
# =========================================================

@app.route('/traffic/semaforos')

def semaforos():

    return jsonify({

        "semaforos":
        TRAFEGO["semaforos"]
    })

# =========================================================
# FILA
# =========================================================

@app.route('/traffic/fila')

def fila():

    return jsonify({

        "fila_subida":
        TRAFEGO["fila_subida"]
    })

# =========================================================
# WATCHER
# =========================================================

def iniciar_watcher():

    threading.Thread(

        target=monitorar_portas,

        daemon=True

    ).start()

    threading.Thread(

        target=guarda_operacional,

        daemon=True

    ).start()

# =========================================================
# BOOT
# =========================================================

if __name__ == '__main__':

    registrar_evento(
        "IOTEC TRAFFIC CONTROLLER INICIADO"
    )

    iniciar_watcher()

    app.run(

        host='0.0.0.0',

        port=5050
    )

