﻿def executar_nucleo():

    setores = ["financeiro", "economico", "geral"]
    setor = priorizar_setor(setores)

    api = escolher_api(setor)

    if not api:
        return

    if not verificar_limite_custo(api):
        return

    resultado = executar_coleta(api)

    if resultado["status"] == "SUCESSO":
        valor = resultado["valor"]
        custo = api["custo"]

        atualizar_perf(setor, api["nome"], valor, custo, True)

        verificar_roi_alto(setor, api["nome"])

    else:
        atualizar_perf(setor, api["nome"], 0.0, api["custo"], False)

    executar_experimentos()

