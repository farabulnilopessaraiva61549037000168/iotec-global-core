﻿import os
import ast
from collections import defaultdict

# ============================
# CONFIG
# ============================

ROOT = input("Digite a pasta do núcleo: ").strip()

KEYWORDS_ORCHESTRATION = [
    "orchestrator", "engine", "workflow", "pipeline",
    "queue", "worker", "dispatch", "router", "controller",
    "manager", "agent", "event", "trigger", "state",
    "async", "task", "schedule", "execute", "run"
]

ENTRYPOINT_HINTS = [
    "main", "app", "start", "boot", "server", "run"
]

CALL_GRAPH = defaultdict(list)
FILES_ANALYZED = 0

# ============================
# ANALISAR PY FILES
# ============================

def analyze_file(path):
    global FILES_ANALYZED

    try:
        with open(path, "r", encoding="utf-8") as f:
            tree = ast.parse(f.read(), filename=path)

        FILES_ANALYZED += 1

        calls = []

        for node in ast.walk(tree):
            if isinstance(node, ast.Call):
                if hasattr(node.func, "id"):
                    calls.append(node.func.id)
                elif hasattr(node.func, "attr"):
                    calls.append(node.func.attr)

        CALL_GRAPH[path] = calls

    except:
        pass

# ============================
# SCAN NÚCLEO
# ============================

for root, dirs, files in os.walk(ROOT):
    for file in files:
        if file.endswith(".py"):
            analyze_file(os.path.join(root, file))

# ============================
# ANÁLISE ESTRUTURAL
# ============================

orchestration_score = 0
entrypoints = 0
connections = 0

for file, calls in CALL_GRAPH.items():

    name = file.lower()

    # sinais de orquestração por nome
    if any(k in name for k in KEYWORDS_ORCHESTRATION):
        orchestration_score += 2

    # entrypoints
    if any(k in name for k in ENTRYPOINT_HINTS):
        entrypoints += 1

    # conexões reais entre arquivos
    connections += len(calls)

# ============================
# DIAGNÓSTICO FINAL
# ============================

print("\n===================================")
print("CORE ORCHESTRATION ANALYSIS")
print("===================================\n")

print(f"Arquivos analisados: {FILES_ANALYZED}")
print(f"Conexões detectadas (calls): {connections}")
print(f"Sinais de orquestração: {orchestration_score}")
print(f"Entrypoints detectados: {entrypoints}")

print("\n-----------------------------------")

# ============================
# CLASSIFICAÇÃO INTELIGENTE
# ============================

if orchestration_score > 50 and connections > 500:
    status = "ORQUESTRAÇÃO FORTE - SISTEMA OPERACIONAL PROVÁVEL"
elif orchestration_score > 20 and connections > 200:
    status = "ORQUESTRAÇÃO MÉDIA - ECOSSISTEMA PARCIAL"
elif orchestration_score > 5:
    status = "ORQUESTRAÇÃO FRACA - MÓDULOS ISOLADOS"
else:
    status = "SEM ORQUESTRAÇÃO REAL DETECTADA"

print("STATUS:")
print(status)

print("\n-----------------------------------")

# ============================
# INTERPRETAÇÃO FINAL
# ============================

print("""
INTERPRETAÇÃO:

- 'orquestração forte' = sistemas realmente conversam entre si
- 'média' = existem partes conectadas mas não centralizadas
- 'fraca' = apenas arquivos soltos com nomes inteligentes
- 'nenhuma' = projeto não tem coordenação real

IMPORTANTE:
Isso NÃO mede inteligência da IA,
mas sim arquitetura real de execução.
""")

