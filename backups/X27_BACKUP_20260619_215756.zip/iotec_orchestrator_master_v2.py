# ============================================================
# 🧠 IOTEC ORCHESTRATOR MASTER v2 - PIPELINE INTELIGENTE
# ============================================================
# Função: Receber requisições e executar pipeline de decisão
# Autor: IOTEC CORE SYSTEM
# Versão: 2.0 - Governança Inteligente
# ============================================================

import time
import uuid
from datetime import datetime

# -------------------------------
# 🧠 TABELA DE CLASSIFICAÇÃO
# -------------------------------

SETORES = {
    "core": ["bug", "erro", "falha", "crash", "login", "api", "sistema"],
    "atendimento": ["cliente", "suporte", "ajuda", "chamado", "pedido", "automação"],
    "dados": ["relatório", "análise", "csv", "dados", "estatística", "financeiro"],
    "producao": ["gerar", "build", "pipeline", "deploy", "criar sistema"],
    "presidencia": ["governança", "estratégia", "decisão", "arquitetura"],
    "ruido": []
}

PRIORIDADE_MAP = {
    "critica": ["erro", "bug", "falha", "crash", "login"],
    "alta": ["automação", "cliente", "sistema", "criar", "gerar"],
    "media": ["relatório", "análise", "pedido"],
}

# -------------------------------
# 🧠 FUNÇÃO DE CLASSIFICAÇÃO
# -------------------------------

def classificar_setor(texto):
    texto = texto.lower()

    for setor, palavras in SETORES.items():
        for p in palavras:
            if p in texto:
                return setor
    return "ruido"


def definir_prioridade(texto):
    texto = texto.lower()

    for nivel, palavras in PRIORIDADE_MAP.items():
        for p in palavras:
            if p in texto:
                return nivel.upper()

    return "BAIXA"


# -------------------------------
# 🧠 PIPELINE DE PROCESSAMENTO
# -------------------------------

def pipeline_requisicao(requisicao):

    ticket_id = str(uuid.uuid4())[:8]
    timestamp = datetime.now()

    print("\n" + "="*60)
    print("🧠 IOTEC ORCHESTRATOR MASTER v2 - PIPELINE")
    print("="*60)

    print(f"📩 REQUISIÇÃO: {requisicao}")

    # ETAPA 1 - CLASSIFICAÇÃO
    setor = classificar_setor(requisicao)
    prioridade = definir_prioridade(requisicao)

    # ETAPA 2 - ROTEAMENTO
    rota = f"Torre > {setor.upper()} > Nível automático"

    # ETAPA 3 - CRIAÇÃO DE TICKET
    ticket = {
        "id": ticket_id,
        "texto": requisicao,
        "setor": setor,
        "prioridade": prioridade,
        "rota": rota,
        "timestamp": str(timestamp)
    }

    # ETAPA 4 - EXECUÇÃO SIMULADA
    print("\n📦 TICKET GERADO:")
    for k, v in ticket.items():
        print(f" - {k}: {v}")

    # ETAPA 5 - LOG / AUDITORIA
    log_line = f"{timestamp} | {ticket_id} | {setor} | {prioridade} | {requisicao}\n"

    with open("iotec_orchestrator_log.txt", "a", encoding="utf-8") as f:
        f.write(log_line)

    print("\n📜 LOG REGISTRADO")
    print("✔ PIPELINE FINALIZADO COM SUCESSO")

    return ticket


# -------------------------------
# 🧠 LOOP PRINCIPAL
# -------------------------------

if __name__ == "__main__":

    print("🧠 ORCHESTRATOR MASTER v2 - PIPELINE INTELIGENTE")

    while True:
        req = input("\nDigite requisição (ou 'sair'): ")

        if req.lower() == "sair":
            break

        pipeline_requisicao(req)