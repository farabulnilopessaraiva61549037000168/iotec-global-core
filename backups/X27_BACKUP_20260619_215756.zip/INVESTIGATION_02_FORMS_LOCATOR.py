import json

with open(
    "MISSION_03_MASTER_INVENTORY.json",
    "r",
    encoding="utf-8"
) as f:
    data = json.load(f)

print("\n================================")
print(" FORMS FOUND")
print("================================\n")

for i, form in enumerate(data["forms"], 1):

    print(f"{i:02d} - {form}")

print("\n================================")