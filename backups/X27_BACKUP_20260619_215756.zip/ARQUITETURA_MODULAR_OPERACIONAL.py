﻿# =========================================================
# IOTEC CORE
# NUCLEO MODULAR OPERACIONAL
# =========================================================

from flask import Flask, jsonify, request
from flask_cors import CORS

from datetime import datetime

import os
import json

# =========================================================
# APP
# =========================================================

app = Flask(__name__)

CORS(app)

# =========================================================
# ESTRUTURA CENTRAL
# =========================================================

BASE_DIR = "iotec_core"

ESTRUTURA = [

    "logs",
    "config",
    "status",
    "memoria",
    "modulos",
    "analitico",
    "operante",
    "dashboard",
    "interfaces",
    "clientes",
    "automacao",
    "ia",
    "webhooks",
    "banco"
]

# =========================================================
# MODULOS
# =========================================================

MODULOS = {

    "analitico": {

        "status": "online",
        "peso": "pesado",
        "camada": "estrategica",
        "descricao":
        "Consciencia sistemica"
    },

    "operante": {

        "status": "online",
        "peso": "pesado",
        "camada": "operacional",
        "descricao":
        "Operacao continua"
    },

    "ia": {

        "status": "online",
        "peso": "medio",
        "camada": "inteligencia",
        "descricao":
        "Processamento inteligente"
    },

    "dashboard": {

        "status": "online",
        "peso": "leve",
        "camada": "controle",
        "descricao":
        "Visualizacao central"
    },

    "automacao": {

        "status": "online",
        "peso": "pesado",
        "camada": "infraestrutura",
        "descricao":
        "Automacoes e gatilhos"
    }
}

# =========================================================
# CRIAR ESTRUTURA
# =========================================================

def criar_estrutura():

    os.makedirs(BASE_DIR, exist_ok=True)

    for pasta in ESTRUTURA:

        os.makedirs(

            os.path.join(
                BASE_DIR,
                pasta
            ),

            exist_ok=True
        )

# =========================================================
# LOG CENTRAL
# =========================================================

def registrar_evento(evento):

    arquivo = os.path.join(

        BASE_DIR,

        "logs",

        f"core_{datetime.now().strftime('%Y-%m-%d')}.txt"
    )

    with open(

        arquivo,

        "a",

        encoding="utf-8"

    ) as f:

        f.write("\n")
        f.write("=" * 60)
        f.write("\n")

        f.write(

            datetime.now().strftime(
                "%d/%m/%Y %H:%M:%S"
            )

        )

        f.write("\n\n")

        f.write(evento)

        f.write("\n")

# =========================================================
# MEMORIA CENTRAL
# =========================================================

def salvar_memoria():

    arquivo = os.path.join(

        BASE_DIR,

        "config",

        "modulos.json"
    )

    with open(

        arquivo,

        "w",

        encoding="utf-8"

    ) as f:

        json.dump(

            MODULOS,

            f,

            indent=4,

            ensure_ascii=False
        )

# =========================================================
# HOME
# =========================================================

@app.route('/')

def home():

    registrar_evento(
        "ACESSO AO NUCLEO CENTRAL"
    )

    return jsonify({

        "iotec_core": "online",

        "tipo":
        "nucleo_modular_operacional",

        "status": "ativo",

        "recepcao": "24h",

        "modulos_ativos":
        len(MODULOS),

        "timestamp":

        datetime.now().strftime(
            "%d/%m/%Y %H:%M:%S"
        )
    })

# =========================================================
# STATUS GERAL
# =========================================================

@app.route('/admin/status')

def status():

    registrar_evento(
        "CONSULTA STATUS CENTRAL"
    )

    return jsonify({

        "nucleo": "online",

        "modulos": MODULOS,

        "recepcao": "ativa",

        "interfaces": "conectadas",

        "timestamp":

        datetime.now().strftime(
            "%d/%m/%Y %H:%M:%S"
        )
    })

# =========================================================
# MODULO ANALITICO
# =========================================================

@app.route('/admin/analitico')

def analitico():

    registrar_evento(
        "MODULO ANALITICO ACESSADO"
    )

    return jsonify({

        "modulo": "analitico",

        "status": "online",

        "funcao":
        "interpretacao sistemica",

        "capacidade": [

            "analise",
            "classificacao",
            "monitoramento",
            "diagnostico"
        ]
    })

# =========================================================
# MODULO OPERANTE
# =========================================================

@app.route('/admin/operante')

def operante():

    registrar_evento(
        "MODULO OPERANTE ACESSADO"
    )

    return jsonify({

        "modulo": "operante",

        "status": "online",

        "funcao":
        "operacao continua",

        "capacidade": [

            "recepcao",
            "automacao",
            "processamento",
            "integracao"
        ]
    })

# =========================================================
# DASHBOARD
# =========================================================

@app.route('/admin/dashboard')

def dashboard():

    registrar_evento(
        "ACESSO DASHBOARD"
    )

    return jsonify({

        "dashboard": "ativo",

        "modulos_online":
        len(MODULOS),

        "recepcao": "24h",

        "nucleo": "operacional"
    })

# =========================================================
# EMERGENCIA MODULAR
# =========================================================

@app.route('/admin/emergencia')

def emergencia():

    registrar_evento(
        "EMERGENCIA MODULAR"
    )

    return jsonify({

        "status":
        "emergencia_controlada",

        "modulos_emergindo": [

            "analitico",
            "operante",
            "ia"
        ],

        "risco": "baixo",

        "infraestrutura":
        "estavel"
    })

# =========================================================
# RECEPCAO
# =========================================================

@app.route('/recepcao/mensagem', methods=['POST'])

def mensagem():

    dados = request.json

    registrar_evento(

        f"MENSAGEM RECEBIDA: "
        f"{dados}"
    )

    return jsonify({

        "status": "recebido",

        "recepcao": "ativa",

        "nucleo": "processando"
    })

# =========================================================
# IA
# =========================================================

@app.route('/ia/chat', methods=['POST'])

def ia_chat():

    data = request.json

    mensagem = data.get(
        "mensagem",
        ""
    )

    registrar_evento(

        f"IA PROCESSOU: "
        f"{mensagem}"
    )

    return jsonify({

        "ia": "online",

        "resposta":

        f"IOTEC CORE RECEBEU: "
        f"{mensagem}"
    })

# =========================================================
# BOOT
# =========================================================

if __name__ == '__main__':

    criar_estrutura()

    salvar_memoria()

    registrar_evento(
        "NUCLEO IOTEC INICIALIZADO"
    )

    app.run(

        host='0.0.0.0',

        port=5000
    )

