﻿import os
import datetime
import pandas as pd
import plotly.graph_objects as go

from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Image
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import cm

# =========================
# CONFIG
# =========================

BASE_DIR = "C:\\IOTEC\\DOSSIER_IOTEC"
os.makedirs(BASE_DIR, exist_ok=True)

# =========================
# DADOS (EXEMPLO)
# =========================

dados = {
    "municipio": "Ibicuitinga",
    "professores": 100,
    "salario": 2500,
    "piso": 3500
}

# =========================
# CÃLCULOS
# =========================

folha_atual = dados["professores"] * dados["salario"]
folha_nova = dados["professores"] * dados["piso"]
aumento_pct = (folha_nova - folha_atual) / folha_atual * 100

# =========================
# PASTA FINAL
# =========================

timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M")
PASTA = os.path.join(BASE_DIR, f"DOSSIE_{timestamp}")
os.makedirs(PASTA, exist_ok=True)

# =========================
# GRÃFICO PREMIUM
# =========================

grafico_path = os.path.join(PASTA, "grafico.png")

fig = go.Figure()
fig.add_trace(go.Bar(
    x=["Atual", "Projetado"],
    y=[folha_atual, folha_nova],
    marker_color=["#1E6FFF", "#00C48C"]
))
fig.update_layout(
    title="Impacto Financeiro",
    plot_bgcolor="#0B0F14",
    paper_bgcolor="#0B0F14",
    font=dict(color="white")
)

fig.write_image(grafico_path, width=1400, height=800)

# =========================
# EXCEL
# =========================

excel_path = os.path.join(PASTA, "analise.xlsx")

df = pd.DataFrame({
    "Indicador": ["Folha Atual", "Folha Projetada", "Aumento (%)"],
    "Valor": [folha_atual, folha_nova, aumento_pct]
})

df.to_excel(excel_path, index=False)

# =========================
# TEXTO PROFISSIONAL
# =========================

texto = f"""
Diante do cenÃ¡rio analisado, observa-se que a adequaÃ§Ã£o ao piso salarial implica aumento relevante da despesa com pessoal.

A folha atual apresenta o valor de R$ {folha_atual:,.2f}, enquanto a projeÃ§Ã£o indica R$ {folha_nova:,.2f}, representando variaÃ§Ã£o de {aumento_pct:.2f}%.

Nesse contexto, recomenda-se a adoÃ§Ã£o de planejamento gradual, com vistas Ã  mitigaÃ§Ã£o dos impactos financeiros e preservaÃ§Ã£o do equilÃ­brio orÃ§amentÃ¡rio.
"""

# =========================
# PDF PROFISSIONAL
# =========================

pdf_path = os.path.join(PASTA, "relatorio.pdf")

doc = SimpleDocTemplate(
    pdf_path,
    pagesize=A4,
    leftMargin=3*cm,
    rightMargin=2*cm,
    topMargin=3*cm,
    bottomMargin=2*cm
)

styles = getSampleStyleSheet()

estilo = ParagraphStyle(
    name="Justificado",
    parent=styles["Normal"],
    fontName="Times-Roman",
    fontSize=12,
    leading=18,
    alignment=4,
    firstLineIndent=1.25*cm
)

story = []

story.append(Paragraph("RELATÃ“RIO TÃ‰CNICO IOTEC", styles["Title"]))
story.append(Spacer(1, 20))

for p in texto.strip().split("\n\n"):
    story.append(Paragraph(p, estilo))
    story.append(Spacer(1, 12))

story.append(Image(grafico_path, width=500, height=300))

doc.build(story)

# =========================
# CHECKLIST
# =========================

itens = {
    "pdf": os.path.exists(pdf_path),
    "excel": os.path.exists(excel_path),
    "grafico": os.path.exists(grafico_path)
}

faltando = [k for k, v in itens.items() if not v]

print("\n===== RESULTADO =====")

if faltando:
    print("âŒ Faltando:", faltando)
else:
    print("âœ… DossiÃª completo gerado com sucesso")

print(f"\nðŸ“ Pasta: {PASTA}")

