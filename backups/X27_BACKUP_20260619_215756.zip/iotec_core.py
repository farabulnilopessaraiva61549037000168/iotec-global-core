﻿# ============================================================
# IOTEC - NÚCLEO INTEGRADO
# ============================================================

import os
from datetime import datetime
import random
import json

BASE = "C:\\IoTec"
LOG_PATH = os.path.join(BASE, "logs", "registro_nucleo.txt")
TASK_PATH = os.path.join(BASE, "tasks", "fila_tarefas.json")

# ============================================================
# GARANTIA DE ARQUIVOS
# ============================================================

if not os.path.exists(TASK_PATH):
    with open(TASK_PATH, "w", encoding="utf-8") as f:
        json.dump([], f)

# ============================================================
# COMUNICAÇÃO INTERNA
# ============================================================

def registrar_mensagem(tipo, modulo, descricao, impacto, acao, prioridade):

    mensagem = {
        "data": str(datetime.now()),
        "tipo": tipo,
        "modulo": modulo,
        "descricao": descricao,
        "impacto": impacto,
        "acao": acao,
        "prioridade": prioridade
    }

    salvar_log(mensagem)
    gerar_tarefa(mensagem)

    print(f"\n[{mensagem['data']}] {tipo} - {modulo}")
    print(f"{descricao}\n")

def salvar_log(mensagem):
    with open(LOG_PATH, "a", encoding="utf-8") as f:
        f.write(json.dumps(mensagem, ensure_ascii=False) + "\n")

# ============================================================
# GERADOR DE TAREFAS AUTOMÁTICO
# ============================================================

def gerar_tarefa(mensagem):

    if mensagem["prioridade"] == "BAIXA":
        return

    with open(TASK_PATH, "r", encoding="utf-8") as f:
        tarefas = json.load(f)

    tarefa = {
        "id": len(tarefas) + 1,
        "data": mensagem["data"],
        "modulo": mensagem["modulo"],
        "descricao": mensagem["descricao"],
        "acao": mensagem["acao"],
        "prioridade": mensagem["prioridade"],
        "status": "PENDENTE"
    }

    tarefas.append(tarefa)

    with open(TASK_PATH, "w", encoding="utf-8") as f:
        json.dump(tarefas, f, indent=4, ensure_ascii=False)

# ============================================================
# MOTOR DO NÚCLEO (SIMULAÇÃO)
# ============================================================

def detectar_oportunidade():
    return {
        "valor": random.uniform(0.5, 1.5),
        "demanda": random.uniform(0.5, 1.5),
        "custo": random.uniform(0.01, 0.2)
    }

def calcular_score(d):
    return (d["valor"] * d["demanda"]) / d["custo"]

def executar_nucleo():

    dados = detectar_oportunidade()
    score = calcular_score(dados)

    # SITUAÇÕES DO SISTEMA
    if score < 2:
        registrar_mensagem(
            tipo="NECESSIDADE",
            modulo="COLETA",
            descricao="Baixa eficiência na coleta de dados.",
            impacto="Pouca geração de valor.",
            acao="Buscar novas APIs mais eficientes.",
            prioridade="ALTA"
        )

    elif score > 8:
        registrar_mensagem(
            tipo="OPORTUNIDADE",
            modulo="MERCADO",
            descricao="Alta oportunidade detectada.",
            impacto="Possível aumento de receita.",
            acao="Intensificar coleta e análise.",
            prioridade="MÉDIA"
        )

    # ERRO SIMULADO
    if random.random() < 0.3:
        registrar_mensagem(
            tipo="ERRO",
            modulo="API",
            descricao="Falha na comunicação com API externa.",
            impacto="Interrupção parcial dos dados.",
            acao="Verificar limite ou substituir API.",
            prioridade="ALTA"
        )

# ============================================================
# LOOP PRINCIPAL
# ============================================================

if __name__ == "__main__":

    print("====================================")
    print(" IOTEC - NÚCLEO ATIVO ")
    print("====================================")

    for i in range(5):
        executar_nucleo()

    print("\nExecução finalizada.")

