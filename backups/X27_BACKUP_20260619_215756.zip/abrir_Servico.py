﻿<script>
function abrirServico(tipo) {

    let conteudo = "";

    if (tipo === "auditoria") {
        conteudo = "<h1>Auditoria TÃ©cnica</h1><p>AnÃ¡lise completa da sua operaÃ§Ã£o.</p>";
    }

    if (tipo === "desenvolvimento") {
        conteudo = "<h1>Desenvolvimento</h1><p>Sistemas sob medida.</p>";
    }

    if (tipo === "seguranca") {
        conteudo = "<h1>CiberseguranÃ§a</h1><p>ProteÃ§Ã£o de dados.</p>";
    }

    // cria painel
    let painel = document.createElement("div");
    painel.style.position = "fixed";
    painel.style.top = "0";
    painel.style.left = "0";
    painel.style.width = "100%";
    painel.style.height = "100%";
    painel.style.background = "#080A0F";
    painel.style.color = "#fff";
    painel.style.padding = "40px";
    painel.style.zIndex = "9999";

    painel.innerHTML = conteudo + "<br><br><button onclick='this.parentElement.remove()'>Fechar</button>";

    document.body.appendChild(painel);
}
</script>

