from pathlib import Path

arquivo = Path("orchestrator_cluster.py")

texto = arquivo.read_text(encoding="utf-8")

inicio = texto.find("def heartbeat_server():")
fim = texto.find("# =========================\n# START NODE")

novo = '''
def heartbeat_server():

    server = socket.socket(
        socket.AF_INET,
        socket.SOCK_STREAM
    )

    server.setsockopt(
        socket.SOL_SOCKET,
        socket.SO_REUSEADDR,
        1
    )

    server.bind((HOST, PORT))

    server.listen(20)

    print("[ORQUEST] heartbeat server rodando...")


    def handle_client(conn):

        try:

            data = conn.recv(1024).decode()

            if ":" in data:

                node_id = data.split(":")[0]

                if node_id in nodes:

                    nodes[node_id]["last"] = time.time()

                    print(
                        f"[HEARTBEAT] {node_id} atualizado"
                    )

        except Exception as e:

            print(f"[HEARTBEAT] erro: {e}")

        finally:

            conn.close()


    while True:

        try:

            conn, _ = server.accept()

            threading.Thread(
                target=handle_client,
                args=(conn,),
                daemon=True
            ).start()

        except Exception as e:

            print(f"[SERVER] erro accept: {e}")

'''

texto = texto[:inicio] + novo + texto[fim:]

arquivo.write_text(texto, encoding="utf-8")

print("[FIX] heartbeat_server atualizado")