﻿import time
from mail_reader import ler_emails  # seu mÃ³dulo

print("ðŸ§  NÃºcleo iniciado...")

while True:
    try:
        print("ðŸ”„ Verificando e-mails...")
        ler_emails()

    except Exception as e:
        print("Erro:", e)

    time.sleep(30)  # verifica a cada 30 segundos

