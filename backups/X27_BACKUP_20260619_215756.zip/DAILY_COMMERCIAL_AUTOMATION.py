import subprocess

print("")
print("====================================")
print("DAILY COMMERCIAL AUTOMATION")
print("====================================")
print("")

scripts = [

    "IMPORTADOR_EMPRESAS.py",
    "RADAR_COMERCIAL_IOTEC.py",
    "COMMERCIAL_OPPORTUNITY_ENGINE.py",
    "COMMERCIAL_CONVERSION_ENGINE.py",
    "PROPOSAL_GENERATOR.py",
    "COMMERCIAL_EXECUTIVE_REPORT.py"

]

for script in scripts:

    print("")
    print("EXECUTANDO:", script)
    print("")

    try:

        subprocess.run(

            ["python", script],

            check=True

        )

    except Exception as e:

        print("")
        print("ERRO:")
        print(e)
        print("")

print("")
print("====================================")
print("ROTINA FINALIZADA")
print("====================================")
print("")