﻿def executar_nucleo():

    setores = ["financeiro", "economico", "geral"]
    setor_escolhido = priorizar_setor(setores)

    api = escolher_api(setor_escolhido)

    if not api:
        registrar_mensagem(
            tipo="NECESSIDADE",
            modulo="CATALOGO",
            descricao=f"Sem API para setor {setor_escolhido}.",
            impacto="Bloqueio de exploraÃ§Ã£o.",
            acao="Adicionar fonte ao catÃ¡logo.",
            prioridade="ALTA"
        )
        return

    resultado = executar_coleta(api)

    if resultado["status"] == "SUCESSO":
        valor = resultado["valor"]
        custo = api["custo"]

        atualizar_perf(setor_escolhido, api["nome"], valor, custo, True)

        registrar_mensagem(
            tipo="OPORTUNIDADE",
            modulo="EXECUCAO",
            descricao=f"ExploraÃ§Ã£o bem-sucedida em {setor_escolhido} via {api['nome']}.",
            impacto="GeraÃ§Ã£o de valor confirmada.",
            acao="ReforÃ§ar este caminho.",
            prioridade="MÃ‰DIA"
        )
    else:
        atualizar_perf(setor_escolhido, api["nome"], 0.0, api["custo"], False)

        registrar_mensagem(
            tipo="ERRO",
            modulo="API",
            descricao=f"Falha ao executar {api['nome']} no setor {setor_escolhido}.",
            impacto="Perda de oportunidade.",
            acao="Testar alternativa ou revisar conexÃ£o.",
            prioridade="ALTA"
        )

