# ==========================================================
# IOTEC ALMA CORE v5
# CONSOLIDADOR ARQUITETURAL FINAL
# Núcleo vs Produto vs Legado vs Ruído Técnico
# ==========================================================

import os
from pathlib import Path
from collections import defaultdict, Counter
from datetime import datetime

ROOT_DIR = Path.cwd()

# ----------------------------------------------------------
# CLASSIFICAÇÃO ARQUITETURAL AVANÇADA
# ----------------------------------------------------------

NUCLEO = [
    "core", "master", "central", "kernel", "orchestrator",
    "engine", "system", "gateway", "brain", "main"
]

PRODUTO = [
    "portal", "frontend", "ui", "html", "client", "chat",
    "dashboard", "interface", "app"
]

LEGADO = [
    "backup", "legacy", "old", "archive", "dump", "v1", "v2", "v3"
]

INFRA = [
    "pipeline", "worker", "automation", "build", "script", "task"
]

DADOS = [
    "json", "csv", "data", "report", "analytics", "log"
]


# ----------------------------------------------------------
# CLASSIFICAÇÃO ARQUITETURAL REAL
# ----------------------------------------------------------
def classificar_arquitetura(nome: str):

    n = nome.lower()

    if any(k in n for k in NUCLEO):
        return "NUCLEO"

    if any(k in n for k in PRODUTO):
        return "PRODUTO"

    if any(k in n for k in INFRA):
        return "INFRAESTRUTURA"

    if any(k in n for k in DADOS):
        return "DADOS"

    if any(k in n for k in LEGADO):
        return "LEGADO"

    return "RUÍDO"


# ----------------------------------------------------------
# ESCANEAMENTO
# ----------------------------------------------------------
def escanear():
    mapa = defaultdict(list)

    for root, _, files in os.walk(ROOT_DIR):
        for f in files:
            path = str(Path(root) / f)
            categoria = classificar_arquitetura(f)
            mapa[categoria].append(path)

    return mapa


# ----------------------------------------------------------
# ANÁLISE DE ARQUITETURA
# ----------------------------------------------------------
def analisar(mapa):

    total = sum(len(v) for v in mapa.values())

    duplicados = Counter(
        [os.path.basename(p) for v in mapa.values() for p in v]
    )

    duplicados = {k: v for k, v in duplicados.items() if v > 1}

    return {
        "total": total,
        "nucleo": len(mapa.get("NUCLEO", [])),
        "produto": len(mapa.get("PRODUTO", [])),
        "infra": len(mapa.get("INFRAESTRUTURA", [])),
        "dados": len(mapa.get("DADOS", [])),
        "legado": len(mapa.get("LEGADO", [])),
        "ruido": len(mapa.get("RUÍDO", [])),
        "duplicados": len(duplicados),
        "top_duplicados": dict(list(duplicados.items())[:10])
    }


# ----------------------------------------------------------
# DIAGNÓSTICO ARQUITETURAL FINAL
# ----------------------------------------------------------
def diagnostico(r):

    alertas = []

    if r["nucleo"] < r["total"] * 0.03:
        alertas.append("🔴 Núcleo extremamente subdimensionado")

    if r["ruido"] > r["total"] * 0.4:
        alertas.append("⚠ Sistema com alto nível de indefinição estrutural (RUÍDO)")

    if r["legado"] > r["nucleo"] * 5:
        alertas.append("⚠ Legado excessivo dominando arquitetura atual")

    if r["produto"] < r["nucleo"] * 0.5:
        alertas.append("⚠ Baixa conversão de núcleo em produto")

    if r["duplicados"] > 10000:
        alertas.append("⚠ Duplicação estrutural crítica")

    return alertas


# ----------------------------------------------------------
# RELATÓRIO FINAL
# ----------------------------------------------------------
def relatorio(mapa):

    r = analisar(mapa)
    alertas = diagnostico(r)

    print("\n====================================")
    print("🧠 IOTEC ALMA CORE v5 - ARQUITETO FINAL")
    print("====================================\n")

    print(f"📦 TOTAL DE ATIVOS: {r['total']}\n")

    print("🏗 ARQUITETURA REAL:")
    print(f" - Núcleo: {r['nucleo']}")
    print(f" - Produto: {r['produto']}")
    print(f" - Infraestrutura: {r['infra']}")
    print(f" - Dados: {r['dados']}")
    print(f" - Legado: {r['legado']}")
    print(f" - Ruído: {r['ruido']}")
    print(f" - Duplicados: {r['duplicados']}\n")

    print("🚨 DIAGNÓSTICO ESTRUTURAL:")
    if alertas:
        for a in alertas:
            print(" ", a)
    else:
        print(" ✔ Arquitetura relativamente saudável")

    print("\n📌 TOP DUPLICADOS:")
    for k, v in r["top_duplicados"].items():
        print(f" - {k}: {v}")

    print("\n====================================")
    print(f"Timestamp: {datetime.now()}")
    print("====================================\n")


# ----------------------------------------------------------
# EXECUÇÃO
# ----------------------------------------------------------
def arquiteto_final():
    print("🧠 ALMA CORE v5 - ARQUITETO FINAL INICIADO\n")

    mapa = escanear()
    relatorio(mapa)

    print("✔ Consolidação arquitetural concluída.")


if __name__ == "__main__":
    arquiteto_final()