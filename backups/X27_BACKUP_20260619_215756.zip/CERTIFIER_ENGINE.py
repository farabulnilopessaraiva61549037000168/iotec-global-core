# ============================================================
# IOTEC / IBEX
# FRONT FAÇADE CERTIFIER ENGINE
# ============================================================
#
# OBJETIVO:
# - encontrar fachadas principais reais
# - diferenciar componente de portal
# - detectar interfaces cinematográficas
# - detectar dashboards completos
# - detectar UX avançada
# - detectar vídeos/imagens
# - detectar profundidade visual
# - selecionar front principal
# - montar grade de fachadas
# - alimentar programação contínua
#
# ============================================================

import os
import re
import json
from datetime import datetime

# ============================================================
# BASE
# ============================================================

BASE_PATH = r"C:\IOTEC"

# ============================================================
# DIRETÓRIOS
# ============================================================

REPORT_DIR = os.path.join(
    BASE_PATH,
    "FRONT_CERTIFIER"
)

os.makedirs(
    REPORT_DIR,
    exist_ok=True
)

# ============================================================
# LOG
# ============================================================

def log(message):

    timestamp = datetime.now().strftime(
        "%Y-%m-%d %H:%M:%S"
    )

    line = f"[{timestamp}] {message}"

    print(line)

    with open(

        os.path.join(
            REPORT_DIR,
            "FRONT_CERTIFIER.log"
        ),

        "a",
        encoding="utf-8"

    ) as f:

        f.write(line + "\n")

# ============================================================
# LOAD SIGNAL REPORT
# ============================================================

SIGNAL_REPORT = os.path.join(

    BASE_PATH,
    "TOWER_SIGNAL_REPORTS",
    "TOWER_CONNECTION_REPORT.json"
)

if not os.path.exists(
    SIGNAL_REPORT
):

    print("")
    print("================================================")
    print(" SIGNAL REPORT NOT FOUND")
    print("================================================")
    print("")

    exit()

with open(

    SIGNAL_REPORT,

    "r",

    encoding="utf-8"

) as f:

    SIGNAL_DATA = json.load(f)

# ============================================================
# PADRÕES CINEMATOGRÁFICOS
# ============================================================

VIDEO_PATTERNS = [

    "<video",
    ".mp4",
    "autoplay",
    "background-video",
    "hero-video"
]

IMAGE_PATTERNS = [

    "<img",
    "background-image",
    ".png",
    ".jpg",
    ".webp"
]

UX_PATTERNS = [

    "dashboard",
    "sidebar",
    "navbar",
    "card",
    "modal",
    "carousel",
    "grid",
    "analytics",
    "premium"
]

INTERACTION_PATTERNS = [

    "button",
    "onclick",
    "submit",
    "fetch(",
    "socket.io",
    "websocket"
]

CINEMATIC_PATTERNS = [

    "executive",
    "cinematic",
    "netflix",
    "govtech",
    "satellite",
    "ai",
    "control",
    "premium"
]

# ============================================================
# RESULTADOS
# ============================================================

RESULT = {

    "timestamp":
        str(datetime.now()),

    "fronts":
        [],

    "components":
        [],

    "cinematic":
        [],

    "premium":
        [],

    "dashboard":
        [],

    "video_enabled":
        [],

    "high_priority":
        [],

    "recommended_main_front":
        None
}

# ============================================================
# ANALISADOR
# ============================================================

def analyze_interface(path):

    try:

        with open(

            path,

            "r",

            encoding="utf-8",

            errors="ignore"

        ) as f:

            content = f.read()

        score = 0

        cinematic = False
        dashboard = False
        video = False
        component = False

        signals = []

        # ====================================================
        # TAMANHO
        # ====================================================

        size = len(content)

        if size > 10000:
            score += 5

        if size > 50000:
            score += 8

        # ====================================================
        # VÍDEO
        # ====================================================

        for pattern in VIDEO_PATTERNS:

            if pattern.lower() in content.lower():

                score += 6

                video = True

                signals.append(
                    pattern
                )

        # ====================================================
        # IMAGEM
        # ====================================================

        for pattern in IMAGE_PATTERNS:

            if pattern.lower() in content.lower():

                score += 2

                signals.append(
                    pattern
                )

        # ====================================================
        # UX
        # ====================================================

        for pattern in UX_PATTERNS:

            if pattern.lower() in content.lower():

                score += 4

                dashboard = True

                signals.append(
                    pattern
                )

        # ====================================================
        # INTERAÇÃO
        # ====================================================

        for pattern in INTERACTION_PATTERNS:

            if pattern.lower() in content.lower():

                score += 3

                signals.append(
                    pattern
                )

        # ====================================================
        # CINEMÁTICO
        # ====================================================

        for pattern in CINEMATIC_PATTERNS:

            if pattern.lower() in content.lower():

                score += 5

                cinematic = True

                signals.append(
                    pattern
                )

        # ====================================================
        # COMPONENTE
        # ====================================================

        name = os.path.basename(
            path
        ).lower()

        if (

            "button" in name
            or
            "input" in name
            or
            "card" in name
            or
            "modal" in name

        ):

            component = True

            score -= 8

        # ====================================================
        # CLASSIFICAÇÃO
        # ====================================================

        status = "COMPONENT"

        if score >= 25:

            status = "HIGH_PRIORITY_FRONT"

        elif score >= 18:

            status = "PREMIUM_FRONT"

        elif score >= 12:

            status = "DASHBOARD_FRONT"

        elif score >= 6:

            status = "VISUAL_FRONT"

        return {

            "file":
                os.path.basename(path),

            "path":
                path,

            "score":
                score,

            "status":
                status,

            "cinematic":
                cinematic,

            "dashboard":
                dashboard,

            "video":
                video,

            "component":
                component,

            "signals":
                signals
        }

    except:

        return None

# ============================================================
# PROCESSAMENTO
# ============================================================

log(
    "INICIANDO FRONT CERTIFIER..."
)

connected = SIGNAL_DATA.get(
    "connected",
    []
)

socket_wave = SIGNAL_DATA.get(
    "socketio",
    []
)

# ============================================================
# FONTES
# ============================================================

ALL_PATHS = []

for item in connected:

    ALL_PATHS.append(
        item["path"]
    )

for root, dirs, files in os.walk(BASE_PATH):

    for file in files:

        if file.lower().endswith(".html"):

            ALL_PATHS.append(

                os.path.join(
                    root,
                    file
                )
            )

# ============================================================
# ANÁLISE
# ============================================================

for path in ALL_PATHS:

    result = analyze_interface(
        path
    )

    if not result:
        continue

    # ========================================================
    # COMPONENTES
    # ========================================================

    if result["component"]:

        RESULT[
            "components"
        ].append(
            result
        )

        continue

    # ========================================================
    # VISUAL
    # ========================================================

    RESULT[
        "fronts"
    ].append(
        result
    )

    # ========================================================
    # CINEMATIC
    # ========================================================

    if result["cinematic"]:

        RESULT[
            "cinematic"
        ].append(
            result
        )

    # ========================================================
    # DASHBOARD
    # ========================================================

    if result["dashboard"]:

        RESULT[
            "dashboard"
        ].append(
            result
        )

    # ========================================================
    # VIDEO
    # ========================================================

    if result["video"]:

        RESULT[
            "video_enabled"
        ].append(
            result
        )

    # ========================================================
    # PRIORIDADE
    # ========================================================

    if result["status"] == "HIGH_PRIORITY_FRONT":

        RESULT[
            "high_priority"
        ].append(
            result
        )

        log(
            f"HIGH PRIORITY: {result['file']}"
        )

# ============================================================
# FACHADA PRINCIPAL
# ============================================================

if RESULT["high_priority"]:

    sorted_fronts = sorted(

        RESULT["high_priority"],

        key=lambda x: x["score"],

        reverse=True
    )

    RESULT[
        "recommended_main_front"
    ] = sorted_fronts[0]

# ============================================================
# EXPORTAÇÃO
# ============================================================

EXPORT = os.path.join(

    REPORT_DIR,

    "FRONT_FACADE_REPORT.json"
)

with open(

    EXPORT,

    "w",

    encoding="utf-8"

) as f:

    json.dump(

        RESULT,

        f,

        indent=4,

        ensure_ascii=False
    )

# ============================================================
# RESUMO
# ============================================================

print("")
print("================================================")
print(" IOTEC / IBEX FRONT CERTIFIER")
print("================================================")
print("")

print(
    f"FRONTS: "
    f"{len(RESULT['fronts'])}"
)

print(
    f"CINEMATIC: "
    f"{len(RESULT['cinematic'])}"
)

print(
    f"DASHBOARD: "
    f"{len(RESULT['dashboard'])}"
)

print(
    f"VIDEO ENABLED: "
    f"{len(RESULT['video_enabled'])}"
)

print(
    f"HIGH PRIORITY: "
    f"{len(RESULT['high_priority'])}"
)

print(
    f"COMPONENTS: "
    f"{len(RESULT['components'])}"
)

print("")

if RESULT["recommended_main_front"]:

    print("================================================")
    print(" RECOMMENDED MAIN FRONT")
    print("================================================")
    print("")

    print(
        RESULT[
            "recommended_main_front"
        ]["file"]
    )

    print("")

print("================================================")
print(" FRONT CERTIFICATION COMPLETE")
print("================================================")
print("")

log(
    "FRONT CERTIFIER FINALIZADO."
)