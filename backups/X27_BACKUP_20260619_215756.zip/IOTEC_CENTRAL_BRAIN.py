﻿import os
import importlib
import traceback

# ============================
# IOTEC CENTRAL BRAIN
# ============================

class CentralBrain:

    def __init__(self, root_path):
        self.root = root_path
        self.modules = {}
        self.logs = []

    # ========================
    # 1. MAPEAR NÃšCLEO
    # ========================
    def scan_core(self):
        print("\n[BRAIN] Escaneando nÃºcleo...\n")

        for root, dirs, files in os.walk(self.root):
            for file in files:

                if file.endswith(".py") and "test" not in file.lower():

                    path = os.path.join(root, file)
                    module_name = file.replace(".py", "")

                    self.modules[module_name] = path

        print(f"[BRAIN] {len(self.modules)} mÃ³dulos encontrados")

    # ========================
    # 2. IDENTIFICAR CAMADAS
    # ========================
    def classify_modules(self):

        self.layers = {
            "orchestration": [],
            "commercial": [],
            "operational": [],
            "unknown": []
        }

        for name, path in self.modules.items():

            lower = name.lower()

            if any(x in lower for x in ["orchestrator", "engine", "core", "manager"]):
                self.layers["orchestration"].append(name)

            elif any(x in lower for x in ["whatsapp", "mail", "pay", "paypal", "lead", "chat"]):
                self.layers["commercial"].append(name)

            elif any(x in lower for x in ["queue", "worker", "pipeline", "monitor", "traffic"]):
                self.layers["operational"].append(name)

            else:
                self.layers["unknown"].append(name)

        print("\n[BRAIN] ClassificaÃ§Ã£o concluÃ­da")
        for k, v in self.layers.items():
            print(f"  {k}: {len(v)} mÃ³dulos")

    # ========================
    # 3. DEFINIR ORQUESTRADOR ÃšNICO
    # ========================
    def select_master_orchestrator(self):

        candidates = self.layers["orchestration"]

        if not candidates:
            print("\n[BRAIN] Nenhum orquestrador encontrado. Sistema em estado fragmentado.")
            return None

        # regra simples: primeiro candidato vira cÃ©rebro (ajustÃ¡vel depois)
        self.master = candidates[0]

        print(f"\n[BRAIN] ORQUESTRADOR PRINCIPAL DEFINIDO: {self.master}")
        return self.master

    # ========================
    # 4. SIMULAR EXECUÃ‡ÃƒO CONTROLADA
    # ========================
    def simulate_control_flow(self):

        print("\n[BRAIN] Simulando fluxo de controle...\n")

        if not hasattr(self, "master"):
            print("[BRAIN] Sem cÃ©rebro definido.")
            return

        print(f"[BRAIN] Entrada â†’ {self.master}")
        print("[BRAIN] Fluxo estimado:")

        for layer, modules in self.layers.items():
            print(f"  â†’ {layer}: {len(modules)} mÃ³dulos conectados")

    # ========================
    # 5. DIAGNÃ“STICO FINAL
    # ========================
    def report(self):

        print("\n===================================")
        print("IOTEC CENTRAL BRAIN REPORT")
        print("===================================\n")

        total = len(self.modules)

        print(f"MÃ³dulos totais: {total}")
        print(f"Orquestradores: {len(self.layers['orchestration'])}")
        print(f"Comercial: {len(self.layers['commercial'])}")
        print(f"Operacional: {len(self.layers['operational'])}")
        print(f"NÃ£o classificados: {len(self.layers['unknown'])}")

        print("\nSTATUS DO SISTEMA:")

        if len(self.layers["orchestration"]) >= 1:
            print("âœ” POSSUI CÃ‰REBRO POTENCIAL")
        else:
            print("âš  SEM CÃ‰REBRO DEFINIDO")

        if total > 1000:
            print("âœ” SISTEMA DE GRANDE ESCALA")
        else:
            print("âš  SISTEMA EM ESCALA MÃ‰DIA")

        print("\n===================================")

# ============================
# EXECUÃ‡ÃƒO
# ============================

if __name__ == "__main__":

    path = input("Digite o caminho do nÃºcleo: ").strip()

    brain = CentralBrain(path)

    brain.scan_core()
    brain.classify_modules()
    brain.select_master_orchestrator()
    brain.simulate_control_flow()
    brain.report()

