﻿# =========================================================
# IOTEC AI v3
# ORQUESTRADOR EMPRESARIAL INTELIGENTE
# Arquitetura Conversacional Moderna
# =========================================================

import time

# =========================================================
# NÃšCLEO PRINCIPAL
# =========================================================

class IOTEC_AI:

    def __init__(self):

        self.memoria = {}

        self.base_conhecimento = {
            "moda": [
                "Controle de estoque",
                "GestÃ£o de pedidos",
                "Dashboard financeiro",
                "Rastreamento logÃ­stico",
                "CatÃ¡logo de produtos",
                "AutomaÃ§Ã£o de vendas"
            ],

            "educaÃ§Ã£o": [
                "DiÃ¡rio eletrÃ´nico",
                "Painel acadÃªmico",
                "Controle de alunos",
                "RelatÃ³rios escolares",
                "AutomaÃ§Ã£o pedagÃ³gica"
            ],

            "saÃºde": [
                "ProntuÃ¡rio digital",
                "Agendamento",
                "Dashboard clÃ­nico",
                "Controle financeiro",
                "GestÃ£o de pacientes"
            ]
        }

    # =====================================================
    # ANIMAÃ‡ÃƒO IA
    # =====================================================

    def pensar(self, texto):

        print(f"\n[IA] {texto}")

        time.sleep(1)

    # =====================================================
    # INICIAR
    # =====================================================

    def iniciar(self):

        print("\n================================================")
        print("        IOTEC AI - CORE ENTERPRISE")
        print("================================================")

        mensagem = input(
            "\n[IA] Descreva o que sua empresa precisa:\n\n>>> "
        )

        self.memoria["pedido_inicial"] = mensagem

        self.interpretar_intencao(mensagem)

        self.investigar_empresa()

        self.sugerir_funcionalidades()

        self.gerar_analise()

    # =====================================================
    # INTERPRETAR INTENÃ‡ÃƒO
    # =====================================================

    def interpretar_intencao(self, mensagem):

        texto = mensagem.lower()

        self.pensar("Interpretando solicitaÃ§Ã£o...")

        # -------------------------------------------------
        # DETECÃ‡ÃƒO DE NECESSIDADE
        # -------------------------------------------------

        if "sistema" in texto:

            necessidade = "Sistema Empresarial"

        elif "auditoria" in texto:

            necessidade = "Auditoria Inteligente"

        elif "dashboard" in texto:

            necessidade = "Business Intelligence"

        else:

            necessidade = "ServiÃ§o Personalizado"

        self.memoria["necessidade"] = necessidade

        self.pensar(f"Necessidade detectada: {necessidade}")

    # =====================================================
    # INVESTIGAÃ‡ÃƒO
    # =====================================================

    def investigar_empresa(self):

        print("\n================================================")
        print("         INVESTIGAÃ‡ÃƒO EMPRESARIAL")
        print("================================================")

        # -------------------------------------------------
        # SETOR
        # -------------------------------------------------

        setor = input(
            "\n[IA] Qual Ã© o setor da sua empresa?\n\n>>> "
        ).lower()

        self.memoria["setor"] = setor

        # -------------------------------------------------
        # PROBLEMAS
        # -------------------------------------------------

        problemas = input(
            "\n[IA] Quais problemas sua empresa enfrenta atualmente?\n\n>>> "
        ).lower()

        self.memoria["problemas"] = problemas

        # -------------------------------------------------
        # USUÃRIOS
        # -------------------------------------------------

        usuarios = input(
            "\n[IA] Quantas pessoas utilizarÃ£o o sistema?\n\n>>> "
        )

        self.memoria["usuarios"] = usuarios

        # -------------------------------------------------
        # OBJETIVO
        # -------------------------------------------------

        objetivo = input(
            "\n[IA] Qual Ã© o principal objetivo do sistema?\n\n>>> "
        ).lower()

        self.memoria["objetivo"] = objetivo

    # =====================================================
    # MOTOR DE RECOMENDAÃ‡ÃƒO
    # =====================================================

    def sugerir_funcionalidades(self):

        self.pensar("Analisando estrutura operacional...")
        self.pensar("Detectando gargalos internos...")
        self.pensar("Gerando recomendaÃ§Ãµes inteligentes...")

        setor = self.memoria["setor"]
        problemas = self.memoria["problemas"]

        sugestoes = []

        # -------------------------------------------------
        # BASE POR SETOR
        # -------------------------------------------------

        if setor in self.base_conhecimento:

            sugestoes.extend(
                self.base_conhecimento[setor]
            )

        # -------------------------------------------------
        # ANÃLISE DE PROBLEMAS
        # -------------------------------------------------

        if "financeiro" in problemas:

            sugestoes.extend([
                "Fluxo de caixa automatizado",
                "RelatÃ³rios financeiros",
                "Controle de faturamento"
            ])

        if "logistica" in problemas or "pedido" in problemas:

            sugestoes.extend([
                "GestÃ£o logÃ­stica",
                "Rastreamento de pedidos",
                "AutomaÃ§Ã£o operacional"
            ])

        if "estoque" in problemas:

            sugestoes.extend([
                "Controle inteligente de estoque"
            ])

        # -------------------------------------------------
        # REMOVER DUPLICADOS
        # -------------------------------------------------

        sugestoes = list(set(sugestoes))

        self.memoria["funcionalidades_sugeridas"] = sugestoes

        print("\n================================================")
        print("      FUNCIONALIDADES RECOMENDADAS")
        print("================================================")

        for item in sugestoes:

            print(f"\nâœ… {item}")

        resposta = input(
            "\n[IA] Deseja incluir essas funcionalidades no projeto?\n\n>>> "
        ).lower()

        self.memoria["confirmacao_funcionalidades"] = resposta

    # =====================================================
    # GERAR ANÃLISE
    # =====================================================

    def gerar_analise(self):

        self.pensar("Gerando diagnÃ³stico empresarial...")
        self.pensar("Calculando arquitetura ideal...")
        self.pensar("Encaminhando para nÃºcleo operacional...")

        print("\n================================================")
        print("          RELATÃ“RIO ESTRATÃ‰GICO")
        print("================================================")

        for chave, valor in self.memoria.items():

            print(f"\n{chave.upper()}:")

            if isinstance(valor, list):

                for item in valor:

                    print(f" - {item}")

            else:

                print(valor)

        print("\n================================================")

        print("[IA] DiagnÃ³stico concluÃ­do.")
        print("[IA] Escopo tÃ©cnico preparado.")
        print("[IA] Ordem de produÃ§Ã£o iniciada.")
        print("[IA] Sistema interno assumirÃ¡ a operaÃ§Ã£o.")

# =========================================================
# EXECUÃ‡ÃƒO
# =========================================================

if __name__ == "__main__":

    ia = IOTEC_AI()

    ia.iniciar()

