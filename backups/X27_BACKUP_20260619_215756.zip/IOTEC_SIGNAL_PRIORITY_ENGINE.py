from datetime import datetime

print("")
print("===================================")
print("IOTEC SIGNAL PRIORITY ENGINE")
print("===================================")

print("")
print("DATA:")
print(datetime.now())

print("")
print("MISSAO:")
print(
    "CLASSIFICAR SINAIS POR "
    "IMPACTO, URGENCIA E "
    "POTENCIAL ECONOMICO"
)

sinais = [

    {
        "nome": "ESTIAGEM_CEARA",
        "impacto": 10,
        "urgencia": 10,
        "orcamento": 9
    },

    {
        "nome": "ENCHENTE_REGIONAL",
        "impacto": 8,
        "urgencia": 8,
        "orcamento": 7
    },

    {
        "nome": "QUEDA_DE_PRODUCAO",
        "impacto": 7,
        "urgencia": 6,
        "orcamento": 8
    }
]

print("")
print("===================================")
print("SINAIS ANALISADOS")
print("===================================")

ranking = []

for sinal in sinais:

    score = (
        sinal["impacto"]
        *
        sinal["urgencia"]
        *
        sinal["orcamento"]
    )

    ranking.append(
        {
            "nome": sinal["nome"],
            "score": score
        }
    )

ranking.sort(
    key=lambda x: x["score"],
    reverse=True
)

for item in ranking:

    print("")
    print("SINAL:")
    print(item["nome"])

    print("PRIORIDADE:")
    print(item["score"])

print("")
print("===================================")
print("LOGICA")
print("===================================")

print("FONTE")
print("↓")
print("SINAL")
print("↓")
print("IMPACTO")
print("↓")
print("URGENCIA")
print("↓")
print("ORCAMENTO")
print("↓")
print("PRIORIDADE")
print("↓")
print("PRODUTO")
print("↓")
print("RECEITA")

print("")
print("PERGUNTA CENTRAL:")

print(
    "QUAL O PROBLEMA MAIS "
    "IMPORTANTE PARA ATUAR AGORA?"
)

print("")
print("ORDEM MOR:")

print(
    "ATACAR PRIMEIRO OS "
    "PROBLEMAS COM MAIOR "
    "IMPACTO E MAIOR "
    "POTENCIAL DE MERCADO."
)

print("")
print("NUCLEO DE PRIORIZACAO ATIVO")