﻿import os

BASE = os.path.join(os.path.expanduser("~"), "Desktop", "OFICINA_IOTEC")

print("ðŸ” Verificando:", BASE)
print("="*50)

if not os.path.exists(BASE):
    print("âŒ PASTA NÃƒO EXISTE")
else:
    for raiz, dirs, arquivos in os.walk(BASE):
        print("\nðŸ“", raiz)
        for a in arquivos:
            print("   -", a)

