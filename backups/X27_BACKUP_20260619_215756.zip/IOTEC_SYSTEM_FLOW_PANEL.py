﻿# ============================================================
# IOTEC_SYSTEM_FLOW_PANEL.py
# Painel de fluxo: Entrada â†’ DecisÃ£o â†’ SaÃ­da
# ============================================================

import streamlit as st
import random
import time

st.set_page_config(layout="wide")

st.title("ðŸ§  IOTEC - Fluxo do NÃºcleo")
st.subheader("Entrada â†’ DecisÃ£o â†’ SaÃ­da (Sistema Vivo)")

# =========================
# ESTADO
# =========================

if "entradas" not in st.session_state:
    st.session_state.entradas = []

if "decisoes" not in st.session_state:
    st.session_state.decisoes = []

if "saidas" not in st.session_state:
    st.session_state.saidas = []

if "bloqueios" not in st.session_state:
    st.session_state.bloqueios = []

# =========================
# GERAR ENTRADA (simulaÃ§Ã£o)
# =========================

def gerar_entrada():
    setores = ["PÃºblico", "PME", "Agro", "Tech", "MÃ­dia"]
    return {
        "setor": random.choice(setores),
        "score": random.randint(5, 40)
    }

# =========================
# DECISÃƒO
# =========================

def decidir(entrada):

    score = entrada["score"]

    if score >= 30:
        return "saida"

    elif score >= 20:
        return "monitorar"

    elif score >= 10:
        return "esperar"

    else:
        return "bloqueio"

# =========================
# CICLO
# =========================

def rodar_ciclo():

    entrada = gerar_entrada()
    st.session_state.entradas.append(entrada)

    decisao = decidir(entrada)
    st.session_state.decisoes.append(decisao)

    if decisao == "saida":
        st.session_state.saidas.append(entrada)

    elif decisao == "bloqueio":
        st.session_state.bloqueios.append(entrada)

# =========================
# BOTÃƒO
# =========================

if st.button("ðŸš€ Rodar Ciclo"):
    rodar_ciclo()

# =========================
# EXIBIÃ‡ÃƒO
# =========================

col1, col2, col3, col4 = st.columns(4)

# ENTRADAS
with col1:
    st.markdown("### ðŸ“¥ Entradas")
    for e in st.session_state.entradas[-5:]:
        st.write(e)

# DECISÃ•ES
with col2:
    st.markdown("### ðŸ§  DecisÃµes")
    for d in st.session_state.decisoes[-5:]:
        st.write(d)

# SAÃDAS
with col3:
    st.markdown("### ðŸš€ SaÃ­das")
    for s in st.session_state.saidas[-5:]:
        st.write(s)

# BLOQUEIOS
with col4:
    st.markdown("### ðŸ”´ Bloqueios")
    for b in st.session_state.bloqueios[-5:]:
        st.write(b)

# =========================
# RESUMO
# =========================

st.markdown("### ðŸ“Š Resumo do Sistema")

total = len(st.session_state.entradas)
saidas = len(st.session_state.saidas)
bloqueios = len(st.session_state.bloqueios)

c1, c2, c3 = st.columns(3)

c1.metric("Entradas", total)
c2.metric("SaÃ­das", saidas)
c3.metric("Bloqueios", bloqueios)

