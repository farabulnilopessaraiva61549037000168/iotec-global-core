﻿# ============================================================
# DETECÃ‡ÃƒO DE ALTO RETORNO
# ============================================================

def verificar_roi_alto(setor, api_nome):
    data = carregar_perf()
    chave = f"{setor}:{api_nome}"

    if chave not in data:
        return False

    roi = calcular_roi(data[chave])

    if roi > 5:
        registrar_mensagem(
            tipo="ALAVANCAGEM",
            modulo="ESTRATEGIA",
            descricao=f"ROI alto detectado em {setor} via {api_nome}.",
            impacto="Alta geraÃ§Ã£o de valor.",
            acao="Aumentar frequÃªncia de execuÃ§Ã£o.",
            prioridade="ALTA"
        )
        return True

    return False

