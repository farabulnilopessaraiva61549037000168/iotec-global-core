﻿conteudo = f"""
===============================
IOTEC - RELATÃ“RIO TÃ‰CNICO
===============================

Data: {datetime.now().strftime("%Y-%m-%d")}
Pedido: {pedido['id']}

ServiÃ§o: {pedido['servico']}

ðŸ“Š AnÃ¡lise:
Este relatÃ³rio foi gerado com base em processamento tÃ©cnico de dados.

âš™ï¸ O que foi feito:
- Coleta de dados
- OrganizaÃ§Ã£o
- InterpretaÃ§Ã£o tÃ©cnica

ðŸ“ˆ Resultado:
Sistema validado e operando.

ðŸ” ObservaÃ§Ã£o:
Este Ã© um produto digital baseado em dados.

===============================
"""

