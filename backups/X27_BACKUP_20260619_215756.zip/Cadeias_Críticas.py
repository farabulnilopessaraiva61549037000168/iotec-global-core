CADEIAS_CRITICAS = {

    "AGUA": [

        "RESERVATORIOS",
        "TRATAMENTO",
        "DISTRIBUICAO",
        "POPULACAO"

    ],

    "ALIMENTOS": [

        "PRODUCAO",
        "ARMAZENAMENTO",
        "TRANSPORTE",
        "MERCADOS"

    ],

    "ENERGIA": [

        "GERACAO",
        "TRANSMISSAO",
        "DISTRIBUICAO",
        "CONSUMO"

    ]

}