# ============================================================
# AURORA ECOSYSTEM CORE
# ============================================================
# IOTEC EDU ECOSYSTEM
#
# Centro de Inteligência Climática, Territorial,
# Humanitária e Resiliência Operacional
#
# Autor da Visão: Bruno Lopes
# ============================================================

from datetime import datetime

# ============================================================
# CONFIGURAÇÕES GERAIS
# ============================================================

AURORA = {
    "nome": "AURORA",
    "versao": "1.0",
    "status": "ONLINE",
    "inicializacao": datetime.now().strftime("%d/%m/%Y %H:%M:%S")
}

# ============================================================
# MÓDULOS
# ============================================================

MODULOS = {
    "WATCH": "Monitoramento climático e territorial",
    "PREDICT": "Modelagem matemática e previsão",
    "SHIELD": "Protocolos preventivos",
    "RESPONSE": "Resposta operacional",
    "SENTINEL": "Observância e auditoria",
    "WAR_ROOM": "Sala de guerra estratégica",
    "COMMERCIAL": "Relacionamento institucional"
}

# ============================================================
# EVENTOS MONITORADOS
# ============================================================

EVENTOS = [
    "Seca",
    "Estiagem",
    "Onda de Calor",
    "Frio Extremo",
    "Enchente",
    "Inundação",
    "Deslizamento",
    "Queimada",
    "Incêndio Florestal",
    "Colapso Hídrico",
    "Falha Energética"
]

# ============================================================
# GRUPOS PRIORITÁRIOS
# ============================================================

VULNERABILIDADES = [
    "Crianças",
    "Idosos",
    "Gestantes",
    "Pessoas com Deficiência",
    "Pessoas com Mobilidade Reduzida",
    "Pacientes Dependentes de Tratamento",
    "Famílias em Vulnerabilidade Social"
]

# ============================================================
# FONTES ESTRATÉGICAS
# ============================================================

FONTES = [
    "INMET",
    "ANA",
    "CEMADEN",
    "Defesa Civil",
    "Institutos de Pesquisa",
    "Universidades",
    "Satélites",
    "Sensores Territoriais"
]

# ============================================================
# PROTOCOLOS
# ============================================================

PROTOCOLOS = {
    "SECA": [
        "Monitorar reservatórios",
        "Planejar abastecimento",
        "Mapear áreas vulneráveis",
        "Acionar defesa civil"
    ],

    "ENCHENTE": [
        "Avaliar áreas de risco",
        "Abrir abrigos",
        "Planejar evacuação",
        "Acionar equipes de resposta"
    ],

    "ONDA_DE_CALOR": [
        "Criar centros de resfriamento",
        "Distribuir água",
        "Monitorar grupos vulneráveis"
    ]
}

# ============================================================
# ABORDAGEM COMERCIAL
# ============================================================

def apresentar_iotec():

    print("\n================================================")
    print("APRESENTAÇÃO INSTITUCIONAL")
    print("================================================\n")

    print("Bom dia.")
    print("Somos o ecossistema IOTEC.")
    print("Trabalhamos com inteligência aplicada à")
    print("tomada de decisão, monitoramento e gestão de riscos.")
    print()
    print("Objetivo:")
    print("Transformar dados em decisões.")
    print()
    print("Não vendemos apenas tecnologia.")
    print("Entregamos capacidade de antecipação.")
    print()

# ============================================================
# WAR ROOM
# ============================================================

def war_room():

    print("\n================================================")
    print("AURORA WAR ROOM")
    print("================================================")

    print("\nRISCOS MONITORADOS:")

    for evento in EVENTOS:
        print(f"[MONITORANDO] {evento}")

# ============================================================
# SENTINEL
# ============================================================

def sentinel():

    print("\n================================================")
    print("AURORA SENTINEL")
    print("================================================")

    for fonte in FONTES:
        print(f"[OK] Fonte registrada: {fonte}")

# ============================================================
# BOOT
# ============================================================

def iniciar_aurora():

    print("=" * 60)
    print("AURORA ONLINE")
    print("=" * 60)

    print(f"\nVERSÃO: {AURORA['versao']}")
    print(f"STATUS : {AURORA['status']}")
    print(f"INÍCIO : {AURORA['inicializacao']}")

    print("\nMÓDULOS CARREGADOS:\n")

    for nome, descricao in MODULOS.items():
        print(f"[OK] {nome} -> {descricao}")

    sentinel()
    war_room()

    print("\n================================================")
    print("CENTRO DE INTELIGÊNCIA INICIALIZADO")
    print("================================================")

# ============================================================
# EXECUÇÃO
# ============================================================

if __name__ == "__main__":
    iniciar_aurora()