﻿# ============================================================
# IOTEC HYPERCORE SHIELD
# LATENCY + RESILIENCE RECOVERY ENGINE
# ============================================================

import time
import json
import random
import psutil
from pathlib import Path
from datetime import datetime

# ============================================================
# BASE
# ============================================================

BASE = Path(
    "C:/IOTEC_HYPERCORE_SHIELD"
)

BASE.mkdir(
    parents=True,
    exist_ok=True
)

# ============================================================
# MODULOS
# ============================================================

MODULOS = {

    "FRONTEND": {
        "latencia": 480
    },

    "IA_ENGINE": {
        "latencia": 1800
    },

    "DATABASE": {
        "latencia": 320
    },

    "STREAMING": {
        "latencia": 2600
    },

    "AUTH": {
        "latencia": 240
    },

    "UPLOAD": {
        "latencia": 1100
    },

    "WEBSOCKET": {
        "latencia": 1700
    }

}

# ============================================================
# ACOES
# ============================================================

ACOES_GLOBAIS = []

RESULTADOS = []

# ============================================================
# FUNCOES
# ============================================================

def cpu():

    return round(
        psutil.cpu_percent(),
        2
    )

def ram():

    return round(
        psutil.virtual_memory().percent,
        2
    )

def reduzir_latencia(valor):

    reducao = random.uniform(
        0.35,
        0.70
    )

    return round(
        valor * (1 - reducao),
        2
    )

# ============================================================
# ENGINE DE RECUPERACAO
# ============================================================

def otimizar(

    modulo,
    latencia

):

    melhorias = []

    nova_latencia = latencia

    # ========================================================
    # CDN
    # ========================================================

    if latencia > 300:

        melhorias.append(
            "CDN GLOBAL"
        )

        nova_latencia *= 0.82

    # ========================================================
    # CACHE
    # ========================================================

    if latencia > 500:

        melhorias.append(
            "CACHE DISTRIBUIDO"
        )

        nova_latencia *= 0.80

    # ========================================================
    # FILAS
    # ========================================================

    if latencia > 800:

        melhorias.append(
            "MODO ASSINCRONO"
        )

        melhorias.append(
            "FILA INTELIGENTE"
        )

        nova_latencia *= 0.72

    # ========================================================
    # EDGE
    # ========================================================

    if latencia > 1200:

        melhorias.append(
            "EDGE SERVER"
        )

        melhorias.append(
            "LOAD BALANCER"
        )

        nova_latencia *= 0.65

    # ========================================================
    # AUTOSCALING
    # ========================================================

    if latencia > 1800:

        melhorias.append(
            "AUTOSCALING"
        )

        nova_latencia *= 0.60

    # ========================================================
    # STREAMING
    # ========================================================

    if modulo == "STREAMING":

        melhorias.append(
            "COMPRESSAO ADAPTATIVA"
        )

        melhorias.append(
            "STREAMING DISTRIBUIDO"
        )

        melhorias.append(
            "EDGE VIDEO"
        )

        nova_latencia *= 0.58

    # ========================================================
    # IA
    # ========================================================

    if modulo == "IA_ENGINE":

        melhorias.append(
            "IA ASSINCRONA"
        )

        melhorias.append(
            "CACHE DE INFERENCIA"
        )

        melhorias.append(
            "WORKERS IA"
        )

        nova_latencia *= 0.62

    # ========================================================
    # WEBSOCKET
    # ========================================================

    if modulo == "WEBSOCKET":

        melhorias.append(
            "CLUSTER WEBSOCKET"
        )

        melhorias.append(
            "EDGE REALTIME"
        )

        nova_latencia *= 0.66

    return round(
        nova_latencia,
        2
    ), list(set(melhorias))

# ============================================================
# TERMINAL
# ============================================================

print()
print("===================================================")
print(" IOTEC HYPERCORE SHIELD")
print(" LATENCY RECOVERY ENGINE")
print("===================================================")

# ============================================================
# TESTES
# ============================================================

for modulo in MODULOS:

    print()
    print("===================================================")

    print(
        f"MODULO -> {modulo}"
    )

    print("===================================================")

    latencia_original = MODULOS[modulo]["latencia"]

    latencia_otimizada, melhorias = otimizar(

        modulo,
        latencia_original

    )

    ganho = round(

        (
            (
                latencia_original
                - latencia_otimizada
            )
            / latencia_original
        ) * 100,

        2

    )

    uso_cpu = cpu()

    uso_ram = ram()

    rps = int(

        random.uniform(
            40000,
            300000
        )

    )

    # ========================================================
    # STATUS
    # ========================================================

    if latencia_otimizada < 300:

        status = "ULTRA ESTAVEL"

    elif latencia_otimizada < 700:

        status = "ESTAVEL"

    elif latencia_otimizada < 1200:

        status = "ALERTA"

    else:

        status = "CRITICO"

    # ========================================================
    # RESULTADO
    # ========================================================

    resultado = {

        "modulo":
        modulo,

        "latencia_original":
        latencia_original,

        "latencia_otimizada":
        latencia_otimizada,

        "ganho_percentual":
        ganho,

        "cpu":
        uso_cpu,

        "ram":
        uso_ram,

        "rps":
        rps,

        "status":
        status,

        "melhorias":
        melhorias

    }

    RESULTADOS.append(
        resultado
    )

    ACOES_GLOBAIS.extend(
        melhorias
    )

    # ========================================================
    # TERMINAL
    # ========================================================

    print()
    print(
        f"LATENCIA ORIGINAL -> {latencia_original}ms"
    )

    print(
        f"LATENCIA OTIMIZADA -> {latencia_otimizada}ms"
    )

    print(
        f"GANHO -> {ganho}%"
    )

    print(
        f"CPU -> {uso_cpu}%"
    )

    print(
        f"RAM -> {uso_ram}%"
    )

    print(
        f"RPS -> {rps}"
    )

    print(
        f"STATUS -> {status}"
    )

    print()
    print("ACOES:")

    for item in melhorias:

        print(
            f" [+] {item}"
        )

    time.sleep(1)

# ============================================================
# RELATORIO
# ============================================================

RELATORIO = {

    "empresa": "IOTEC",

    "timestamp":
    str(datetime.now()),

    "acoes_globais":
    list(set(ACOES_GLOBAIS)),

    "resultados":
    RESULTADOS

}

# ============================================================
# EXPORTACAO
# ============================================================

ARQUIVO = BASE / "HYPERCORE_SHIELD_REPORT.json"

with open(

    ARQUIVO,

    "w",
    encoding="utf-8"

) as f:

    json.dump(
        RELATORIO,
        f,
        indent=4,
        ensure_ascii=False
    )

# ============================================================
# FINAL
# ============================================================

print()
print("===================================================")
print(" OTIMIZACOES GLOBAIS")
print("===================================================")

for item in list(set(ACOES_GLOBAIS)):

    print(
        f" [+] {item}"
    )

print()
print("===================================================")
print(" EXPORTACAO")
print("===================================================")

print()
print(
    f"ARQUIVO -> {ARQUIVO}"
)

print()
print("===================================================")
print(" HYPERCORE SHIELD FINALIZADO")
print("===================================================")

