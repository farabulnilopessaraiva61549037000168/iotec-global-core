﻿import uuid
import time
from datetime import datetime


class Module:

    def __init__(self, name, category, priority):

        self.id = f"MOD-{uuid.uuid4().hex[:8].upper()}"
        self.name = name
        self.category = category
        self.priority = priority
        self.status = "ACTIVE"

    def execute(self):

        print(f"\n[EXECUTION] {self.name}")
        print(f"ID: {self.id}")
        print(f"CATEGORY: {self.category}")
        print(f"STATUS: {self.status}")
        print(f"TIME: {datetime.now()}")


class SpineCore:

    def __init__(self):

        self.modules = []

    def boot(self):

        print("\n========================================")
        print("       IOTEC SPINE CORE ONLINE")
        print("========================================")

    def add_module(self, module):

        self.modules.append(module)

        print("\n[REGISTRY]")
        print(f"MODULE REGISTERED: {module.name}")

    def list_modules(self):

        print("\n========== ACTIVE MODULES ==========")

        ordered = sorted(
            self.modules,
            key=lambda x: x.priority,
            reverse=True
        )

        for idx, mod in enumerate(ordered, start=1):

            print(
                f"{idx}. {mod.name} | "
                f"{mod.category} | "
                f"PRIORITY {mod.priority}"
            )

    def execute_all(self):

        print("\n========== ORCHESTRATED EXECUTION ==========")

        ordered = sorted(
            self.modules,
            key=lambda x: x.priority,
            reverse=True
        )

        for mod in ordered:

            mod.execute()

            time.sleep(0.5)


if __name__ == "__main__":

    core = SpineCore()

    core.boot()

    sales = Module(
        "Commercial Intelligence",
        "BUSINESS",
        10
    )

    media = Module(
        "Luxury Media Engine",
        "MEDIA",
        8
    )

    automation = Module(
        "Automation Spine",
        "AUTOMATION",
        9
    )

    advisor = Module(
        "Technical Advisor",
        "COORDINATION",
        10
    )

    core.add_module(sales)
    core.add_module(media)
    core.add_module(automation)
    core.add_module(advisor)

    core.list_modules()

    core.execute_all()

    print("\n========================================")
    print(" IOTEC CORE STABLE")
    print("========================================")

