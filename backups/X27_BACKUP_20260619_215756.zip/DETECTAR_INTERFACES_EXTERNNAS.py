﻿import os

def buscar_interfaces():
    locais = [
        "C:\\IoTec\\interfaces_origem",
        os.path.join(os.environ["USERPROFILE"], "Desktop", "OFICINA_IOTEC")
    ]

    arquivos = []
    nomes_vistos = set()

    for local in locais:
        print(f"\nðŸ” Verificando: {local}")

        if os.path.exists(local):
            for root, dirs, files in os.walk(local):
                for file in files:
                    if file.endswith((".html", ".htm")):

                        if file not in nomes_vistos:
                            caminho = os.path.join(root, file)
                            arquivos.append(caminho)
                            nomes_vistos.add(file)

                            print(f"âœ” Adicionado: {caminho}")
                        else:
                            print(f"âš ï¸ Ignorado duplicado: {file}")

    print(f"\nðŸ“¦ Total Ãºnico: {len(arquivos)}")

    return arquivos

