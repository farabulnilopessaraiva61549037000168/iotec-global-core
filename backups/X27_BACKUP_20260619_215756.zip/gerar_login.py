﻿import random

def import random

def gerar_login(cliente):
    usuario = cliente.lower().replace(" ", "")
    senha = str(random.randint(100000, 999999))
    return usuario, senha(cliente):
    usuario = cliente.lower().replace(" ", "")
    senha = str(random.randint(100000, 999999))
    return usuario, senha

