﻿import sys
import os

# garante PYTHONPATH
sys.path.insert(0, r"C:\IOTEC\MODULES")

# patch seguro de config padrão
def ensure_config(config):
    if config is None:
        config = {}

    paths = config.get("paths", {})
    paths.setdefault("logs_dir", "logs")
    paths.setdefault("snapshots_dir", "snapshots")

    config["paths"] = paths
    return config

import builtins
builtins.ensure_config = ensure_config

print("[BOOTSTRAP] Safe mode ativo")
