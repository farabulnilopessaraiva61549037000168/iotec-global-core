﻿import os
import importlib
import traceback

ROOT = os.path.dirname(os.path.abspath(__file__))

# ============================
# REGISTRO CENTRAL DO SISTEMA
# ============================

SYSTEM_MAP = {
    "commercial": [],
    "orchestration": [],
    "operational": [],
    "unknown": []
}

ACTIVE_MODULES = []

# ============================
# DESCUBRE MÃ“DULOS
# ============================

def discover_modules():
    print("\n[MASTER_CORE] Escaneando nÃºcleo...\n")

    for root, dirs, files in os.walk(ROOT):
        for file in files:
            if file.endswith(".py") and file != "IOTEC_MASTER_CORE.py":
                path = os.path.join(root, file)

                name = file.lower()

                if "cerebro" in name or "commercial" in name:
                    SYSTEM_MAP["commercial"].append(path)

                elif "orchestrator" in name or "core" in name or "engine" in name:
                    SYSTEM_MAP["orchestration"].append(path)

                elif "agent" in name or "pipeline" in name or "worker" in name:
                    SYSTEM_MAP["operational"].append(path)

                else:
                    SYSTEM_MAP["unknown"].append(path)

# ============================
# CARREGA MÃ“DULO SEGURO
# ============================

def safe_import(module_path):
    try:
        module_name = os.path.splitext(os.path.basename(module_path))[0]
        spec = importlib.util.spec_from_file_location(module_name, module_path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        ACTIVE_MODULES.append(module_name)
        return module
    except Exception as e:
        print(f"[ERROR] Falha ao carregar {module_path}")
        print(traceback.format_exc())
        return None

# ============================
# INICIALIZAÃ‡ÃƒO DO SISTEMA
# ============================

def boot_system():
    print("\n===================================")
    print("IOTEC MASTER CORE STARTING")
    print("===================================\n")

    discover_modules()

    print("\n[MASTER_CORE] Resumo do sistema:")
    for k, v in SYSTEM_MAP.items():
        print(f"  {k}: {len(v)} mÃ³dulos")

    print("\n[MASTER_CORE] Inicializando mÃ³dulos crÃ­ticos...\n")

    # carrega primeiro orquestraÃ§Ã£o
    for m in SYSTEM_MAP["orchestration"][:5]:
        safe_import(m)

    # depois comercial
    for m in SYSTEM_MAP["commercial"][:3]:
        safe_import(m)

    print("\n[MASTER_CORE] Sistema ativo.")
    print(f"[MASTER_CORE] MÃ³dulos carregados: {len(ACTIVE_MODULES)}")

# ============================
# LOOP PRINCIPAL
# ============================

def run():
    boot_system()

    print("\n[MASTER_CORE] Sistema em execuÃ§Ã£o.\n")

    while True:
        cmd = input("IOTEC > ").strip().lower()

        if cmd == "status":
            print("\n--- STATUS ---")
            print(f"Ativos: {len(ACTIVE_MODULES)} mÃ³dulos")
            print("OrquestraÃ§Ã£o:", len(SYSTEM_MAP["orchestration"]))
            print("Comercial:", len(SYSTEM_MAP["commercial"]))
            print("Operacional:", len(SYSTEM_MAP["operational"]))

        elif cmd == "modules":
            print("\n--- MÃ“DULOS ATIVOS ---")
            for m in ACTIVE_MODULES:
                print(m)

        elif cmd == "exit":
            print("Encerrando MASTER CORE...")
            break

        else:
            print("Comandos: status | modules | exit")

# ============================
# START
# ============================

if __name__ == "__main__":
    run()

