﻿# ============================================================
# IOTEC - CENTRAL OPERACIONAL DO NÃšCLEO
# REGULUS CORE ENGINE v1.0
# EMPRESA: IOTEC
# MODO: OPERACAO_MULTISETORIAL
# STATUS: ONLINE
# ============================================================

import json
import random
from datetime import datetime

# ============================================================
# CONFIGURAÃ‡ÃƒO CENTRAL
# ============================================================

EMPRESA = "IOTEC"

NUCLEO = {
    "empresa": EMPRESA,
    "modo": "operacao_multissetorial",
    "status": "online",
    "timestamp": str(datetime.now())
}

# ============================================================
# SETORES ECONÃ”MICOS
# ============================================================

SETORES = {
    "juridico": {
        "produto": "Lexus Juris Enterprise",
        "ticket_brl": 15000,
        "ticket_usd": 4000,
        "ticket_eur": 3500
    },

    "analytics": {
        "produto": "Omega Analytics",
        "ticket_brl": 12000,
        "ticket_usd": 3000,
        "ticket_eur": 2800
    },

    "govtech": {
        "produto": "GovTech Intelligence",
        "ticket_brl": 25000,
        "ticket_usd": 8000,
        "ticket_eur": 7000
    },

    "importacao": {
        "produto": "Casa Turca Commerce",
        "ticket_brl": 18000,
        "ticket_usd": 5000,
        "ticket_eur": 4500
    }
}

# ============================================================
# CLIMA ECONÃ”MICO
# ============================================================

CLIMA_ECONOMICO = {
    "juridico": random.choice(["alta", "moderado", "estavel"]),
    "analytics": random.choice(["alta", "crescimento", "explosao"]),
    "govtech": random.choice(["crescimento", "estavel", "alta"]),
    "importacao": random.choice(["moderado", "alta", "estavel"])
}

# ============================================================
# CENTRAL DE METAS
# ============================================================

def gerar_metas():

    metas = {}

    for setor, dados in SETORES.items():

        meta_dia = random.randint(8000, 50000)
        meta_mes = meta_dia * 30

        metas[setor] = {
            "produto": dados["produto"],
            "meta_dia": meta_dia,
            "meta_mes": meta_mes,
            "ticket_brl": dados["ticket_brl"],
            "ticket_usd": dados["ticket_usd"],
            "ticket_eur": dados["ticket_eur"]
        }

    return metas

# ============================================================
# CENTRAL DE LEADS
# ============================================================

PAISES = [
    "Brasil",
    "Estados Unidos",
    "CanadÃ¡",
    "Alemanha",
    "FranÃ§a",
    "Espanha",
    "Filipinas",
    "Portugal"
]

EMPRESAS = [
    "North Analytics",
    "Global Legal Group",
    "Future Gov",
    "Prime Commerce",
    "Vision Systems",
    "Atlas Intelligence"
]

def gerar_lead():

    setor = random.choice(list(SETORES.keys()))
    pais = random.choice(PAISES)
    empresa = random.choice(EMPRESAS)

    return {
        "empresa": empresa,
        "pais": pais,
        "setor": setor,
        "produto": SETORES[setor]["produto"],
        "status": "lead_detectado",
        "timestamp": str(datetime.now())
    }

# ============================================================
# CENTRAL FINANCEIRA
# ============================================================

def gerar_faturamento():

    brl = random.randint(10000, 80000)
    usd = random.randint(2000, 15000)
    eur = random.randint(1000, 10000)

    total = brl + (usd * 5) + (eur * 6)

    return {
        "brasil_brl": brl,
        "eua_usd": usd,
        "europa_eur": eur,
        "total_estimado_brl": total
    }

# ============================================================
# CENTRAL DE PRODUÃ‡ÃƒO
# ============================================================

PIPELINE = [
    "entrevista_tecnica",
    "diagnostico",
    "orcamento",
    "pagamento",
    "pipeline_aberto",
    "producao",
    "homologacao",
    "deploy",
    "suporte"
]

# ============================================================
# CENTRAL EXECUTIVA
# ============================================================

def painel_executivo():

    metas = gerar_metas()
    lead = gerar_lead()
    faturamento = gerar_faturamento()

    painel = {
        "nucleo": NUCLEO,
        "clima_economico": CLIMA_ECONOMICO,
        "metas": metas,
        "lead_ativo": lead,
        "faturamento": faturamento,
        "pipeline": PIPELINE
    }

    return painel

# ============================================================
# RELATÃ“RIO OPERACIONAL
# ============================================================

def exibir_relatorio():

    painel = painel_executivo()

    print("\n===================================================")
    print(" IOTEC - CENTRAL OPERACIONAL")
    print("===================================================\n")

    print(f"EMPRESA: {painel['nucleo']['empresa']}")
    print(f"MODO: {painel['nucleo']['modo']}")
    print(f"STATUS: {painel['nucleo']['status']}")
    print(f"TIMESTAMP: {painel['nucleo']['timestamp']}")

    print("\n===================================================")
    print(" CLIMA ECONÃ”MICO")
    print("===================================================\n")

    for setor, status in painel["clima_economico"].items():
        print(f"{setor.upper()} -> {status}")

    print("\n===================================================")
    print(" METAS OPERACIONAIS")
    print("===================================================\n")

    for setor, dados in painel["metas"].items():

        print(f"SETOR: {setor.upper()}")
        print(f"PRODUTO: {dados['produto']}")
        print(f"META DIA: R$ {dados['meta_dia']}")
        print(f"META MÃŠS: R$ {dados['meta_mes']}")
        print(f"TICKET BRL: R$ {dados['ticket_brl']}")
        print(f"TICKET USD: $ {dados['ticket_usd']}")
        print(f"TICKET EUR: â‚¬ {dados['ticket_eur']}")
        print("---------------------------------------------------")

    print("\n===================================================")
    print(" LEAD DETECTADO")
    print("===================================================\n")

    lead = painel["lead_ativo"]

    print(f"EMPRESA: {lead['empresa']}")
    print(f"PAÃS: {lead['pais']}")
    print(f"SETOR: {lead['setor']}")
    print(f"PRODUTO: {lead['produto']}")
    print(f"STATUS: {lead['status']}")

    print("\n===================================================")
    print(" FATURAMENTO ESTIMADO")
    print("===================================================\n")

    fat = painel["faturamento"]

    print(f"BRASIL: R$ {fat['brasil_brl']}")
    print(f"EUA: $ {fat['eua_usd']}")
    print(f"EUROPA: â‚¬ {fat['europa_eur']}")
    print(f"TOTAL CONSOLIDADO: R$ {fat['total_estimado_brl']}")

    print("\n===================================================")
    print(" PIPELINE OPERACIONAL")
    print("===================================================\n")

    for etapa in painel["pipeline"]:
        print(f"-> {etapa}")

    print("\n===================================================")
    print(" NÃšCLEO OPERACIONAL FINALIZADO")
    print("===================================================\n")

    salvar_json(painel)

# ============================================================
# EXPORTAÃ‡ÃƒO JSON
# ============================================================

def salvar_json(dados):

    arquivo = "IOTEC_CENTRAL_OPERACIONAL.json"

    with open(arquivo, "w", encoding="utf-8") as f:
        json.dump(dados, f, indent=4, ensure_ascii=False)

    print(f"\nJSON EXPORTADO -> {arquivo}")

# ============================================================
# EXECUÃ‡ÃƒO
# ============================================================

if __name__ == "__main__":
    exibir_relatorio()

