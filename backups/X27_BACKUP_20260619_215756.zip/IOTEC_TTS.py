﻿from gtts import gTTS

def gerar_audio(texto, nome_arquivo="resposta.mp3"):
    tts = gTTS(texto, lang="pt-br")
    tts.save(nome_arquivo)

