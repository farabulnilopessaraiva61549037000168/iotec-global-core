﻿import os
import subprocess

# =========================================
# CONFIG
# =========================================

PASTA_SITE = r"C:\Users\Bruno Lopes\Desktop\regulus site"

# =========================================
# VERIFICA SE EXISTE
# =========================================

if not os.path.exists(PASTA_SITE):
    print("Pasta não encontrada!")
    exit()

print("Pasta encontrada:", PASTA_SITE)

# =========================================
# EXECUTA DEPLOY
# =========================================

os.chdir(PASTA_SITE)

print("Iniciando deploy...")

comando = [
    "netlify",
    "deploy",
    "--prod",
    "--dir",
    "."
]

subprocess.run(comando)

print("Deploy finalizado.")

