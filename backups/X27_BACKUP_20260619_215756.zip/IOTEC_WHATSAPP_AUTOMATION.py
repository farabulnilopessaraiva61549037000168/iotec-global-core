﻿import urllib.parse

def gerar_link_whatsapp(telefone, nome, problema):

    mensagem = f"""
OlÃ¡ {nome}, recebemos sua solicitaÃ§Ã£o.

Identificamos que seu caso envolve:
{problema}

Para agilizar seu atendimento, selecione uma opÃ§Ã£o:

1 - Solicitar anÃ¡lise completa
2 - DÃºvidas sobre o serviÃ§o
3 - Acompanhar solicitaÃ§Ã£o
4 - Suporte tÃ©cnico

Equipe IOTEC
"""

    mensagem_codificada = urllib.parse.quote(mensagem)

    link = f"https://wa.me/55{telefone}?text={mensagem_codificada}"

    return link

