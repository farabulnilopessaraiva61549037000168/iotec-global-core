# ==========================================================
# IOTEC ALMA CORE v2
# Governança Inteligente da Torre
# Diagnóstico + Mapa de Saúde do Ecossistema
# ==========================================================

import os
from pathlib import Path
from collections import defaultdict
from datetime import datetime

ROOT_DIR = Path.cwd()

# -----------------------------
# SETORES (MAPA BASE)
# -----------------------------
SETOR_MAPA = {
    "presidencia": ["core", "master", "admin", "central", "strategy"],
    "recepcao": ["portal", "reception", "entrada", "frontend", "ui", "html"],
    "producao": ["pipeline", "automation", "worker", "build", "engine"],
    "atendimento": ["client", "chat", "ticket", "support", "msg"],
    "dados": ["data", "json", "csv", "report", "analytics"],
    "documentos": ["pdf", "doc", "contract", "proposal"],
    "almoxarifado": ["backup", "legacy", "old", "archive", "dump"],
}

# -----------------------------
# CLASSIFICAÇÃO
# -----------------------------
def classificar(nome):
    n = nome.lower()

    for setor, keywords in SETOR_MAPA.items():
        for k in keywords:
            if k in n:
                return setor

    return "desconhecido"


# -----------------------------
# ESCANEAMENTO
# -----------------------------
def escanear():
    inventario = defaultdict(list)

    for root, _, files in os.walk(ROOT_DIR):
        for f in files:
            path = str(Path(root) / f)
            setor = classificar(f)
            inventario[setor].append(path)

    return inventario


# -----------------------------
# ANALISE DE SAÚDE DA TORRE
# -----------------------------
def analisar_saude(inventario):
    total = sum(len(v) for v in inventario.values())

    desconhecido = len(inventario.get("desconhecido", []))

    # setores críticos
    balanceamento = {}

    for setor, itens in inventario.items():
        balanceamento[setor] = round(len(itens) / total * 100, 2)

    return total, desconhecido, balanceamento


# -----------------------------
# DETECÇÃO DE PROBLEMAS
# -----------------------------
def detectar_alertas(inventario):
    alertas = []

    if len(inventario.get("desconhecido", [])) > 1000:
        alertas.append("⚠ Grande volume de arquivos sem classificação (DESCONHECIDO)")

    if len(inventario.get("producao", [])) < 50:
        alertas.append("⚠ Produção pode estar subdimensionada")

    if len(inventario.get("recepcao", [])) > len(inventario.get("producao", [])) * 5:
        alertas.append("⚠ Recepção muito maior que produção (possível gargalo)")

    return alertas


# -----------------------------
# RELATÓRIO FINAL
# -----------------------------
def relatorio(inventario):
    total, desconhecido, balanceamento = analisar_saude(inventario)
    alertas = detectar_alertas(inventario)

    print("\n====================================")
    print("🧠 IOTEC ALMA CORE v2 - GOVERNANÇA")
    print("====================================\n")

    print(f"📦 TOTAL DE ATIVOS: {total}")
    print(f"❓ DESCONHECIDOS: {desconhecido}\n")

    print("📊 DISTRIBUIÇÃO DA TORRE:")
    for setor, pct in balanceamento.items():
        print(f" - {setor.upper()}: {pct}%")

    print("\n🚨 ALERTAS:")
    if alertas:
        for a in alertas:
            print(" ", a)
    else:
        print(" ✔ Nenhum alerta crítico")

    print("\n====================================")
    print(f"Timestamp: {datetime.now()}")
    print("====================================\n")


# -----------------------------
# ALMA CORE v2
# -----------------------------
def alma_core_v2():
    print("🧠 ALMA CORE v2 INICIADO - MODO GOVERNANÇA\n")

    inventario = escanear()

    relatorio(inventario)

    print("✔ Diagnóstico concluído.")


# -----------------------------
# EXECUÇÃO
# -----------------------------
if __name__ == "__main__":
    alma_core_v2()