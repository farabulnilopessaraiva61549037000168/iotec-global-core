import json
from datetime import datetime

ARQUIVO = "IOTEC_PIPELINE_DATABASE.json"

with open(
    ARQUIVO,
    "r",
    encoding="utf-8"
) as f:

    dados = json.load(f)

print("")
print("===================================")
print("IOTEC PIPELINE ACTION CENTER")
print("===================================")

print("")
print("DATA:")
print(datetime.now())

leads = dados.get("leads", [])
propostas = dados.get("propostas", [])
contratos = dados.get("contratos", [])
receitas = dados.get("receita", [])

print("")
print("===================================")
print("ACOES NECESSARIAS")
print("===================================")

acoes = 0

for lead in leads:

    possui_proposta = False

    for proposta in propostas:

        if proposta.get("lead_id") == lead["id"]:

            possui_proposta = True
            break

    if not possui_proposta:

        acoes += 1

        print("")
        print("LEAD SEM PROPOSTA")
        print("-----------------")
        print("ID:", lead["id"])
        print("PRODUTO:", lead.get("produto"))

for proposta in propostas:

    possui_contrato = False

    for contrato in contratos:

        if contrato.get("proposta_id") == proposta["id"]:

            possui_contrato = True
            break

    if not possui_contrato:

        acoes += 1

        print("")
        print("PROPOSTA SEM CONTRATO")
        print("---------------------")
        print("ID:", proposta["id"])
        print("VALOR:", proposta.get("valor"))

for contrato in contratos:

    possui_receita = False

    for receita in receitas:

        if receita.get("contrato_id") == contrato["id"]:

            possui_receita = True
            break

    if not possui_receita:

        acoes += 1

        print("")
        print("CONTRATO SEM RECEITA")
        print("--------------------")
        print("ID:", contrato["id"])
        print("VALOR:", contrato.get("valor"))

print("")
print("===================================")
print("RESUMO EXECUTIVO")
print("===================================")

print("")
print("LEADS:", len(leads))
print("PROPOSTAS:", len(propostas))
print("CONTRATOS:", len(contratos))
print("RECEITAS:", len(receitas))

print("")
print("ACOES PENDENTES:")
print(acoes)

print("")
print("===================================")
print("ORDEM MOR")
print("===================================")

if acoes == 0:

    print("PIPELINE COMPLETAMENTE SAUDAVEL")

else:

    print("EXISTEM ETAPAS PENDENTES")

print("")
print("ACTION CENTER ATIVO")