﻿# ============================================================
# IOTEC_MULTI_MAIL_CORE.py
# NÃºcleo com mÃºltiplas caixas de e-mail
# ============================================================

import imaplib
import email
from email.header import decode_header

# =========================
# CONFIGURAÃ‡Ã•ES
# =========================

CAIXAS = [
    {
        "nome": "PESSOAL",
        "email": "seu@gmail.com",
        "senha": "senha_app",
        "imap": "imap.gmail.com",
        "tipo": "OPERACIONAL"
    },
    {
        "nome": "COMERCIAL",
        "email": "seu@proton.me",
        "senha": "senha_app",
        "imap": "imap.gmail.com",  # via encaminhamento
        "tipo": "CLIENTE"
    }
]

# =========================
# CLASSIFICAÃ‡ÃƒO
# =========================

def classificar(tipo_caixa, assunto):

    assunto = assunto.lower()

    if tipo_caixa == "CLIENTE":
        return "CLIENTE"

    if "pagamento" in assunto or "invoice" in assunto:
        return "FINANCEIRO"

    if "cobranÃ§a" in assunto or "dÃ©bito" in assunto:
        return "ALERTA"

    return "OUTROS"

# =========================
# PROCESSAMENTO
# =========================

def processar_email(tipo, assunto):

    if tipo == "CLIENTE":
        print("ðŸ‘¤ Atendimento / geraÃ§Ã£o de dossiÃª")

    elif tipo == "FINANCEIRO":
        print("ðŸ’° Registrar pagamento ou dÃ­vida")

    elif tipo == "ALERTA":
        print("âš ï¸ Notificar administraÃ§Ã£o")

# =========================
# LEITURA
# =========================

def ler_caixa(config):

    print(f"\nðŸ“¬ Lendo caixa: {config['nome']}")

    mail = imaplib.IMAP4_SSL(config["imap"])
    mail.login(config["email"], config["senha"])
    mail.select("inbox")

    status, mensagens = mail.search(None, "ALL")
    mensagens = mensagens[0].split()

    for num in mensagens[-5:]:

        status, msg_data = mail.fetch(num, "(RFC822)")
        msg = email.message_from_bytes(msg_data[0][1])

        assunto, enc = decode_header(msg["Subject"])[0]
        if isinstance(assunto, bytes):
            assunto = assunto.decode(enc if enc else "utf-8")

        tipo = classificar(config["tipo"], assunto)

        print("Assunto:", assunto)
        print("Classificado como:", tipo)

        processar_email(tipo, assunto)

# =========================
# EXECUÃ‡ÃƒO
# =========================

def executar():

    for caixa in CAIXAS:
        ler_caixa(caixa)

if __name__ == "__main__":
    executar()

