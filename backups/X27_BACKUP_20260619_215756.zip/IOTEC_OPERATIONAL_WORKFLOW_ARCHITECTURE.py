﻿# ============================================================
# IOTEC_OPERATIONAL_WORKFLOW_ARCHITECTURE.py
# ============================================================
# ARQUITETURA OPERACIONAL DO FLUXO COMERCIAL
# ============================================================
# OBJETIVO:
# ------------------------------------------------------------
# Este nÃºcleo representa a arquitetura operacional responsÃ¡vel
# por controlar:
#
# - atendimento
# - catÃ¡logo
# - investigaÃ§Ã£o
# - proposta
# - contrato
# - pagamento
# - pausa operacional
# - rastreamento
# - produÃ§Ã£o
# - entrega
# - suporte
#
# O sistema trabalha de forma ASSÃNCRONA.
#
# Nenhuma produÃ§Ã£o continua sem:
# - validaÃ§Ã£o financeira
# - liberaÃ§Ã£o operacional
# - autorizaÃ§Ã£o interna
#
# ============================================================

import uuid
import time
from dataclasses import dataclass, field
from typing import Dict, List

# ============================================================
# CATÃLOGO PÃšBLICO
# ============================================================

SERVICE_CATALOG = {

    "ERP Empresarial": {
        "base_price": 35000,
        "description": "Sistema completo de gestÃ£o empresarial."
    },

    "Sistema Industrial": {
        "base_price": 45000,
        "description": "AutomaÃ§Ã£o industrial e monitoramento operacional."
    },

    "Dashboard Inteligente": {
        "base_price": 15000,
        "description": "PainÃ©is inteligentes e BI operacional."
    },

    "Sistema JurÃ­dico": {
        "base_price": 28000,
        "description": "GestÃ£o processual e compliance."
    },

    "Sistema Hospitalar": {
        "base_price": 55000,
        "description": "GestÃ£o clÃ­nica e hospitalar."
    }
}

# ============================================================
# STATUS OPERACIONAIS
# ============================================================

STATUS = {

    "WAITING_PAYMENT": "AGUARDANDO PAGAMENTO",
    "PAYMENT_CONFIRMED": "PAGAMENTO CONFIRMADO",
    "PRODUCTION_RELEASED": "PRODUÃ‡ÃƒO LIBERADA",
    "IN_PRODUCTION": "EM PRODUÃ‡ÃƒO",
    "VALIDATION": "VALIDAÃ‡ÃƒO OPERACIONAL",
    "DELIVERED": "PROJETO ENTREGUE",
    "SUPPORT": "SUPORTE ATIVO"
}

# ============================================================
# ESTRUTURAS
# ============================================================

@dataclass
class Client:

    name: str
    email: str
    company: str


@dataclass
class Project:

    project_id: str
    service_name: str
    total_value: float
    entry_payment: float
    remaining_payment: float

    status: str = STATUS["WAITING_PAYMENT"]

    workflow: List[str] = field(default_factory=list)

    notes: Dict = field(default_factory=dict)

# ============================================================
# NÃšCLEO OPERACIONAL
# ============================================================

class IOTECOperationalCore:

    def __init__(self):

        self.client = None
        self.project = None

    # ========================================================
    # IA VISUAL
    # ========================================================

    def think(self, text):

        print(f"\n[IOTEC CORE] {text}")

        time.sleep(1)

    # ========================================================
    # IDENTIFICADOR GLOBAL
    # ========================================================

    def generate_project_id(self):

        uid = str(uuid.uuid4())[:8].upper()

        return f"IOTEC-2026-{uid}"

    # ========================================================
    # CADASTRO
    # ========================================================

    def collect_client(self):

        print("\n================ CLIENTE ================")

        name = input("\nNome: ")

        email = input("\nE-mail: ")

        company = input("\nEmpresa: ")

        self.client = Client(
            name=name,
            email=email,
            company=company
        )

    # ========================================================
    # CATÃLOGO
    # ========================================================

    def show_catalog(self):

        print("\n================ CATÃLOGO ================")

        services = list(SERVICE_CATALOG.keys())

        for i, service in enumerate(services, start=1):

            print(f"\n{i} - {service}")

        return services

    # ========================================================
    # APRESENTAÃ‡ÃƒO COMERCIAL
    # ========================================================

    def sales_presentation(self, service):

        data = SERVICE_CATALOG[service]

        self.think(
            f"Apresentando soluÃ§Ã£o {service}"
        )

        print("\n================ APRESENTAÃ‡ÃƒO ================")

        print(f"\nSERVIÃ‡O:")
        print(service)

        print(f"\nDESCRIÃ‡ÃƒO:")
        print(data["description"])

        print(f"\nVALOR BASE:")
        print(f"R$ {data['base_price']:,.2f}")

        print("\nBENEFÃCIOS:")

        print("- ReduÃ§Ã£o de falhas humanas")
        print("- AutomaÃ§Ã£o operacional")
        print("- Monitoramento inteligente")
        print("- Escalabilidade")
        print("- Controle operacional")

    # ========================================================
    # INVESTIGAÃ‡ÃƒO
    # ========================================================

    def investigation(self):

        print("\n================ INVESTIGAÃ‡ÃƒO ================")

        sector = input(
            "\nQual Ã© o setor da empresa?\n\n>>> "
        )

        problems = input(
            "\nQuais gargalos existem atualmente?\n\n>>> "
        )

        objective = input(
            "\nQual Ã© o principal objetivo?\n\n>>> "
        )

        users = input(
            "\nQuantas pessoas utilizarÃ£o o sistema?\n\n>>> "
        )

        self.think(
            "Construindo diagnÃ³stico operacional..."
        )

        return {

            "sector": sector,
            "problems": problems,
            "objective": objective,
            "users": users
        }

    # ========================================================
    # CRIAÃ‡ÃƒO DE PROJETO
    # ========================================================

    def create_project(self, service, diagnosis):

        value = SERVICE_CATALOG[service]["base_price"]

        entry = value * 0.30

        remaining = value * 0.70

        project_id = self.generate_project_id()

        workflow = [

            "Pedido recebido",
            "DiagnÃ³stico operacional",
            "Pagamento pendente"
        ]

        self.project = Project(

            project_id=project_id,
            service_name=service,
            total_value=value,
            entry_payment=entry,
            remaining_payment=remaining,
            workflow=workflow,
            notes=diagnosis
        )

    # ========================================================
    # PROPOSTA
    # ========================================================

    def show_proposal(self):

        print("\n================ PROPOSTA ================")

        print(f"\nPROJECT ID:")
        print(self.project.project_id)

        print(f"\nCLIENTE:")
        print(self.client.name)

        print(f"\nEMPRESA:")
        print(self.client.company)

        print(f"\nSERVIÃ‡O:")
        print(self.project.service_name)

        print(f"\nVALOR TOTAL:")
        print(f"R$ {self.project.total_value:,.2f}")

        print(f"\nENTRADA 30%:")
        print(f"R$ {self.project.entry_payment:,.2f}")

        print(f"\nRESTANTE 70%:")
        print(f"R$ {self.project.remaining_payment:,.2f}")

        print(f"\nSTATUS:")
        print(self.project.status)

    # ========================================================
    # PAGAMENTO
    # ========================================================

    def request_payment(self):

        self.think(
            "O atendimento continuarÃ¡ apÃ³s confirmaÃ§Ã£o financeira."
        )

        print("\n================ PAGAMENTO ================")

        print("\nMÃ‰TODOS DISPONÃVEIS:")

        print("- PIX")
        print("- PayPal")
        print("- Stripe")
        print("- TransferÃªncia")

        print("\nSTATUS:")
        print("AGUARDANDO CONFIRMAÃ‡ÃƒO FINANCEIRA")

        self.project.status = STATUS["WAITING_PAYMENT"]

    # ========================================================
    # LIBERAÃ‡ÃƒO INTERNA
    # ========================================================

    def internal_release(self):

        print("\n================ NÃšCLEO FINANCEIRO ================")

        confirmation = input(
            "\nPagamento reconhecido internamente?\n\n>>> "
        ).lower()

        if confirmation in ["sim", "s"]:

            self.project.status = STATUS["PAYMENT_CONFIRMED"]

            self.project.workflow.append(
                "Pagamento confirmado"
            )

            self.think(
                "LiberaÃ§Ã£o operacional autorizada."
            )

            self.project.status = STATUS["PRODUCTION_RELEASED"]

            self.project.workflow.append(
                "ProduÃ§Ã£o liberada"
            )

            return True

        self.think(
            "Projeto permanece pausado."
        )

        return False

    # ========================================================
    # PRODUÃ‡ÃƒO
    # ========================================================

    def production(self):

        self.project.status = STATUS["IN_PRODUCTION"]

        self.project.workflow.append(
            "ProduÃ§Ã£o iniciada"
        )

        print("\n================ PRODUÃ‡ÃƒO ================")

        stages = [

            "Criando arquitetura",
            "Gerando APIs",
            "Criando banco de dados",
            "Construindo frontend",
            "Configurando dashboards",
            "Executando validaÃ§Ãµes",
            "Preparando entrega"
        ]

        for stage in stages:

            self.think(stage)

            self.project.workflow.append(stage)

    # ========================================================
    # VALIDAÃ‡ÃƒO
    # ========================================================

    def validation(self):

        self.project.status = STATUS["VALIDATION"]

        self.project.workflow.append(
            "ValidaÃ§Ã£o operacional"
        )

        self.think(
            "Executando validaÃ§Ãµes tÃ©cnicas..."
        )

    # ========================================================
    # ENTREGA
    # ========================================================

    def delivery(self):

        self.project.status = STATUS["DELIVERED"]

        self.project.workflow.append(
            "Projeto entregue"
        )

        print("\n================ ENTREGA ================")

        print("\nSTATUS:")
        print("PROJETO ENTREGUE")

        print("\nSUPORTE:")
        print("Monitoramento assistido por IA.")

    # ========================================================
    # RASTREAMENTO
    # ========================================================

    def tracking(self):

        print("\n================ RASTREAMENTO ================")

        print(f"\nPROJECT ID:")
        print(self.project.project_id)

        print(f"\nSTATUS ATUAL:")
        print(self.project.status)

        print("\nFLUXO OPERACIONAL:")

        for step in self.project.workflow:

            print(f"- {step}")

    # ========================================================
    # PIPELINE PRINCIPAL
    # ========================================================

    def start(self):

        print("\n================================================")
        print("        IOTEC OPERATIONAL WORKFLOW")
        print("================================================")

        self.collect_client()

        services = self.show_catalog()

        choice = int(
            input(
                "\nEscolha um serviÃ§o:\n\n>>> "
            )
        )

        selected_service = services[choice - 1]

        self.sales_presentation(selected_service)

        diagnosis = self.investigation()

        self.create_project(
            selected_service,
            diagnosis
        )

        self.show_proposal()

        self.request_payment()

        released = self.internal_release()

        if not released:

            return

        self.production()

        self.validation()

        self.delivery()

        self.tracking()

# ============================================================
# EXECUÃ‡ÃƒO
# ============================================================

if __name__ == "__main__":

    system = IOTECOperationalCore()

    system.start()

