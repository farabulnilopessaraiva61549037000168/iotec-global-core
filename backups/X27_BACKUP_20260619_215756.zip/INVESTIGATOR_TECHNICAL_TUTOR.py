﻿# =========================================================
# IOTEC CORE INVESTIGATOR + TECHNICAL TUTOR
# =========================================================
#
# O QUE ESSE SISTEMA FAZ:
#
# 1. INVESTIGA O NÃšCLEO
#    - percorre pastas
#    - detecta arquivos
#    - detecta linguagens
#    - detecta mÃ³dulos
#    - detecta APIs
#
# 2. GERA RELATÃ“RIOS
#    - estrutura do projeto
#    - tecnologias encontradas
#    - arquivos crÃ­ticos
#    - potencial comercial
#
# 3. TUTOR TÃ‰CNICO
#    - explica em portuguÃªs humano
#    - traduz termos tÃ©cnicos
#    - ajuda vocÃª a entender o ecossistema
#
# =========================================================
# COMO SALVAR
# =========================================================
#
# Salve como:
#
# core_investigator.py
#
# =========================================================
# COMO RODAR
# =========================================================
#
# 1. instalar:
#
# pip install python-dotenv
#
# 2. rodar:
#
# python core_investigator.py
#
# =========================================================

import os
import json
from pathlib import Path
from collections import defaultdict

# =========================================================
# CONFIGURAÃ‡ÃƒO
# =========================================================

# PASTA QUE SERÃ ANALISADA
ROOT_DIR = input(
    "\nDigite o caminho da pasta do nÃºcleo que deseja investigar:\n> "
).strip()

# =========================================================
# MAPAS DE DETECÃ‡ÃƒO
# =========================================================

LANGUAGE_MAP = {
    ".py": "Python",
    ".js": "JavaScript",
    ".ts": "TypeScript",
    ".jsx": "React JSX",
    ".tsx": "React TSX",
    ".html": "HTML",
    ".css": "CSS",
    ".json": "JSON",
    ".env": "Environment Config",
    ".sql": "SQL",
    ".md": "Markdown",
    ".yml": "YAML",
    ".yaml": "YAML",
}

CATEGORY_MAP = {
    "api": "API / IntegraÃ§Ã£o",
    "auth": "AutenticaÃ§Ã£o",
    "payment": "Pagamento",
    "chat": "Chat / ConversaÃ§Ã£o",
    "ai": "InteligÃªncia Artificial",
    "agent": "Agente IA",
    "dashboard": "Painel",
    "admin": "AdministraÃ§Ã£o",
    "database": "Banco de Dados",
    "memory": "MemÃ³ria",
    "core": "NÃºcleo Central",
    "frontend": "Frontend",
    "backend": "Backend",
    "voice": "Ãudio / Voz",
    "stripe": "Pagamento Stripe",
    "whatsapp": "WhatsApp",
    "openai": "OpenAI",
}

# =========================================================
# ESTRUTURAS
# =========================================================

report = {
    "project_name": "",
    "directories": [],
    "files": [],
    "languages": defaultdict(int),
    "categories": defaultdict(list),
    "critical_modules": [],
    "possible_products": [],
}

# =========================================================
# DETECÃ‡ÃƒO DE CATEGORIA
# =========================================================

def detect_category(name):
    name = name.lower()

    found = []

    for keyword, category in CATEGORY_MAP.items():
        if keyword in name:
            found.append(category)

    return found

# =========================================================
# TUTOR TÃ‰CNICO
# =========================================================

def explain_category(category):

    explanations = {

        "API / IntegraÃ§Ã£o":
            "Esse mÃ³dulo parece servir para conectar sistemas diferentes.",

        "AutenticaÃ§Ã£o":
            "Essa parte controla login, seguranÃ§a e acesso.",

        "Pagamento":
            "Esse mÃ³dulo provavelmente gerencia cobranÃ§as, pagamentos ou assinaturas.",

        "Chat / ConversaÃ§Ã£o":
            "Essa estrutura parece responsÃ¡vel pela comunicaÃ§Ã£o com usuÃ¡rios.",

        "InteligÃªncia Artificial":
            "Esse mÃ³dulo parece ligado Ã  IA do sistema.",

        "Agente IA":
            "Esse componente parece funcionar como um agente automatizado.",

        "Painel":
            "Essa parte provavelmente exibe dashboards e controle visual.",

        "AdministraÃ§Ã£o":
            "Esse mÃ³dulo parece ser usado para controle interno do sistema.",

        "Banco de Dados":
            "Essa estrutura provavelmente armazena informaÃ§Ãµes do sistema.",

        "MemÃ³ria":
            "Esse mÃ³dulo parece armazenar contexto e histÃ³rico.",

        "NÃºcleo Central":
            "Esse parece ser um componente central do ecossistema.",

        "Frontend":
            "Frontend Ã© a parte visual que o usuÃ¡rio enxerga.",

        "Backend":
            "Backend Ã© a parte invisÃ­vel do sistema onde ficam regras e processamento.",

        "Ãudio / Voz":
            "Esse mÃ³dulo parece ligado a voz, Ã¡udio ou chamadas.",

        "Pagamento Stripe":
            "IntegraÃ§Ã£o provÃ¡vel com pagamentos Stripe.",

        "WhatsApp":
            "IntegraÃ§Ã£o provÃ¡vel com WhatsApp.",

        "OpenAI":
            "IntegraÃ§Ã£o provÃ¡vel com inteligÃªncia artificial da OpenAI.",
    }

    return explanations.get(
        category,
        "Categoria tÃ©cnica detectada."
    )

# =========================================================
# INVESTIGAÃ‡ÃƒO
# =========================================================

print("\n=================================================")
print("INICIANDO INVESTIGAÃ‡ÃƒO DO NÃšCLEO...")
print("=================================================\n")

root_path = Path(ROOT_DIR)

report["project_name"] = root_path.name

for path in root_path.rglob("*"):

    if path.is_dir():

        report["directories"].append(str(path))

    elif path.is_file():

        file_info = {
            "name": path.name,
            "path": str(path),
            "size_kb": round(path.stat().st_size / 1024, 2),
        }

        ext = path.suffix.lower()

        # Linguagem
        language = LANGUAGE_MAP.get(ext, "Desconhecida")
        file_info["language"] = language

        report["languages"][language] += 1

        # Categorias
        categories = detect_category(path.name)

        file_info["categories"] = categories

        for c in categories:
            report["categories"][c].append(path.name)

        # MÃ³dulos crÃ­ticos
        if any(k in path.name.lower() for k in [
            "core",
            "main",
            "server",
            "app",
            "engine",
            "payment",
            "auth"
        ]):
            report["critical_modules"].append(path.name)

        # PossÃ­vel produto
        if any(k in path.name.lower() for k in [
            "dashboard",
            "chat",
            "ai",
            "crm",
            "automation"
        ]):
            report["possible_products"].append(path.name)

        report["files"].append(file_info)

# =========================================================
# RELATÃ“RIO
# =========================================================

print("\n=================================================")
print("RELATÃ“RIO DO NÃšCLEO")
print("=================================================\n")

print(f"Projeto detectado: {report['project_name']}\n")

print("-------------------------------------------------")
print("LINGUAGENS DETECTADAS")
print("-------------------------------------------------\n")

for lang, count in report["languages"].items():
    print(f"{lang}: {count} arquivos")

print("\n-------------------------------------------------")
print("CATEGORIAS DETECTADAS")
print("-------------------------------------------------\n")

for category, files in report["categories"].items():

    print(f"\n[{category}]")
    print(explain_category(category))

    for f in files[:10]:
        print(f" - {f}")

print("\n-------------------------------------------------")
print("MÃ“DULOS CRÃTICOS")
print("-------------------------------------------------\n")

for module in report["critical_modules"]:
    print(f" - {module}")

print("\n-------------------------------------------------")
print("POSSÃVEIS PRODUTOS / SERVIÃ‡OS")
print("-------------------------------------------------\n")

for p in report["possible_products"]:
    print(f" - {p}")

# =========================================================
# EXPORTAÃ‡ÃƒO
# =========================================================

output = {
    "project_name": report["project_name"],
    "languages": dict(report["languages"]),
    "categories": dict(report["categories"]),
    "critical_modules": report["critical_modules"],
    "possible_products": report["possible_products"],
}

with open("iotec_core_report.json", "w", encoding="utf-8") as f:
    json.dump(output, f, indent=4, ensure_ascii=False)

print("\n=================================================")
print("INVESTIGAÃ‡ÃƒO FINALIZADA")
print("=================================================\n")

print("RelatÃ³rio salvo em:")
print("iotec_core_report.json\n")

print("Agora vocÃª pode comeÃ§ar a entender:")
print(" - o que existe no nÃºcleo")
print(" - o que Ã© importante")
print(" - o que pode virar produto")
print(" - o que Ã© infraestrutura")
print(" - o que precisa reorganizar")
print()

