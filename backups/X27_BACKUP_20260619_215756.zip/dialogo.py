﻿import json
import os

MEMORIA = "C:\\IOTEC\\memoria_dialogo.json"

def carregar_memoria():
    if not os.path.exists(MEMORIA):
        return []
    with open(MEMORIA, "r") as f:
        return json.load(f)

def salvar_memoria(mem):
    with open(MEMORIA, "w") as f:
        json.dump(mem, f, indent=2)

def registrar(pergunta, resposta):
    mem = carregar_memoria()

    mem.append({
        "pergunta": pergunta,
        "resposta": resposta
    })

    # mantÃ©m sÃ³ Ãºltimas 10 interaÃ§Ãµes
    mem = mem[-10:]

    salvar_memoria(mem)

def obter_contexto():
    mem = carregar_memoria()
    contexto = ""

    for item in mem:
        contexto += f"Cliente: {item['pergunta']}\n"
        contexto += f"Sistema: {item['resposta']}\n"

    return contexto

