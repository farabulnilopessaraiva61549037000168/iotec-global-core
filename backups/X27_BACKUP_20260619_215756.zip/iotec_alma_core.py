# ==========================================================
# IOTEC ALMA CORE
# Sistema de Organização Inteligente do Ecossistema
# Metáfora: "A Alma que organiza a Torre"
# ==========================================================

import os
from pathlib import Path
from datetime import datetime

# -----------------------------
# CONFIGURAÇÃO DO PRÉDIO (RAIZ)
# -----------------------------
ROOT_DIR = Path.cwd()  # diretório onde o script é executado

# -----------------------------
# MAPA DA TORRE (DEPARTAMENTOS)
# -----------------------------
DEPARTAMENTOS = {
    "presidencia": ["strategy", "core", "master", "admin"],
    "recepcao": ["portal", "reception", "entry", "frontend", "ui", "html"],
    "producao": ["pipeline", "automation", "build", "generate", "worker"],
    "atendimento": ["ticket", "support", "client", "chat", "service"],
    "dados": ["data", "analytics", "report", "csv", "json"],
    "almoxarifado": ["backup", "archive", "old", "deprecated", "legacy"],
    "documentos": ["pdf", "doc", "contract", "proposal"],
    "desconhecido": []
}

# -----------------------------
# FUNÇÃO: IDENTIFICAR SETOR
# -----------------------------
def classificar_arquivo(nome_arquivo: str):
    nome = nome_arquivo.lower()

    for setor, palavras in DEPARTAMENTOS.items():
        for p in palavras:
            if p in nome:
                return setor

    return "desconhecido"


# -----------------------------
# FUNÇÃO: ESCANEAR O NÚCLEO
# -----------------------------
def escanear_nucleo(caminho: Path):
    inventario = {}

    for root, dirs, files in os.walk(caminho):
        for file in files:
            caminho_completo = Path(root) / file
            setor = classificar_arquivo(file)

            if setor not in inventario:
                inventario[setor] = []

            inventario[setor].append(str(caminho_completo))

    return inventario


# -----------------------------
# FUNÇÃO: GERAR RELATÓRIO
# -----------------------------
def gerar_relatorio(inventario):
    print("\n====================================")
    print("🏢 IOTEC - RELATÓRIO DA TORRE")
    print("====================================\n")

    total = 0

    for setor, itens in inventario.items():
        print(f"📁 SETOR: {setor.upper()}")
        print(f"   itens encontrados: {len(itens)}\n")

        total += len(itens)

        for i in itens[:10]:  # limita visualização
            print(f"   - {i}")

        if len(itens) > 10:
            print("   ...")

        print("\n------------------------------------\n")

    print(f"TOTAL DE ATIVOS NA TORRE: {total}")
    print("====================================\n")


# -----------------------------
# FUNÇÃO: ALMA CORE (ORQUESTRADOR)
# -----------------------------
def alma_core():
    print("🧠 ALMA CORE INICIADA")
    print("Escaneando a torre...\n")

    inventario = escanear_nucleo(ROOT_DIR)

    print("Organizando setores...\n")

    gerar_relatorio(inventario)

    print("✔ Organização concluída.")
    print(f"Timestamp: {datetime.now()}")


# -----------------------------
# EXECUÇÃO
# -----------------------------
if __name__ == "__main__":
    alma_core()