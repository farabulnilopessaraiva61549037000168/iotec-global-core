﻿def extrair_valor(corpo):

    import re

    match = re.search(r'\$ ?([\d,\.]+)', corpo)

    if match:
        return match.group(1)

    return None

