JEWEL_SCALE = {

    "PULSEIRA": 1,
    "COLAR": 2,
    "JOIA_RARA": 3,
    "COROA_REAL": 4,
    "ARTEFATO_UNICO": 5

}