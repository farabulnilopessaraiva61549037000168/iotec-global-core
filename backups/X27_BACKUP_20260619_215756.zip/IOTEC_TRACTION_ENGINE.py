# ==========================================================
# IOTEC TRACTION ENGINE
# GERA METAS DE CRESCIMENTO
# ==========================================================

import sqlite3
import json
import os
from datetime import datetime

ROOT = r"C:\IOTEC"

OUTPUT_JSON = r"C:\IOTEC\IOTEC_TRACTION_REPORT.json"
OUTPUT_TXT  = r"C:\IOTEC\IOTEC_TRACTION_REPORT.txt"

# ==========================================================
# CONTADORES
# ==========================================================

leads = 0
clients = 0
payments = 0
invoices = 0

# ==========================================================
# PROCURA BANCOS
# ==========================================================

dbs = []

for root, dirs, files in os.walk(ROOT):

    for file in files:

        if file.endswith(".db"):

            dbs.append(
                os.path.join(root, file)
            )

# ==========================================================
# LEITURA
# ==========================================================

for db in dbs:

    try:

        conn = sqlite3.connect(db)
        cur = conn.cursor()

        tables = cur.execute("""

        SELECT name

        FROM sqlite_master

        WHERE type='table'

        """).fetchall()

        for table in tables:

            name = table[0]

            low = name.lower()

            try:

                total = cur.execute(

                    f"SELECT COUNT(*) FROM {name}"

                ).fetchone()[0]

            except:

                total = 0

            if "lead" in low:

                leads += total

            elif "client" in low:

                clients += total

            elif "payment" in low:

                payments += total

            elif "invoice" in low:

                invoices += total

        conn.close()

    except:
        pass

# ==========================================================
# METAS
# ==========================================================

target_leads = max(
    100,
    leads * 10
)

target_clients = max(
    10,
    clients * 5
)

target_payments = max(
    20,
    payments * 10
)

# ==========================================================
# SCORE
# ==========================================================

traction_score = (
    leads * 2 +
    clients * 5 +
    payments * 10
)

# ==========================================================
# RELATORIO
# ==========================================================

report = {

    "generated": str(datetime.now()),

    "current": {

        "leads": leads,
        "clients": clients,
        "payments": payments,
        "invoices": invoices

    },

    "targets_30_days": {

        "leads": target_leads,
        "clients": target_clients,
        "payments": target_payments

    },

    "traction_score": traction_score
}

# ==========================================================
# JSON
# ==========================================================

with open(
    OUTPUT_JSON,
    "w",
    encoding="utf-8"
) as f:

    json.dump(
        report,
        f,
        indent=4,
        ensure_ascii=False
    )

# ==========================================================
# TXT
# ==========================================================

with open(
    OUTPUT_TXT,
    "w",
    encoding="utf-8"
) as f:

    f.write("\n")
    f.write("===================================\n")
    f.write("IOTEC TRACTION ENGINE\n")
    f.write("===================================\n\n")

    f.write(f"LEADS: {leads}\n")
    f.write(f"CLIENTS: {clients}\n")
    f.write(f"PAYMENTS: {payments}\n")
    f.write(f"INVOICES: {invoices}\n\n")

    f.write("META 30 DIAS\n")
    f.write("----------------------\n")
    f.write(f"LEADS: {target_leads}\n")
    f.write(f"CLIENTS: {target_clients}\n")
    f.write(f"PAYMENTS: {target_payments}\n\n")

    f.write(
        f"TRACTION SCORE: {traction_score}\n"
    )

# ==========================================================
# CONSOLE
# ==========================================================

print("")
print("===================================")
print("IOTEC TRACTION ENGINE")
print("===================================")

print("")
print("LEADS:", leads)
print("CLIENTS:", clients)
print("PAYMENTS:", payments)
print("INVOICES:", invoices)

print("")
print("META 30 DIAS")

print("LEADS:", target_leads)
print("CLIENTS:", target_clients)
print("PAYMENTS:", target_payments)

print("")
print(
    "TRACTION SCORE:",
    traction_score
)

print("")
print("TXT:")
print(OUTPUT_TXT)

print("")
print("JSON:")
print(OUTPUT_JSON)

print("")
print("CONCLUIDO")