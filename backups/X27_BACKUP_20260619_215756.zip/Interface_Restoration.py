﻿from pathlib import Path

print("")
print("==========================================")
print(" IOTEC INTERFACE RESTORATION")
print("==========================================")
print("")

# ==========================================
# FILES
# ==========================================

files = [

    r"C:\Tecnologia\showroom\index.html",
    r"C:\Tecnologia\IOTEC BL â€” Tecnologia que transforma.htm"
]

# ==========================================
# REPLACEMENTS
# ==========================================

replacements = {

    "InovaÃƒÂ§ÃƒÂ£o": "InovaÃ§Ã£o",
    "negÃƒÂ³cio": "negÃ³cio",
    "transformaÃƒÂ§ÃƒÂ£o": "transformaÃ§Ã£o",
    "soluÃƒÂ§ÃƒÂµes": "soluÃ§Ãµes",
    "gestÃƒÂ£o": "gestÃ£o",
    "informaÃƒÂ§ÃƒÂ£o": "informaÃ§Ã£o",
    "produÃƒÂ§ÃƒÂ£o": "produÃ§Ã£o",
    "operaÃƒÂ§ÃƒÂ£o": "operaÃ§Ã£o",
    "integraÃƒÂ§ÃƒÂ£o": "integraÃ§Ã£o",
    "configuraÃƒÂ§ÃƒÂ£o": "configuraÃ§Ã£o",
    "otimizaÃƒÂ§ÃƒÂ£o": "otimizaÃ§Ã£o",
    "evoluÃƒÂ§ÃƒÂ£o": "evoluÃ§Ã£o",
    "Ã‚Â·": "Â·",
    "Ã‚": ""
}

# ==========================================
# PROCESS
# ==========================================

for file_path in files:

    path = Path(file_path)

    if not path.exists():

        print(f"[ERROR] FILE NOT FOUND:")
        print(file_path)
        continue

    print("")
    print("[PROCESSING]")
    print(file_path)

    # BACKUP

    backup = str(path) + ".restorebackup"

    Path(backup).write_text(
        path.read_text(
            encoding="utf-8",
            errors="ignore"
        ),
        encoding="utf-8"
    )

    print("[OK] BACKUP CREATED")

    # READ

    content = path.read_text(
        encoding="utf-8",
        errors="ignore"
    )

    # REPLACE

    for wrong, correct in replacements.items():

        content = content.replace(
            wrong,
            correct
        )

    # META UTF8

    if "charset" not in content:

        content = content.replace(
            "<head>",
            "<head><meta charset='UTF-8'>"
        )

    # SAVE

    path.write_text(
        content,
        encoding="utf-8"
    )

    print("[OK] ENCODING RESTORED")

print("")
print("==========================================")
print(" RESTORATION COMPLETE")
print("==========================================")

