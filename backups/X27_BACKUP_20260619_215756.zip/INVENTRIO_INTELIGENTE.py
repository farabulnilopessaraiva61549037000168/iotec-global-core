﻿# =========================================================
# IOTEC INVENTÃRIO INTELIGENTE ENTERPRISE
# CLASSIFICAÃ‡ÃƒO â€¢ SCORE â€¢ MATRIZES â€¢ Ã“RFÃƒOS
# =========================================================

import os
import json
import hashlib
from datetime import datetime

# =========================================================
# CONFIGURAÃ‡ÃƒO
# =========================================================

BASE_DIR = r"C:\IOTEC"

INPUT_JSON = os.path.join(
    BASE_DIR,
    "INVENTARIO_IMPERIAL",
    "inventario_corporativo.json"
)

OUTPUT_DIR = os.path.join(
    BASE_DIR,
    "INVENTARIO_INTELIGENTE"
)

OUTPUT_JSON = os.path.join(
    OUTPUT_DIR,
    "inventario_inteligente.json"
)

OUTPUT_RELATORIO = os.path.join(
    OUTPUT_DIR,
    "relatorio_executivo.txt"
)

# =========================================================
# PALAVRAS-CHAVE
# =========================================================

CATEGORIAS = {

    "frontend_premium": [
        "regulus",
        "turca",
        "lexus",
        "premium",
        "luxo",
        "interface",
        "dashboard"
    ],

    "backend_critico": [
        "engine",
        "gateway",
        "watcher",
        "observer",
        "orchestrator",
        "core"
    ],

    "governanca": [
        "governance",
        "compliance",
        "security",
        "vault"
    ],

    "financeiro": [
        "finance",
        "market",
        "treasury",
        "consorcio"
    ],

    "juridico": [
        "juris",
        "adv",
        "legal",
        "tribunal"
    ],

    "educacional": [
        "escola",
        "educacao",
        "aluno",
        "professor"
    ],

    "analytics": [
        "analytics",
        "data",
        "ai",
        "forecast"
    ]
}

# =========================================================
# HASH
# =========================================================

def gerar_hash(texto):

    return hashlib.sha256(
        texto.encode()
    ).hexdigest()

# =========================================================
# CLASSIFICAÃ‡ÃƒO
# =========================================================

def classificar_ativo(nome):

    nome = nome.lower()

    categorias_encontradas = []

    for categoria, palavras in CATEGORIAS.items():

        for palavra in palavras:

            if palavra in nome:

                categorias_encontradas.append(
                    categoria
                )

                break

    if not categorias_encontradas:

        categorias_encontradas.append(
            "experimental"
        )

    return categorias_encontradas

# =========================================================
# SCORE
# =========================================================

def score_ativo(nome):

    nome = nome.lower()

    score = 0

    palavras_estrategicas = [

        "regulus",
        "lexus",
        "omega",
        "turca",
        "treasury",
        "governance",
        "premium",
        "core",
        "ai",
        "analytics"

    ]

    for palavra in palavras_estrategicas:

        if palavra in nome:
            score += 15

    extensoes_valiosas = [
        ".py",
        ".html",
        ".js"
    ]

    for ext in extensoes_valiosas:

        if nome.endswith(ext):
            score += 10

    return min(score, 100)

# =========================================================
# MATRIZ OU CLONE
# =========================================================

def tipo_ativo(nome):

    nome = nome.lower()

    if "clone" in nome:
        return "clone"

    if "backup" in nome:
        return "backup"

    if "copy" in nome:
        return "derivacao"

    return "matriz"

# =========================================================
# Ã“RFÃƒO
# =========================================================

def ativo_orfao(caminho):

    try:

        pasta = os.path.dirname(caminho)

        arquivos = os.listdir(pasta)

        if len(arquivos) <= 1:
            return True

        return False

    except:
        return False

# =========================================================
# CARREGA INVENTÃRIO
# =========================================================

def carregar_inventario():

    with open(
        INPUT_JSON,
        "r",
        encoding="utf-8"
    ) as f:

        return json.load(f)

# =========================================================
# ANALISA
# =========================================================

def analisar_ativos(ativos):

    resultado = []

    for ativo in ativos:

        nome = ativo["arquivo"]

        caminho = ativo["caminho"]

        categorias = classificar_ativo(
            nome
        )

        score = score_ativo(
            nome
        )

        registro = {

            "arquivo": nome,

            "caminho": caminho,

            "categorias": categorias,

            "score": score,

            "tipo": tipo_ativo(
                nome
            ),

            "orfao": ativo_orfao(
                caminho
            ),

            "timestamp": str(
                datetime.now()
            )
        }

        resultado.append(
            registro
        )

    return resultado

# =========================================================
# RELATÃ“RIO
# =========================================================

def gerar_relatorio(dados):

    total = len(dados)

    premium = len([
        x for x in dados
        if x["score"] >= 40
    ])

    orfaos = len([
        x for x in dados
        if x["orfao"]
    ])

    matrizes = len([
        x for x in dados
        if x["tipo"] == "matriz"
    ])

    with open(
        OUTPUT_RELATORIO,
        "w",
        encoding="utf-8"
    ) as f:

        f.write("=" * 70 + "\n")
        f.write(" IOTEC INVENTÃRIO INTELIGENTE\n")
        f.write("=" * 70 + "\n\n")

        f.write(f"TOTAL DE ATIVOS: {total}\n")
        f.write(f"ATIVOS PREMIUM: {premium}\n")
        f.write(f"MATRIZES: {matrizes}\n")
        f.write(f"Ã“RFÃƒOS: {orfaos}\n\n")

        f.write("=" * 70 + "\n")
        f.write(" TOP 50 MAIS ESTRATÃ‰GICOS\n")
        f.write("=" * 70 + "\n\n")

        top = sorted(
            dados,
            key=lambda x: x["score"],
            reverse=True
        )[:50]

        for item in top:

            linha = (
                f"[{item['score']}] "
                f"{item['arquivo']} "
                f"-> {','.join(item['categorias'])}\n"
            )

            f.write(linha)

# =========================================================
# JSON
# =========================================================

def salvar_json(dados):

    os.makedirs(
        OUTPUT_DIR,
        exist_ok=True
    )

    with open(
        OUTPUT_JSON,
        "w",
        encoding="utf-8"
    ) as f:

        json.dump(
            dados,
            f,
            indent=4,
            ensure_ascii=False
        )

# =========================================================
# EXECUÃ‡ÃƒO
# =========================================================

def executar():

    print("=" * 70)
    print(" IOTEC INVENTÃRIO INTELIGENTE")
    print("=" * 70)
    print()

    print("[+] CARREGANDO INVENTÃRIO")

    ativos = carregar_inventario()

    print(
        f"[+] {len(ativos)} ATIVOS CARREGADOS"
    )

    print()
    print("[+] ANALISANDO E CLASSIFICANDO")

    resultado = analisar_ativos(
        ativos
    )

    print()
    print("[+] GERANDO RELATÃ“RIOS")

    salvar_json(resultado)

    gerar_relatorio(resultado)

    print()
    print("=" * 70)
    print(" INVENTÃRIO INTELIGENTE FINALIZADO")
    print("=" * 70)

    print()

    print(
        f"ATIVOS ANALISADOS: {len(resultado)}"
    )

    print()
    print(
        f"JSON -> {OUTPUT_JSON}"
    )

    print(
        f"TXT  -> {OUTPUT_RELATORIO}"
    )

# =========================================================
# START
# =========================================================

if __name__ == "__main__":

    executar()

