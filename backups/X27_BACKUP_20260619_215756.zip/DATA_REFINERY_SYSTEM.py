﻿# =========================================================
# IOTEC DATA REFINERY SYSTEM
# REFINARIA OPERACIONAL DE DADOS
# =========================================================

from flask import Flask, jsonify
from flask_cors import CORS

import os
import hashlib
import mimetypes
from datetime import datetime

# =========================================================
# APP
# =========================================================

app = Flask(__name__)

CORS(app)

# =========================================================
# RESERVATORIOS
# =========================================================

RESERVATORIOS = [

    "C:/IOTEC",
    "C:/",
    "D:/"
]

# =========================================================
# BASES
# =========================================================

DADOS_BRUTOS = []

DADOS_REFINADOS = []

DADOS_SENSIVEIS = []

DADOS_COMERCIAIS = []

DADOS_ORFAOS = []

DADOS_PREMIUM = []

LOG_REFINARIA = []

HASHES = set()

# =========================================================
# CONFIGURACOES
# =========================================================

COMERCIAIS = [

    ".xlsx",
    ".csv",
    ".json",
    ".sql",
    ".db",
    ".sqlite"
]

SENSIVEIS = [

    ".env",
    ".pem",
    ".key",
    ".token"
]

PALAVRAS_PREMIUM = [

    "governance",
    "executive",
    "orchestrator",
    "enterprise",
    "premium",
    "analytics",
    "revenue",
    "finance",
    "audit"
]

IGNORAR_PASTAS = [

    "$Recycle.Bin",
    "System Volume Information",
    "Windows",
    "Program Files",
    "Program Files (x86)",
    "AppData",
    "Temp"
]

# =========================================================
# HASH
# =========================================================

def gerar_hash(path):

    try:

        with open(path, "rb") as f:

            return hashlib.md5(
                f.read(4096)
            ).hexdigest()

    except:

        return None

# =========================================================
# ORFAO
# =========================================================

def eh_orfao(path):

    try:

        tamanho = os.path.getsize(path)

        if tamanho < 200:

            return True

        return False

    except:

        return False

# =========================================================
# CLASSIFICADOR
# =========================================================

def classificar(path):

    nome = os.path.basename(path).lower()

    ext = os.path.splitext(nome)[1]

    categorias = []

    # =====================================================
    # COMERCIAL
    # =====================================================

    if ext in COMERCIAIS:

        categorias.append("comercial")

    # =====================================================
    # SENSIVEL
    # =====================================================

    if ext in SENSIVEIS:

        categorias.append("sensivel")

    # =====================================================
    # PREMIUM
    # =====================================================

    for palavra in PALAVRAS_PREMIUM:

        if palavra in nome:

            categorias.append("premium")

            break

    return categorias

# =========================================================
# HOME
# =========================================================

@app.route('/')

def home():

    return jsonify({

        "empresa":
        "IOTEC",

        "refinery":
        "online",

        "modo":
        "refinaria_operacional",

        "timestamp":
        datetime.now().strftime(
            "%d/%m/%Y %H:%M:%S"
        )
    })

# =========================================================
# PROSPECCAO
# =========================================================

@app.route('/refinery/prospectar')

def prospectar():

    # =====================================================
    # RESET
    # =====================================================

    DADOS_BRUTOS.clear()

    DADOS_REFINADOS.clear()

    DADOS_SENSIVEIS.clear()

    DADOS_COMERCIAIS.clear()

    DADOS_ORFAOS.clear()

    DADOS_PREMIUM.clear()

    LOG_REFINARIA.clear()

    HASHES.clear()

    # =====================================================
    # VARREDURA
    # =====================================================

    for reservatorio in RESERVATORIOS:

        if not os.path.exists(reservatorio):

            continue

        for pasta, subpastas, arquivos in os.walk(reservatorio):

            # =================================================
            # IGNORAR PASTAS PESADAS
            # =================================================

            subpastas[:] = [

                p for p in subpastas

                if p not in IGNORAR_PASTAS
            ]

            for arquivo in arquivos:

                try:

                    path = os.path.join(
                        pasta,
                        arquivo
                    )

                    if not os.path.exists(path):

                        continue

                    tamanho = os.path.getsize(path)

                    hash_file = gerar_hash(path)

                    if hash_file in HASHES:

                        continue

                    HASHES.add(hash_file)

                    mime = mimetypes.guess_type(path)[0]

                    item = {

                        "arquivo":
                        arquivo,

                        "path":
                        path,

                        "tamanho":
                        tamanho,

                        "mime":
                        mime,

                        "hash":
                        hash_file,

                        "timestamp":
                        datetime.now().strftime(
                            "%d/%m/%Y %H:%M:%S"
                        )
                    }

                    DADOS_BRUTOS.append(item)

                    categorias = classificar(path)

                    refinado = {

                        **item,

                        "categorias":
                        categorias
                    }

                    DADOS_REFINADOS.append(refinado)

                    # =========================================
                    # COMERCIAL
                    # =========================================

                    if "comercial" in categorias:

                        DADOS_COMERCIAIS.append(refinado)

                    # =========================================
                    # SENSIVEL
                    # =========================================

                    if "sensivel" in categorias:

                        DADOS_SENSIVEIS.append(refinado)

                    # =========================================
                    # PREMIUM
                    # =========================================

                    if "premium" in categorias:

                        DADOS_PREMIUM.append(refinado)

                    # =========================================
                    # ORFAOS
                    # =========================================

                    if eh_orfao(path):

                        DADOS_ORFAOS.append(refinado)

                except:

                    continue

    # =====================================================
    # LOG
    # =====================================================

    LOG_REFINARIA.append({

        "evento":
        "refinaria_concluida",

        "timestamp":
        datetime.now().strftime(
            "%d/%m/%Y %H:%M:%S"
        )
    })

    return jsonify({

        "status":
        "refinaria_concluida",

        "dados_brutos":
        len(DADOS_BRUTOS),

        "dados_refinados":
        len(DADOS_REFINADOS),

        "dados_comerciais":
        len(DADOS_COMERCIAIS),

        "dados_premium":
        len(DADOS_PREMIUM),

        "dados_sensiveis":
        len(DADOS_SENSIVEIS),

        "dados_orfaos":
        len(DADOS_ORFAOS)
    })

# =========================================================
# COMERCIAL
# =========================================================

@app.route('/refinery/comercial')

def comercial():

    return jsonify({

        "ativos":
        DADOS_COMERCIAIS[:300]
    })

# =========================================================
# PREMIUM
# =========================================================

@app.route('/refinery/premium')

def premium():

    return jsonify({

        "ativos":
        DADOS_PREMIUM[:300]
    })

# =========================================================
# SENSIVEIS
# =========================================================

@app.route('/refinery/sensiveis')

def sensiveis():

    return jsonify({

        "ativos":
        DADOS_SENSIVEIS[:100]
    })

# =========================================================
# ORFAOS
# =========================================================

@app.route('/refinery/orfaos')

def orfaos():

    return jsonify({

        "ativos":
        DADOS_ORFAOS[:300]
    })

# =========================================================
# EXECUTIVO
# =========================================================

@app.route('/refinery/executivo')

def executivo():

    return jsonify({

        "empresa":
        "IOTEC",

        "modo":
        "refinaria_executiva",

        "dados_brutos":
        len(DADOS_BRUTOS),

        "dados_refinados":
        len(DADOS_REFINADOS),

        "dados_comerciais":
        len(DADOS_COMERCIAIS),

        "dados_premium":
        len(DADOS_PREMIUM),

        "dados_sensiveis":
        len(DADOS_SENSIVEIS),

        "dados_orfaos":
        len(DADOS_ORFAOS),

        "timestamp":
        datetime.now().strftime(
            "%d/%m/%Y %H:%M:%S"
        )
    })

# =========================================================
# LOGS
# =========================================================

@app.route('/refinery/log')

def logs():

    return jsonify({

        "logs":
        LOG_REFINARIA
    })

# =========================================================
# START
# =========================================================

if __name__ == '__main__':

    print("")
    print("=" * 70)
    print(" IOTEC DATA REFINERY SYSTEM ")
    print("=" * 70)
    print("")

    app.run(

        host='0.0.0.0',

        port=8000
    )

