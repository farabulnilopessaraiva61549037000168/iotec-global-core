import sqlite3
import pandas as pd
from datetime import datetime

DB = r"C:\IOTEC_OMEGA_X\backend\iotec.db"
CSV = r"C:\IOTEC\fila_comercial.csv"

conn = sqlite3.connect(DB)
cur = conn.cursor()

df = pd.read_csv(CSV)

geradas = 0
receita = 0

for _, row in df.iterrows():

    empresa = str(row["empresa"])
    setor = str(row["setor"])
    score = int(row["lead_score"])

    servico = None
    valor = 0

    if score >= 40:

        servico = "AUTOMACAO INDUSTRIAL"
        valor = 10000

    elif score >= 25:

        servico = "CRM + DASHBOARD"
        valor = 3500

    elif score >= 15:

        servico = "DIAGNOSTICO EMPRESARIAL"
        valor = 500

    else:

        continue

    existe = cur.execute("""

    SELECT COUNT(*)

    FROM commercial_opportunities

    WHERE company=?

    """,(empresa,)).fetchone()[0]

    if existe:
        continue

    cur.execute("""

    INSERT INTO commercial_opportunities(

        company,
        sector,
        lead_score,
        recommended_service,
        estimated_value,
        status,
        created_at

    )

    VALUES(

        ?,?,?,?,?,?,?

    )

    """,(

        empresa,
        setor,
        score,
        servico,
        valor,
        "NOVA",
        datetime.now().strftime(
            "%d/%m/%Y %H:%M:%S"
        )

    ))

    geradas += 1
    receita += valor

conn.commit()
conn.close()

print("")
print("===================================")
print("COMMERCIAL OPPORTUNITY ENGINE")
print("===================================")
print("")
print("OPORTUNIDADES:", geradas)
print("")
print("RECEITA POTENCIAL:")
print(f"R$ {receita:,.2f}")
print("")