# ==========================================================
# 🧠 IOTEC ORCHESTRATOR MASTER v1.0
# Cérebro central de roteamento do sistema
# ==========================================================

from datetime import datetime

# -----------------------------
# 🏛 MAPA DE DECISÃO
# -----------------------------
ROTEAMENTO = {
    "criacao_sistema": "producao",
    "bug": "core",
    "erro": "core",
    "cliente": "atendimento",
    "formulario": "recepcao",
    "interface": "recepcao",
    "dados": "dados",
    "relatorio": "dados",
    "backup": "almoxarifado",
    "auditoria": "presidencia",
    "governanca": "presidencia",
    "documento": "documentos",
}


# -----------------------------
# 🧠 ANALISADOR DE INTENÇÃO
# -----------------------------
def analisar_intencao(texto):
    texto = texto.lower()

    for chave in ROTEAMENTO:
        if chave in texto:
            return ROTEAMENTO[chave]

    return "ruido"


# -----------------------------
# ⚡ DEFINIÇÃO DE PRIORIDADE
# -----------------------------
def prioridade(texto):
    texto = texto.lower()

    if "erro" in texto or "bug" in texto:
        return "CRITICA"

    if "cliente" in texto or "pedido" in texto:
        return "ALTA"

    if "relatorio" in texto:
        return "MEDIA"

    return "BAIXA"


# -----------------------------
# 🏢 SIMULAÇÃO DE ROTA
# -----------------------------
def rota(setor):
    estrutura = {
        "recepcao": "Torre - Entrada (Nível 1)",
        "atendimento": "Torre - Suporte (Nível 2)",
        "producao": "Torre - Execução (Nível 3)",
        "dados": "Torre - Inteligência (Nível 4)",
        "core": "Torre - Núcleo (Nível 5)",
        "presidencia": "Torre - Governança (Nível 6)",
        "almoxarifado": "Torre - Arquivo (Subsolo)",
        "documentos": "Torre - Documentação",
        "ruido": "Fila de análise manual"
    }

    return estrutura.get(setor, "Desconhecido")


# -----------------------------
# 🧠 ORQUESTRADOR PRINCIPAL
# -----------------------------
def orquestrar(requisicao):
    setor = analisar_intencao(requisicao)
    nivel = prioridade(requisicao)
    destino = rota(setor)

    return {
        "timestamp": str(datetime.now()),
        "entrada": requisicao,
        "setor_destino": setor,
        "prioridade": nivel,
        "rota": destino
    }


# -----------------------------
# 📊 VISUALIZAÇÃO
# -----------------------------
def imprimir(resultado):
    print("\n====================================")
    print("🧠 IOTEC ORCHESTRATOR MASTER")
    print("====================================")

    print(f"\n📩 REQUISIÇÃO: {resultado['entrada']}")
    print(f"🏢 SETOR DESTINO: {resultado['setor_destino']}")
    print(f"⚡ PRIORIDADE: {resultado['prioridade']}")
    print(f"🧭 ROTA: {resultado['rota']}")

    print("\n====================================")
    print("✔ DECISÃO TOMADA PELO NÚCLEO")
    print("====================================\n")


# -----------------------------
# 🚀 EXECUÇÃO (TESTE)
# -----------------------------
if __name__ == "__main__":

    print("🧠 ORCHESTRATOR MASTER INICIADO")

    while True:
        req = input("\nDigite requisição (ou 'sair'): ")

        if req.lower() == "sair":
            break

        resultado = orquestrar(req)
        imprimir(resultado)