﻿import os
from collections import defaultdict

ROOT = r"C:\IOTEC"

# ðŸš« RUÃDO DO SISTEMA
BLACKLIST_PATHS = [
    "venv", "site-packages", "dist-packages",
    "__pycache__", "pip", "distutils",
    "lib\\python", "lib/python"
]

BLACKLIST_MODULES = {
    "sys","os","json","time","re","math",
    "datetime","logging","subprocess",
    "functools","itertools","threading",
    "flask","psutil"
}


def is_valid(path):
    p = path.lower()
    return not any(b in p for b in BLACKLIST_PATHS)


def scan_py_files():
    files = []

    for r, _, f in os.walk(ROOT):
        if not is_valid(r):
            continue

        for file in f:
            if file.endswith(".py"):
                full = os.path.join(r, file)
                if is_valid(full):
                    files.append(full)

    return files


def extract_deps(file_path):
    try:
        with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
            lines = f.readlines()

        deps = set()

        for l in lines:
            l = l.strip()

            if l.startswith("import "):
                deps.add(l.split("import ")[1].split(" ")[0])

            elif l.startswith("from "):
                parts = l.split()
                if len(parts) > 1:
                    deps.add(parts[1])

        return {d for d in deps if d not in BLACKLIST_MODULES}

    except:
        return set()


def build_graph():
    files = scan_py_files()

    graph = defaultdict(set)

    for f in files:
        deps = extract_deps(f)

        # ðŸ”¥ normalizaÃ§Ã£o de identidade (remove duplicaÃ§Ã£o)
        node = os.path.basename(f)

        for d in deps:
            graph[node].add(d)

    return graph


def compute_brain(graph):
    score = []

    for node, deps in graph.items():
        score.append((node, len(deps)))

    # ordenaÃ§Ã£o limpa
    score.sort(key=lambda x: x[1], reverse=True)

    return score[:20]


def run():
    print("\n===================================")
    print(" ðŸ§  NEURAL BRAIN CLEAN (FINAL)")
    print("===================================\n")

    graph = build_graph()

    brain = compute_brain(graph)

    print("ðŸ§  CÃ‰REBRO REAL CONSOLIDADO:\n")

    for node, score in brain:
        print(f"{node} -> {score} conexÃµes")

    print("\nðŸ“Š TOTAL DE NÃ“S:", len(graph))

    # salvar mapa limpo
    with open("IOTEC_NEURAL_BRAIN_FINAL.json", "w", encoding="utf-8") as f:
        import json
        json.dump({k: list(v) for k, v in graph.items()}, f, indent=2)

    print("\nRelatÃ³rio salvo: IOTEC_NEURAL_BRAIN_FINAL.json")


if __name__ == "__main__":
    run()
