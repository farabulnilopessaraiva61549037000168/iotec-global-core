import json
from pathlib import Path
from datetime import datetime

ROOT = Path(r"C:\IOTEC")

ARQ_WARROOM = ROOT / "IOTEC_WAR_ROOM_DATABASE.json"

print("")
print("===================================")
print("IOTEC LEAD SOURCE AUDITOR")
print("===================================")

print("")
print("DATA:")
print(datetime.now())

origens = {}

try:

    with open(
        ARQ_WARROOM,
        "r",
        encoding="utf-8-sig"
    ) as f:

        db = json.load(f)

    oportunidades = db.get(
        "oportunidades",
        []
    )

    for op in oportunidades:

        origem = op.get(
            "origem",
            "DESCONHECIDA"
        )

        if origem not in origens:

            origens[origem] = 0

        origens[origem] += 1

except Exception as erro:

    print("")
    print("ERRO:")
    print(erro)

print("")
print("===================================")
print("ORIGENS DETECTADAS")
print("===================================")

if len(origens) == 0:

    print("")
    print("NENHUMA ORIGEM REGISTRADA")

else:

    for origem, qtd in origens.items():

        print(
            f"{origem} -> {qtd}"
        )

print("")
print("===================================")
print("MISSAO")
print("===================================")

print("LOCALIZAR CANAIS DE CAPTACAO")
print("")
print("SITE")
print("FORMULARIO")
print("WHATSAPP")
print("EMAIL")
print("PORTAL")
print("REDES_SOCIAIS")
print("INDICACAO")

print("")
print("===================================")
print("PROXIMA PERGUNTA")
print("===================================")

print(
    "QUAL CANAL ESTA "
    "GERANDO MAIS OPORTUNIDADES?"
)

print("")
print("AUDITORIA FINALIZADA")