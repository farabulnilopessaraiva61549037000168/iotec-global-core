﻿# ============================================================
# IOTEC_MAIL_CORE_INTELIGENTE.py
# NÃºcleo que lÃª e-mail, identifica origem e classifica
# ============================================================

import imaplib
import email
from email.header import decode_header

# =========================
# CONFIG
# =========================

EMAIL = "seuemail@gmail.com"
SENHA = "senha_app"
IMAP = "imap.gmail.com"

# =========================
# DETECTAR PAÃS
# =========================

def detectar_origem(remetente):

    remetente = remetente.lower()

    if ".br" in remetente:
        return "Brasil"
    elif ".us" in remetente:
        return "EUA"
    elif ".de" in remetente:
        return "Alemanha"
    elif ".pt" in remetente:
        return "Portugal"
    else:
        return "Internacional"

# =========================
# CLASSIFICAÃ‡ÃƒO
# =========================

def classificar(assunto, remetente):

    assunto = assunto.lower()

    if "paypal" in remetente or "payment" in assunto:
        return "PAGAMENTO"

    elif "formulÃ¡rio" in assunto or "analysis" in assunto:
        return "SOLICITACAO"

    elif "support" in assunto or "contato" in assunto:
        return "CLIENTE"

    elif "invoice" in assunto or "cobranÃ§a" in assunto:
        return "FINANCEIRO"

    return "OUTROS"

# =========================
# LEITURA
# =========================

def ler_emails():

    mail = imaplib.IMAP4_SSL(IMAP)
    mail.login(EMAIL, SENHA)
    mail.select("inbox")

    status, mensagens = mail.search(None, "ALL")
    mensagens = mensagens[0].split()

    for num in mensagens[-10:]:

        status, msg_data = mail.fetch(num, "(RFC822)")
        msg = email.message_from_bytes(msg_data[0][1])

        assunto, enc = decode_header(msg["Subject"])[0]
        if isinstance(assunto, bytes):
            assunto = assunto.decode(enc if enc else "utf-8")

        remetente = msg.get("From")

        origem = detectar_origem(remetente)
        tipo = classificar(assunto, remetente)

        print("\nðŸ“© NOVA ENTRADA")
        print("Origem:", origem)
        print("Tipo:", tipo)
        print("Assunto:", assunto)

        # =========================
        # AÃ‡Ã•ES AUTOMÃTICAS
        # =========================

        if tipo == "PAGAMENTO":
            print("ðŸ’° Confirmar pagamento e liberar fluxo")

        elif tipo == "SOLICITACAO":
            print("ðŸ“Š Gerar anÃ¡lise e alimentar painel")

        elif tipo == "CLIENTE":
            print("ðŸ‘¤ Enviar para atendimento")

        elif tipo == "FINANCEIRO":
            print("âš ï¸ Enviar para setor administrativo")

# =========================
# EXECUTAR
# =========================

if __name__ == "__main__":
    ler_emails()

