﻿def responder(pergunta, idioma="pt"):
    if idioma == "en":
        return "Your request has been processed."
    else:
        return "Seu pedido foi processado."

