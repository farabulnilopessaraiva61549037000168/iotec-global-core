﻿import streamlit as st
import json
import time

ARQUIVO = "iotec_fluxo.json"

st.set_page_config(layout="wide")

st.title("ðŸ§  IOTEC - Sistema Vivo 24h")

def carregar():
    try:
        with open(ARQUIVO, "r") as f:
            return json.load(f)
    except:
        return {"entradas": [], "saidas": [], "bloqueios": []}

dados = carregar()

col1, col2, col3 = st.columns(3)

with col1:
    st.markdown("### ðŸ“¥ Entradas")
    for e in dados["entradas"][-5:]:
        st.write(e)

with col2:
    st.markdown("### ðŸš€ SaÃ­das")
    for s in dados["saidas"][-5:]:
        st.write(s)

with col3:
    st.markdown("### ðŸ”´ Bloqueios")
    for b in dados["bloqueios"][-5:]:
        st.write(b)

st.metric("Total Entradas", len(dados["entradas"]))

time.sleep(5)
st.rerun()

