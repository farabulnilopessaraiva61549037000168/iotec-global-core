﻿import os
import re
import json
from collections import defaultdict, Counter

ROOT = input("Caminho do nÃºcleo: ").strip()

graph = defaultdict(set)
reverse_graph = defaultdict(set)

files_index = []

# -----------------------------
# 1. COLETA DE ARQUIVOS
# -----------------------------
def collect_files():
    for root, _, files in os.walk(ROOT):
        for f in files:
            if f.endswith(".py"):
                full_path = os.path.join(root, f)
                files_index.append(full_path)

# -----------------------------
# 2. EXTRAÃ‡ÃƒO DE DEPENDÃŠNCIAS
# -----------------------------
def extract_links(file_path):
    try:
        with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
            content = f.read()

        imports = re.findall(r"import (\w+)", content)
        from_imports = re.findall(r"from (\w+) import", content)

        deps = set(imports + from_imports)

        return deps

    except:
        return set()

# -----------------------------
# 3. CONSTRUÃ‡ÃƒO DO GRAFO
# -----------------------------
def build_graph():
    name_map = {}

    for f in files_index:
        name_map[os.path.basename(f).replace(".py", "")] = f

    for f in files_index:
        module_name = os.path.basename(f).replace(".py", "")
        deps = extract_links(f)

        for d in deps:
            if d in name_map:
                graph[module_name].add(d)
                reverse_graph[d].add(module_name)

# -----------------------------
# 4. CENTRALIDADE (cÃ©rebro real)
# -----------------------------
def compute_centrality():
    scores = Counter()

    for node in graph:
        scores[node] += len(graph[node]) * 2  # influencia direta

    for node in reverse_graph:
        scores[node] += len(reverse_graph[node]) * 3  # dependÃªncia recebida

    return scores

# -----------------------------
# 5. DETECTA MÃ“DULO CÃ‰REBRO
# -----------------------------
def select_brain(scores):
    if not scores:
        return None

    return scores.most_common(1)[0]

# -----------------------------
# 6. DETECTA ILHAS (dead zones)
# -----------------------------
def detect_isolated():
    isolated = []

    all_nodes = set(list(graph.keys()) + list(reverse_graph.keys()))

    for node in all_nodes:
        if len(graph[node]) == 0 and len(reverse_graph[node]) == 0:
            isolated.append(node)

    return isolated

# -----------------------------
# 7. HOT NODES
# -----------------------------
def detect_hot_nodes():
    return sorted(reverse_graph.items(), key=lambda x: len(x[1]), reverse=True)[:10]

# -----------------------------
# 8. EXECUÃ‡ÃƒO
# -----------------------------
def run():
    print("\n[NEURAL MAP] Escaneando nÃºcleo...")

    collect_files()
    build_graph()

    scores = compute_centrality()
    brain = select_brain(scores)
    isolated = detect_isolated()
    hot = detect_hot_nodes()

    report = {
        "total_files": len(files_index),
        "nodes": len(graph),
        "brain_node": brain,
        "isolated_nodes": isolated,
        "hot_nodes": [(k, len(v)) for k, v in hot],
        "centrality_scores": dict(scores)
    }

    with open("IOTEC_NEURAL_MAP_REPORT.json", "w", encoding="utf-8") as f:
        json.dump(report, f, indent=4, ensure_ascii=False)

    print("\n===================================")
    print("IOTEC NEURAL MAP ENGINE")
    print("===================================")

    print("Arquivos analisados:", len(files_index))
    print("NÃ³s no grafo:", len(graph))

    print("\nðŸ§  CÃ‰REBRO REAL DO SISTEMA:")
    print(brain)

    print("\nðŸ”¥ HOT NODES:")
    for h in hot:
        print(h[0], "->", len(h[1]), "conexÃµes")

    print("\nðŸ§Š ISOLADOS:")
    print(len(isolated), "mÃ³dulos")

    print("\nRelatÃ³rio salvo: IOTEC_NEURAL_MAP_REPORT.json")

run()
