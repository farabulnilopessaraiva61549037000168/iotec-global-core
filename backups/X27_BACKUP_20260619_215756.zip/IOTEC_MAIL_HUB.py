﻿# ============================================================
# IOTEC_MAIL_HUB.py
# Leitura de e-mail + classificaÃ§Ã£o automÃ¡tica
# ============================================================

import imaplib
import email
from email.header import decode_header

# =========================
# CONFIGURAÃ‡ÃƒO
# =========================

EMAIL = "seuemail@gmail.com"
SENHA = "suasenha"
IMAP_SERVER = "imap.gmail.com"

# =========================
# CLASSIFICAÃ‡ÃƒO
# =========================

def classificar_email(remetente, assunto, corpo):

    assunto = assunto.lower()

    if "paypal" in remetente or "pagamento" in assunto:
        return "PAGAMENTO"

    elif "cliente" in assunto or "contato" in assunto:
        return "CLIENTE"

    elif "cnpj" in assunto or "empresa" in assunto:
        return "ADMINISTRATIVO"

    elif "formulÃ¡rio" in assunto:
        return "PROCESSO"

    elif "cobranÃ§a" in assunto or "dÃ©bito" in assunto:
        return "ALERTA_FINANCEIRO"

    return "OUTROS"

# =========================
# LEITURA DE EMAIL
# =========================

def ler_emails():

    mail = imaplib.IMAP4_SSL(IMAP_SERVER)
    mail.login(EMAIL, SENHA)
    mail.select("inbox")

    status, mensagens = mail.search(None, "ALL")
    mensagens = mensagens[0].split()

    for num in mensagens[-10:]:  # Ãºltimos 10

        status, msg_data = mail.fetch(num, "(RFC822)")
        msg = email.message_from_bytes(msg_data[0][1])

        assunto, encoding = decode_header(msg["Subject"])[0]
        if isinstance(assunto, bytes):
            assunto = assunto.decode(encoding if encoding else "utf-8")

        remetente = msg.get("From")

        tipo = classificar_email(remetente, assunto, "")

        print("\nðŸ“© Novo Email Detectado")
        print("Assunto:", assunto)
        print("Remetente:", remetente)
        print("Tipo:", tipo)

        # =========================
        # AÃ‡Ã•ES AUTOMÃTICAS
        # =========================

        if tipo == "PAGAMENTO":
            print("ðŸ’° Enviar para mÃ³dulo financeiro")

        elif tipo == "CLIENTE":
            print("ðŸ‘¤ Enviar para atendimento")

        elif tipo == "PROCESSO":
            print("âš™ï¸ Iniciar geraÃ§Ã£o de dossiÃª")

        elif tipo == "ALERTA_FINANCEIRO":
            print("âš ï¸ Enviar alerta administrativo")

# =========================
# EXECUTAR
# =========================

if __name__ == "__main__":
    ler_emails()

