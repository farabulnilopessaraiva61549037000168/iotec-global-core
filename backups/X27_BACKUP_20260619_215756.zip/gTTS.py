﻿from gtts import gTTS

def gerar_audio(texto):
    tts = gTTS(texto, lang="pt-br")
    tts.save("resposta.mp3")

