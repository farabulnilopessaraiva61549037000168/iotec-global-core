﻿def criar_entrega(pedido):
    nome_arquivo = f"C:\\IOTEC\\entregas\\{pedido['id']}.txt"

    with open(nome_arquivo, "w") as f:
        f.write(f"Entrega do serviÃ§o: {pedido['servico']}\n")
        f.write("Status: concluÃ­do\n")

    return nome_arquivo

