﻿# ============================================================
# IOTEC_DUAL_MAIL_DASHBOARD.py
# Painel visual com duas caixas de e-mail (Pessoal + Comercial)
# IOTEC - NÃºcleo Inteligente
# ============================================================

import streamlit as st
import imaplib
import email
from email.header import decode_header

st.set_page_config(layout="wide")

st.title("ðŸ“¬ IOTEC - Painel de E-mails Inteligente")
st.subheader("Caixa Pessoal + Caixa Comercial (triagem automÃ¡tica)")

# =========================
# CONFIGURAÃ‡ÃƒO DAS CAIXAS
# =========================

CAIXAS = [
    {
        "nome": "ðŸ“§ Caixa Pessoal (Operacional)",
        "email": "seu@gmail.com",
        "senha": "senha_app",
        "imap": "imap.gmail.com",
        "tipo": "OPERACIONAL"
    },
    {
        "nome": "ðŸ¢ Caixa Comercial (Clientes)",
        "email": "seu@gmail.com",  # Proton encaminhado
        "senha": "senha_app",
        "imap": "imap.gmail.com",
        "tipo": "CLIENTE"
    }
]

# =========================
# CLASSIFICAÃ‡ÃƒO
# =========================

def classificar_email(tipo_caixa, assunto):

    assunto = assunto.lower()

    if tipo_caixa == "CLIENTE":
        return "ðŸ‘¤ CLIENTE"

    if "paypal" in assunto or "payment" in assunto:
        return "ðŸ’³ PAGAMENTO"

    if "invoice" in assunto or "cobranÃ§a" in assunto:
        return "ðŸ’° FINANCEIRO"

    if "promo" in assunto or "newsletter" in assunto:
        return "ðŸš« SPAM"

    return "ðŸ“Œ OUTROS"

# =========================
# LEITURA DE EMAIL
# =========================

def ler_caixa(config):

    resultados = []

    try:
        mail = imaplib.IMAP4_SSL(config["imap"])
        mail.login(config["email"], config["senha"])
        mail.select("inbox")

        status, mensagens = mail.search(None, "ALL")
        mensagens = mensagens[0].split()

        for num in mensagens[-5:]:

            status, msg_data = mail.fetch(num, "(RFC822)")
            msg = email.message_from_bytes(msg_data[0][1])

            assunto, enc = decode_header(msg["Subject"])[0]
            if isinstance(assunto, bytes):
                assunto = assunto.decode(enc if enc else "utf-8")

            remetente = msg.get("From")

            tipo = classificar_email(config["tipo"], assunto)

            resultados.append({
                "assunto": assunto,
                "remetente": remetente,
                "tipo": tipo
            })

    except Exception as e:
        resultados.append({
            "assunto": "Erro ao conectar",
            "remetente": str(e),
            "tipo": "âš ï¸ ERRO"
        })

    return resultados

# =========================
# EXIBIÃ‡ÃƒO
# =========================

col1, col2 = st.columns(2)

for i, caixa in enumerate(CAIXAS):

    dados = ler_caixa(caixa)

    with (col1 if i == 0 else col2):

        st.markdown(f"### {caixa['nome']}")

        for item in dados:

            st.markdown(f"""
            ---
            **Tipo:** {item['tipo']}  
            **Assunto:** {item['assunto']}  
            **Remetente:** {item['remetente']}  
            """)

# =========================
# BOTÃƒO ATUALIZAR
# =========================

if st.button("ðŸ”„ Atualizar Caixa"):
    st.rerun()

