﻿def interpretar_mensagem(msg):

    msg = msg.lower()

    if "1" in msg or "anÃ¡lise" in msg:
        return "ANALISE"

    elif "2" in msg or "dÃºvida" in msg:
        return "DUVIDA"

    elif "3" in msg or "acompanhar" in msg:
        return "STATUS"

    elif "4" in msg or "suporte" in msg:
        return "SUPORTE"

    elif "nÃ£o entendi" in msg:
        return "REEXPLICAR"

    return "GERAL"

