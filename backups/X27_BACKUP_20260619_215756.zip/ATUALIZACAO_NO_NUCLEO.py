﻿import smtplib
from email.mime.text import MIMEText

EMAIL_REMETENTE = "seu_email@gmail.com"
SENHA_APP = "sua_senha_app"

def notificar_cliente(pedido, email_destino="seu_email@gmail.com"):

    mensagem = f"""
IOTEC - ENTREGA

Pedido: {pedido['id']}
ServiÃ§o: {pedido['servico']}

Seu serviÃ§o foi processado com sucesso.

Obrigado por utilizar a IOTEC.
"""

    msg = MIMEText(mensagem)
    msg["Subject"] = "Entrega IOTEC"
    msg["From"] = EMAIL_REMETENTE
    msg["To"] = email_destino

    try:
        servidor = smtplib.SMTP_SSL("smtp.gmail.com", 465)
        servidor.login(EMAIL_REMETENTE, SENHA_APP)
        servidor.send_message(msg)
        servidor.quit()

        print("ðŸ“© E-mail enviado com sucesso")

    except Exception as e:
        print("âŒ Erro ao enviar e-mail:", e)

