﻿import json
from datetime import datetime

def gerar_ordem(produto_nome):

    with open("C:\\IOTEC\\CORE\\produtos.json", "r", encoding="utf-8") as f:
        produtos = json.load(f)

    produto = next((p for p in produtos if p["nome"] == produto_nome), None)

    if not produto:
        print("Produto nÃ£o encontrado")
        return

    ordem = {
        "produto": produto_nome,
        "hora": datetime.now().strftime("%H:%M:%S"),
        "itens": produto["itens"],
        "status": "em produÃ§Ã£o"
    }

    with open("C:\\IOTEC\\CORE\\ordens.json", "a", encoding="utf-8") as f:
        f.write(json.dumps(ordem) + "\n")

    print("Ordem gerada:", ordem)

# TESTE
gerar_ordem("SNIA Score Global 9.85")

