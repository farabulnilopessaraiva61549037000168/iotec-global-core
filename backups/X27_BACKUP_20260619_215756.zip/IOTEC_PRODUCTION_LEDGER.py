# ==========================================================
# IOTEC PRODUCTION LEDGER
# CONTABILIDADE OPERACIONAL DO NÚCLEO
# NÃO EXECUTA MOTORES
# APENAS REGISTRA PRODUÇÃO
# ==========================================================

import json
import os
from datetime import datetime

ROOT = r"C:\IOTEC"

LEDGER_FILE = r"C:\IOTEC\IOTEC_PRODUCTION_LEDGER.json"

# ----------------------------------------------------------
# CRIA LEDGER SE NÃO EXISTIR
# ----------------------------------------------------------

if not os.path.exists(LEDGER_FILE):

    with open(
        LEDGER_FILE,
        "w",
        encoding="utf-8"
    ) as f:

        json.dump(
            {
                "created": str(datetime.now()),
                "records": []
            },
            f,
            indent=4,
            ensure_ascii=False
        )

# ----------------------------------------------------------
# CARREGA
# ----------------------------------------------------------

with open(
    LEDGER_FILE,
    "r",
    encoding="utf-8"
) as f:

    ledger = json.load(f)

# ----------------------------------------------------------
# MOTORES DA GRADE
# ----------------------------------------------------------

GRID_FILE = r"C:\IOTEC\IOTEC_OPERATION_GRID.json"

if os.path.exists(GRID_FILE):

    with open(
        GRID_FILE,
        "r",
        encoding="utf-8"
    ) as f:

        grid = json.load(f)

else:

    print("GRADE NÃO ENCONTRADA")
    raise SystemExit()

# ----------------------------------------------------------
# REGISTRA SNAPSHOT
# ----------------------------------------------------------

snapshot_time = str(datetime.now())

for layer, cfg in grid["layers"].items():

    for motor in cfg["motors"]:

        ledger["records"].append({

            "timestamp": snapshot_time,

            "motor": motor,

            "layer": layer,

            "status": "AGENDADO",

            "produced": None,

            "destination": None,

            "value_score": 0
        })

# ----------------------------------------------------------
# ESTATÍSTICAS
# ----------------------------------------------------------

stats = {}

for item in ledger["records"]:

    layer = item["layer"]

    stats[layer] = stats.get(layer, 0) + 1

ledger["stats"] = stats
ledger["last_update"] = snapshot_time

# ----------------------------------------------------------
# SALVA
# ----------------------------------------------------------

with open(
    LEDGER_FILE,
    "w",
    encoding="utf-8"
) as f:

    json.dump(
        ledger,
        f,
        indent=4,
        ensure_ascii=False
    )

# ----------------------------------------------------------
# RELATÓRIO
# ----------------------------------------------------------

print("")
print("===================================")
print("IOTEC PRODUCTION LEDGER")
print("===================================")
print("")

for layer, total in stats.items():

    print(
        f"{layer}: {total}"
    )

print("")
print("LEDGER:")
print(LEDGER_FILE)
print("")
print("CONCLUIDO")