import sqlite3
from datetime import datetime

DB = r"C:\IOTEC_OMEGA_X\backend\iotec.db"

conn = sqlite3.connect(DB)
cur = conn.cursor()

# ==================================================
# TABELA
# ==================================================

cur.execute("""

CREATE TABLE IF NOT EXISTS communication_queue(

    id INTEGER PRIMARY KEY AUTOINCREMENT,

    created_at TEXT,

    company TEXT,

    channel TEXT,

    objective TEXT,

    priority TEXT,

    message TEXT,

    status TEXT

)

""")

conn.commit()

# ==================================================
# OPORTUNIDADES
# ==================================================

rows = cur.execute("""

SELECT

    company,
    sector,
    recommended_service,
    estimated_value,
    status

FROM commercial_opportunities

ORDER BY estimated_value DESC

""").fetchall()

geradas = 0

for row in rows:

    empresa = row[0]
    setor = row[1]
    servico = row[2]
    valor = row[3]
    status = row[4]

    # ---------------------------------------------

    if status == "PAGAMENTO_PENDENTE":

        prioridade = "CRITICA"
        canal = "FINANCEIRO"

        objetivo = "CONFIRMACAO_PAGAMENTO"

        mensagem = f"""
Olá {empresa}.

Estamos com sua implantação pronta para início.

Gostaríamos de verificar a previsão de confirmação financeira
para reserva definitiva da agenda técnica.

Equipe IOTEC.
"""

    elif status == "NEGOCIACAO":

        prioridade = "ALTA"
        canal = "COMERCIAL"

        objetivo = "AGENDAR_REUNIAO"

        mensagem = f"""
Olá {empresa}.

Identificamos potencial para aplicação da solução:

{servico}

Gostaríamos de apresentar ganhos operacionais,
redução de retrabalho e oportunidades de automação.

Equipe IOTEC.
"""

    elif status == "PROPOSTA_ENVIADA":

        prioridade = "MEDIA"
        canal = "COMERCIAL"

        objetivo = "FOLLOWUP"

        mensagem = f"""
Olá {empresa}.

Gostaríamos de verificar se existem dúvidas sobre a proposta enviada.

Permanecemos à disposição para esclarecimentos.

Equipe IOTEC.
"""

    elif status == "EM_ANALISE":

        prioridade = "MEDIA"
        canal = "CONSULTORIA"

        objetivo = "DIAGNOSTICO"

        mensagem = f"""
Olá {empresa}.

Estamos avaliando oportunidades para o setor {setor}.

Podemos compartilhar um diagnóstico inicial sem compromisso.

Equipe IOTEC.
"""

    else:

        prioridade = "BAIXA"
        canal = "PROSPECCAO"

        objetivo = "QUALIFICACAO"

        mensagem = f"""
Olá {empresa}.

A IOTEC atua com automação,
painéis gerenciais e transformação digital.

Gostaríamos de entender seus desafios atuais.

Equipe IOTEC.
"""

    existe = cur.execute("""

    SELECT id

    FROM communication_queue

    WHERE company=?
    AND objective=?
    AND status='PENDENTE'

    """,(empresa, objetivo)).fetchone()

    if existe:
        continue

    cur.execute("""

    INSERT INTO communication_queue(

        created_at,
        company,
        channel,
        objective,
        priority,
        message,
        status

    )

    VALUES(?,?,?,?,?,?,?)

    """,(

        datetime.now().strftime("%d/%m/%Y %H:%M:%S"),
        empresa,
        canal,
        objetivo,
        prioridade,
        mensagem,
        "PENDENTE"

    ))

    geradas += 1

conn.commit()

total = cur.execute("""

SELECT COUNT(*)

FROM communication_queue

""").fetchone()[0]

print("")
print("===================================")
print("COMMUNICATION CENTER")
print("===================================")
print("")
print("MENSAGENS GERADAS:", geradas)
print("FILA TOTAL:", total)
print("")

for row in cur.execute("""

SELECT

company,
priority,
objective,
status

FROM communication_queue

ORDER BY id DESC

LIMIT 20

""").fetchall():

    print(row)

print("")
print("===================================")

conn.close()