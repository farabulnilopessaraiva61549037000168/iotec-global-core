DOMINIOS = {

    "AGUA": {
        "prioridade": 1,
        "missao": "Garantir abastecimento"
    },

    "ALIMENTOS": {
        "prioridade": 1,
        "missao": "Garantir segurança alimentar"
    },

    "SAUDE": {
        "prioridade": 1,
        "missao": "Preservar vidas"
    },

    "ENERGIA": {
        "prioridade": 2,
        "missao": "Garantir continuidade"
    },

    "COMUNICACAO": {
        "prioridade": 2,
        "missao": "Manter coordenação"
    },

    "LOGISTICA": {
        "prioridade": 2,
        "missao": "Garantir distribuição"
    },

    "PECUARIA": {
        "prioridade": 3,
        "missao": "Preservar rebanhos"
    },

    "AGRICULTURA": {
        "prioridade": 3,
        "missao": "Garantir produção"
    }

}