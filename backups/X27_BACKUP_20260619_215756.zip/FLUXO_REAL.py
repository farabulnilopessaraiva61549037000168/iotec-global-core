﻿â€œquero um sistema de automaÃ§Ã£oâ€

â†’ sistema responde em PT
â†’ cria pedido
â†’ entrega normal

