# ==========================================================
# IOTEC_REVENUE_EXTRACTION_ENGINE_V2.py
# MOTOR DE EXTRAÇÃO DE RECEITA V2
# NÃO MODIFICA ARQUIVOS EXISTENTES
# NÃO REESCREVE MÓDULOS
# APENAS ANALISA E ORGANIZA
# ==========================================================

import os
import json
from collections import defaultdict

ROOT = r"C:\IOTEC"

# ----------------------------------------------------------
# PASTAS IGNORADAS
# ----------------------------------------------------------

IGNORE_DIRS = {
    "venv",
    "node_modules",
    "__pycache__",
    "DUPLICADOS",
    "backup",
    "backups",
    "dist",
    "build",
    ".git"
}

# ----------------------------------------------------------
# MAPA DE CAPACIDADES
# ----------------------------------------------------------

CAPABILITIES = {

    "CRM": [
        "crm",
        "customer",
        "client",
        "cliente",
        "sales",
        "lead"
    ],

    "COMERCIAL": [
        "commercial",
        "opportunity",
        "proposal",
        "sales",
        "lead",
        "funnel"
    ],

    "AUTOMACAO": [
        "automation",
        "workflow",
        "orchestrator",
        "scheduler",
        "trigger"
    ],

    "AUDITORIA": [
        "audit",
        "auditoria",
        "scanner",
        "inspector",
        "forense"
    ],

    "BI": [
        "dashboard",
        "report",
        "analytics",
        "economic",
        "indicator"
    ],

    "IA": [
        "ai",
        "brain",
        "intelligence",
        "neural",
        "assistant"
    ],

    "FINANCEIRO": [
        "billing",
        "invoice",
        "payment",
        "revenue",
        "paypal"
    ],

    "INTEGRACAO": [
        "bridge",
        "connector",
        "integration",
        "gateway",
        "api"
    ]
}

# ----------------------------------------------------------
# COMPETÊNCIAS ECONÔMICAS
# ----------------------------------------------------------

COMPETENCIES = {

    "INTELIGENCIA_COMERCIAL": {
        "capabilities": [
            "CRM",
            "COMERCIAL",
            "BI"
        ],
        "market": [
            "CLINICAS",
            "CONTABILIDADES",
            "ESCOLAS"
        ],
        "ticket": 3500
    },

    "AUTOMACAO_INDUSTRIAL": {
        "capabilities": [
            "AUTOMACAO",
            "IA",
            "AUDITORIA"
        ],
        "market": [
            "INDUSTRIAS"
        ],
        "ticket": 10000
    },

    "AUDITORIA_OPERACIONAL": {
        "capabilities": [
            "AUDITORIA",
            "BI"
        ],
        "market": [
            "PREFEITURAS",
            "INDUSTRIAS"
        ],
        "ticket": 5000
    },

    "INTELIGENCIA_EXECUTIVA": {
        "capabilities": [
            "BI",
            "IA",
            "FINANCEIRO"
        ],
        "market": [
            "EMPRESAS"
        ],
        "ticket": 2500
    }
}

# ----------------------------------------------------------
# INVENTÁRIO
# ----------------------------------------------------------

inventory = defaultdict(list)

total_files = 0

for root, dirs, files in os.walk(ROOT):

    dirs[:] = [
        d for d in dirs
        if d not in IGNORE_DIRS
    ]

    for file in files:

        total_files += 1

        full = os.path.join(root, file)

        name = file.lower()

        for cap, words in CAPABILITIES.items():

            if any(w in name for w in words):

                inventory[cap].append(full)

# ----------------------------------------------------------
# RELATÓRIO
# ----------------------------------------------------------

report = []

report.append("")
report.append("===================================")
report.append("IOTEC REVENUE EXTRACTION ENGINE")
report.append("===================================")
report.append("")

report.append(
    f"ARQUIVOS ANALISADOS: {total_files}"
)

report.append("")

report.append("CAPACIDADES")
report.append("")

for cap in sorted(inventory.keys()):

    report.append(
        f"{cap}: {len(inventory[cap])}"
    )

report.append("")
report.append("===================================")
report.append("COMPETENCIAS ECONOMICAS")
report.append("===================================")
report.append("")

ranking = []

for comp, cfg in COMPETENCIES.items():

    score = 0

    modules = []

    for cap in cfg["capabilities"]:

        qty = len(inventory.get(cap, []))

        score += qty

        modules.extend(
            inventory.get(cap, [])[:5]
        )

    ranking.append(
        (
            score,
            comp,
            cfg
        )
    )

ranking.sort(reverse=True)

for score, comp, cfg in ranking:

    report.append("")
    report.append(f"COMPETENCIA: {comp}")

    report.append(
        f"MERCADOS: "
        f"{', '.join(cfg['market'])}"
    )

    report.append(
        f"TICKET MEDIO: "
        f"R$ {cfg['ticket']:,.2f}"
    )

    report.append(
        f"MATURIDADE: {score}"
    )

    report.append("")

# ----------------------------------------------------------
# TOP PRIORIDADES
# ----------------------------------------------------------

report.append("")
report.append("===================================")
report.append("TOP PRIORIDADES")
report.append("===================================")

for pos, (score, comp, cfg) in enumerate(
        ranking[:10],
        start=1
):

    report.append(
        f"{pos}º {comp}"
    )

    report.append(
        f"Ticket: R$ {cfg['ticket']:,.2f}"
    )

    report.append(
        f"Maturidade: {score}"
    )

    report.append("")

# ----------------------------------------------------------
# ATIVOS NÃO MONETIZADOS
# ----------------------------------------------------------

report.append("")
report.append("===================================")
report.append("ATIVOS DE ALTO VALOR")
report.append("===================================")

keywords = [
    "dashboard",
    "executive",
    "economic",
    "crm",
    "sales",
    "brain",
    "audit"
]

for root, dirs, files in os.walk(ROOT):

    dirs[:] = [
        d for d in dirs
        if d not in IGNORE_DIRS
    ]

    for file in files:

        lower = file.lower()

        if any(
            k in lower
            for k in keywords
        ):

            report.append(file)

# ----------------------------------------------------------
# EXPORTA
# ----------------------------------------------------------

json_file = os.path.join(
    ROOT,
    "REVENUE_INTELLIGENCE_MAP.json"
)

with open(
    json_file,
    "w",
    encoding="utf-8"
) as f:

    json.dump(
        inventory,
        f,
        indent=4,
        ensure_ascii=False
    )

txt_file = os.path.join(
    ROOT,
    "REVENUE_INTELLIGENCE_REPORT.txt"
)

with open(
    txt_file,
    "w",
    encoding="utf-8"
) as f:

    f.write("\n".join(report))

print("")
print("===================================")
print("REVENUE EXTRACTION ENGINE V2")
print("===================================")
print("")
print("MAPA:")
print(json_file)
print("")
print("RELATORIO:")
print(txt_file)
print("")
print("CONCLUIDO")
print("")