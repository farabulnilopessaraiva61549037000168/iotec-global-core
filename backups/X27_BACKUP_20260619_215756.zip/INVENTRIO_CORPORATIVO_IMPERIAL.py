﻿# =========================================================
# IOTEC URBANISMO SISTÃŠMICO DIGITAL
# ENGINE OPERACIONAL REAL
# =========================================================

import os
import shutil
import hashlib
import json
from datetime import datetime
from flask import Flask, jsonify

# =========================================================
# CONFIGURAÃ‡Ã•ES
# =========================================================

BASE_DIR = r"C:\IOTEC"

DOWNLOADS_DIR = os.path.join(
    os.path.expanduser("~"),
    "Downloads"
)

DIVERSOS_DIR = os.path.join(
    os.path.expanduser("~"),
    "Desktop",
    "DIVERSOS"
)

MATRIZ_DIR = os.path.join(BASE_DIR, "MATRIZES")
CLONES_DIR = os.path.join(BASE_DIR, "CLONES")
DISTRITOS_DIR = os.path.join(BASE_DIR, "DISTRITOS")
LOGS_DIR = os.path.join(BASE_DIR, "LOGS")

PORTA = 7900

# =========================================================
# DISTRITOS
# =========================================================

DISTRITOS = {
    "lexus_juris": [
        "juris",
        "adv",
        "legal",
        "tribunal"
    ],

    "casa_turca": [
        "finance",
        "treasury",
        "consorcio",
        "market"
    ],

    "regulus": [
        "media",
        "luxo",
        "lifestyle",
        "turismo"
    ],

    "omega": [
        "data",
        "analytics",
        "ai",
        "dashboard"
    ],

    "educacao": [
        "escola",
        "educacao",
        "aluno",
        "professor"
    ]
}

# =========================================================
# ESTRUTURA
# =========================================================

def criar_estrutura():

    pastas = [
        BASE_DIR,
        MATRIZ_DIR,
        CLONES_DIR,
        DISTRITOS_DIR,
        LOGS_DIR
    ]

    for pasta in pastas:
        os.makedirs(pasta, exist_ok=True)

    for distrito in DISTRITOS.keys():
        os.makedirs(
            os.path.join(DISTRITOS_DIR, distrito),
            exist_ok=True
        )

# =========================================================
# HASH
# =========================================================

def gerar_hash(caminho):

    sha = hashlib.sha256()

    with open(caminho, "rb") as f:

        while True:

            bloco = f.read(4096)

            if not bloco:
                break

            sha.update(bloco)

    return sha.hexdigest()

# =========================================================
# IDENTIFICA DISTRITO
# =========================================================

def identificar_distrito(nome):

    nome = nome.lower()

    for distrito, palavras in DISTRITOS.items():

        for palavra in palavras:

            if palavra in nome:
                return distrito

    return "regulus"

# =========================================================
# PRESERVA MATRIZ
# =========================================================

def preservar_matriz(arquivo):

    nome = os.path.basename(arquivo)

    destino = os.path.join(MATRIZ_DIR, nome)

    if not os.path.exists(destino):

        shutil.copy2(arquivo, destino)

    return destino

# =========================================================
# CLONE OPERACIONAL
# =========================================================

def criar_clone(arquivo, distrito):

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

    nome = os.path.basename(arquivo)

    clone_nome = f"{timestamp}_{nome}"

    pasta_distrito = os.path.join(
        CLONES_DIR,
        distrito
    )

    os.makedirs(pasta_distrito, exist_ok=True)

    destino = os.path.join(
        pasta_distrito,
        clone_nome
    )

    shutil.copy2(arquivo, destino)

    return destino

# =========================================================
# PROCESSAMENTO
# =========================================================

def processar_interfaces(origem):

    processados = []

    for raiz, dirs, arquivos in os.walk(origem):

        for arquivo in arquivos:

            if arquivo.endswith((
                ".html",
                ".htm",
                ".css",
                ".js",
                ".py"
            )):

                caminho = os.path.join(
                    raiz,
                    arquivo
                )

                distrito = identificar_distrito(
                    arquivo
                )

                matriz = preservar_matriz(
                    caminho
                )

                clone = criar_clone(
                    caminho,
                    distrito
                )

                registro = {
                    "arquivo": arquivo,
                    "distrito": distrito,
                    "matriz": matriz,
                    "clone": clone,
                    "hash": gerar_hash(caminho),
                    "timestamp": str(datetime.now())
                }

                processados.append(registro)

    return processados

# =========================================================
# LOGS
# =========================================================

def salvar_logs(dados):

    caminho = os.path.join(
        LOGS_DIR,
        "urbanismo_logs.json"
    )

    with open(
        caminho,
        "w",
        encoding="utf-8"
    ) as f:

        json.dump(
            dados,
            f,
            indent=4,
            ensure_ascii=False
        )

# =========================================================
# EXECUÃ‡ÃƒO CENTRAL
# =========================================================

def executar_engenharia():

    resultado = []

    if os.path.exists(DOWNLOADS_DIR):

        resultado.extend(
            processar_interfaces(
                DOWNLOADS_DIR
            )
        )

    if os.path.exists(DIVERSOS_DIR):

        resultado.extend(
            processar_interfaces(
                DIVERSOS_DIR
            )
        )

    salvar_logs(resultado)

    return resultado

# =========================================================
# FLASK
# =========================================================

app = Flask(__name__)

@app.route("/")

def home():

    return jsonify({
        "empresa": "IOTEC",
        "cidade": "REGULUS_CITY",
        "status": "online",
        "modo": "urbanismo_sistemico",
        "timestamp": str(datetime.now())
    })

@app.route("/engenharia")

def engenharia():

    resultado = executar_engenharia()

    return jsonify({
        "status": "processamento_concluido",
        "interfaces": len(resultado),
        "dados": resultado
    })

# =========================================================
# BOOT
# =========================================================

if __name__ == "__main__":

    criar_estrutura()

    print("=" * 70)
    print(" IOTEC URBANISMO SISTÃŠMICO DIGITAL ")
    print("=" * 70)
    print()

    app.run(
        host="0.0.0.0",
        port=PORTA
    )

