﻿# ============================================================
# IOTEC - CORE MASTER (ORQUESTRADOR CENTRAL)
# ============================================================

import os
import importlib

BASE = "C:\\IOTEC"

# =========================
# REGISTRO DE MÃ“DULOS
# =========================

MODULOS = [
    "IOTEC_CORE_EMAIL_24H",
    "IOTEC_CORE_LIVE_QUEUE",
    "IOTEC_AI_ATENDENTE",
    "IOTEC_CONTEXT_AI",
    "INTEGRACAO_FINAL_DO_NUCLEO",
    "FLUXO_REAL",
    "gerar_dossie"
]

# =========================
# FUNÃ‡ÃƒO DE CARREGAMENTO
# =========================

def carregar_modulo(nome):
    try:
        modulo = importlib.import_module(nome)
        print(f"âœ” MÃ³dulo carregado: {nome}")
        return modulo
    except Exception as e:
        print(f"âš ï¸ Falha ao carregar {nome}: {e}")
        return None

# =========================
# INICIALIZAÃ‡ÃƒO DO NÃšCLEO
# =========================

def iniciar_nucleo():

    print("\nðŸ§  INICIANDO NÃšCLEO IOTEC...\n")

    modulos_carregados = []

    for nome in MODULOS:
        m = carregar_modulo(nome)
        if m:
            modulos_carregados.append(m)

    print("\nðŸ”— Conectando mÃ³dulos...\n")

    # =========================
    # ATIVAÃ‡ÃƒO AUTOMÃTICA
    # =========================

    for m in modulos_carregados:

        for funcao in dir(m):

            if "iniciar" in funcao.lower() or "start" in funcao.lower():
                try:
                    getattr(m, funcao)()
                    print(f"ðŸš€ Executado: {m.__name__}.{funcao}")
                except:
                    pass

    print("\nâœ… NÃšCLEO ATIVO E OPERANDO\n")

# =========================
# EXECUÃ‡ÃƒO
# =========================

if __name__ == "__main__":
    iniciar_nucleo()

