# ==========================================================
# IOTEC EVENT IDENTIFICATION ENGINE
# ==========================================================

import sqlite3

DB = r"C:\IOTEC\IOTEC_EVENT_BUS.db"

conn = sqlite3.connect(DB)
cur = conn.cursor()

events = cur.execute("""

SELECT

    event_type,
    COUNT(*)

FROM events

GROUP BY event_type

ORDER BY COUNT(*) DESC

""").fetchall()

print("")
print("===================================")
print("IOTEC EVENT IDENTIFICATION")
print("===================================")

print("")

for event_type, total in events:

    destination = "UNKNOWN"

    if event_type == "LEAD":

        destination = "MISSION_LEDGER"

    elif event_type == "PROPOSAL":

        destination = "SALES_BRAIN"

    elif event_type == "MEETING":

        destination = "MISSION_LEDGER"

    elif event_type == "PAYMENT":

        destination = "REVENUE_CENTER"

    elif event_type == "CLIENT":

        destination = "EXECUTIVE_COCKPIT"

    elif event_type == "BOOT":

        destination = "CONTROL_TOWER"

    print(
        f"{event_type} -> {destination} ({total})"
    )

print("")
print("CONCLUIDO")

conn.close()