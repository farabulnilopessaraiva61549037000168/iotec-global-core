﻿# ============================================================
# IOTEC_MAIL_FILTER.py
# Filtro inteligente de e-mails (relevante vs propaganda)
# ============================================================

def classificar_email(remetente, assunto, corpo):

    assunto = assunto.lower()
    corpo = corpo.lower()
    remetente = remetente.lower()

    # =========================
    # PALAVRAS RELEVANTES
    # =========================

    palavras_relevantes = [
        "pagamento", "payment", "invoice",
        "cliente", "contrataÃ§Ã£o", "serviÃ§o",
        "anÃ¡lise", "analysis", "proposta"
    ]

    # =========================
    # PALAVRAS DE PROPAGANDA
    # =========================

    palavras_spam = [
        "promoÃ§Ã£o", "desconto", "oferta",
        "newsletter", "marketing",
        "unsubscribe", "clique aqui"
    ]

    # =========================
    # VERIFICAÃ‡ÃƒO
    # =========================

    if any(p in assunto or p in corpo for p in palavras_spam):
        return "SPAM"

    if any(p in assunto or p in corpo for p in palavras_relevantes):
        return "RELEVANTE"

    # =========================
    # DOMÃNIO SUSPEITO
    # =========================

    if "@" in remetente:
        dominio = remetente.split("@")[-1]

        if any(x in dominio for x in ["promo", "ads", "marketing"]):
            return "SPAM"

    return "NEUTRO"

