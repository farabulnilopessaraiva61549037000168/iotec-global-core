﻿# =========================================================
# IOTEC ARQUEOLOGIA DIGITAL CORPORATIVA
# ESCAVAÃ‡ÃƒO PROFUNDA DO NÃšCLEO
# =========================================================

import os
import json
import hashlib
from datetime import datetime

# =========================================================
# CONFIGURAÃ‡ÃƒO
# =========================================================

BASE_OUTPUT = r"C:\IOTEC\ARQUEOLOGIA_DIGITAL"

OUTPUT_JSON = os.path.join(
    BASE_OUTPUT,
    "arqueologia_digital.json"
)

OUTPUT_TXT = os.path.join(
    BASE_OUTPUT,
    "relatorio_arqueologico.txt"
)

# =========================================================
# DIRETÃ“RIOS A ESCAVAR
# ADICIONE MAIS CAMINHOS SE NECESSÃRIO
# =========================================================

RESERVATORIOS = [

    r"C:\IOTEC",

    os.path.join(
        os.path.expanduser("~"),
        "Downloads"
    ),

    os.path.join(
        os.path.expanduser("~"),
        "Desktop",
        "DIVERSOS"
    ),

    r"D:\IOTEC",

    r"D:\BACKUPS",

    r"D:\PROJETOS",

]

# =========================================================
# IGNORAR
# =========================================================

IGNORAR_PASTAS = [

    "node_modules",
    "__pycache__",
    ".git",
    "venv",
    "env",
    "dist",
    "build",
    "cache",
    "temp"

]

# =========================================================
# EXTENSÃ•ES IMPORTANTES
# =========================================================

EXTENSOES = (

    ".html",
    ".htm",
    ".css",
    ".js",
    ".py",
    ".json",
    ".sql",
    ".md",
    ".txt"

)

# =========================================================
# ESTRUTURA
# =========================================================

def criar_estrutura():

    os.makedirs(
        BASE_OUTPUT,
        exist_ok=True
    )

# =========================================================
# HASH
# =========================================================

def gerar_hash(arquivo):

    sha = hashlib.sha256()

    try:

        with open(arquivo, "rb") as f:

            while True:

                bloco = f.read(4096)

                if not bloco:
                    break

                sha.update(bloco)

        return sha.hexdigest()

    except:
        return "erro_hash"

# =========================================================
# TAMANHO
# =========================================================

def tamanho_mb(arquivo):

    try:

        return round(
            os.path.getsize(arquivo) / (1024 * 1024),
            2
        )

    except:
        return 0

# =========================================================
# IDENTIFICA ERA
# =========================================================

def identificar_era(caminho):

    caminho = caminho.lower()

    if "backup" in caminho:
        return "era_backup"

    if "clone" in caminho:
        return "era_clones"

    if "restore" in caminho:
        return "era_restauracao"

    if "old" in caminho:
        return "era_legado"

    if "v1" in caminho:
        return "era_v1"

    if "v2" in caminho:
        return "era_v2"

    return "era_atual"

# =========================================================
# IDENTIFICA VALOR
# =========================================================

def identificar_valor(nome):

    nome = nome.lower()

    termos = [

        "regulus",
        "lexus",
        "omega",
        "governance",
        "turca",
        "treasury",
        "premium",
        "core",
        "engine",
        "orchestrator",
        "dashboard"

    ]

    score = 0

    for termo in termos:

        if termo in nome:
            score += 20

    return min(score, 100)

# =========================================================
# DETECTA MATRIZ
# =========================================================

def detectar_matriz(nome):

    nome = nome.lower()

    if "clone" in nome:
        return False

    if "copy" in nome:
        return False

    if "backup" in nome:
        return False

    return True

# =========================================================
# ESCAVAÃ‡ÃƒO
# =========================================================

def escavar_reservatorio(origem):

    encontrados = []

    for raiz, dirs, arquivos in os.walk(origem):

        dirs[:] = [

            d for d in dirs
            if d not in IGNORAR_PASTAS

        ]

        for arquivo in arquivos:

            if arquivo.endswith(EXTENSOES):

                caminho = os.path.join(
                    raiz,
                    arquivo
                )

                try:

                    modificado = datetime.fromtimestamp(
                        os.path.getmtime(caminho)
                    )

                except:

                    modificado = "desconhecido"

                registro = {

                    "arquivo": arquivo,

                    "caminho": caminho,

                    "extensao": os.path.splitext(
                        arquivo
                    )[1],

                    "hash": gerar_hash(
                        caminho
                    ),

                    "tamanho_mb": tamanho_mb(
                        caminho
                    ),

                    "era": identificar_era(
                        caminho
                    ),

                    "valor": identificar_valor(
                        arquivo
                    ),

                    "matriz": detectar_matriz(
                        arquivo
                    ),

                    "ultima_modificacao": str(
                        modificado
                    )
                }

                encontrados.append(
                    registro
                )

    return encontrados

# =========================================================
# DUPLICADOS
# =========================================================

def detectar_duplicados(dados):

    hashes = {}

    duplicados = []

    for item in dados:

        h = item["hash"]

        if h in hashes:

            duplicados.append(
                item
            )

        else:

            hashes[h] = item

    return duplicados

# =========================================================
# RELATÃ“RIO
# =========================================================

def gerar_relatorio(dados, duplicados):

    total = len(dados)

    matrizes = len([
        x for x in dados
        if x["matriz"]
    ])

    premium = len([
        x for x in dados
        if x["valor"] >= 40
    ])

    with open(
        OUTPUT_TXT,
        "w",
        encoding="utf-8"
    ) as f:

        f.write("=" * 70 + "\n")
        f.write(" IOTEC ARQUEOLOGIA DIGITAL\n")
        f.write("=" * 70 + "\n\n")

        f.write(f"TOTAL DE ATIVOS: {total}\n")
        f.write(f"MATRIZES: {matrizes}\n")
        f.write(f"ATIVOS PREMIUM: {premium}\n")
        f.write(f"DUPLICADOS: {len(duplicados)}\n\n")

        f.write("=" * 70 + "\n")
        f.write(" TOP 100 MAIS VALIOSOS\n")
        f.write("=" * 70 + "\n\n")

        top = sorted(
            dados,
            key=lambda x: x["valor"],
            reverse=True
        )[:100]

        for item in top:

            linha = (
                f"[{item['valor']}] "
                f"{item['arquivo']} "
                f"-> {item['era']} "
                f"-> MATRIZ={item['matriz']}\n"
            )

            f.write(linha)

# =========================================================
# JSON
# =========================================================

def salvar_json(dados):

    with open(
        OUTPUT_JSON,
        "w",
        encoding="utf-8"
    ) as f:

        json.dump(
            dados,
            f,
            indent=4,
            ensure_ascii=False
        )

# =========================================================
# EXECUÃ‡ÃƒO
# =========================================================

def executar():

    print("=" * 70)
    print(" IOTEC ARQUEOLOGIA DIGITAL")
    print("=" * 70)
    print()

    criar_estrutura()

    ativos = []

    for reservatorio in RESERVATORIOS:

        if os.path.exists(reservatorio):

            print(
                f"[+] ESCAVANDO -> {reservatorio}"
            )

            encontrados = escavar_reservatorio(
                reservatorio
            )

            ativos.extend(
                encontrados
            )

    print()
    print("[+] ANALISANDO DUPLICADOS")

    duplicados = detectar_duplicados(
        ativos
    )

    print()
    print("[+] GERANDO RELATÃ“RIOS")

    salvar_json(
        ativos
    )

    gerar_relatorio(
        ativos,
        duplicados
    )

    print()
    print("=" * 70)
    print(" ESCAVAÃ‡ÃƒO FINALIZADA")
    print("=" * 70)

    print()

    print(
        f"ATIVOS ENCONTRADOS: {len(ativos)}"
    )

    print(
        f"DUPLICADOS: {len(duplicados)}"
    )

    print()

    print(
        f"JSON -> {OUTPUT_JSON}"
    )

    print(
        f"TXT  -> {OUTPUT_TXT}"
    )

# =========================================================
# START
# =========================================================

if __name__ == "__main__":

    executar()

